namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTF 임포트의 리그·애니메이션 형식(FBX 임포터 Rig 탭의 Animation Type 과 같은 역할). 직렬화 값이라 숫자를 바꾸지 않는다.
    /// </summary>
    internal enum UMXGltfAnimationType
    {
        /// <summary>
        /// 휴머노이드 아바타 + 휴머노이드 클립. 필수 본을 못 찾거나 아바타가 유효하지 않으면 Generic 으로 만든다(경고 없음).
        /// </summary>
        Humanoid = 0,

        /// <summary>
        /// Animator + 일반(legacy 아님) 클립.
        /// </summary>
        Generic = 1,

        /// <summary>
        /// Animation 컴포넌트 + legacy 클립(예전 동작).
        /// </summary>
        Legacy = 2,
    }
}
