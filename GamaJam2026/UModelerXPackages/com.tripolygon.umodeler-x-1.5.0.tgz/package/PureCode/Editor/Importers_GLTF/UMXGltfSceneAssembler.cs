using Tripolygon.UModelerX.Editor.Riggings;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    internal sealed class UMXGltfAssembledScene
    {
        public GameObject Root;
        public AnimationClip[] Clips;
        /// <summary>
        /// Humanoid 로 만든 아바타. 없으면 null.
        /// </summary>
        public Avatar Avatar;
    }

    /// <summary>
    /// 불러온 glTF 문서로 임포트 결과(계층·메시·머티리얼·클립·아바타)를 만들고 서브에셋으로 등록한다.
    /// ScriptedImporter 없이도(standalone 문맥) 같은 결과를 만들어 테스트할 수 있게 임포터 본문에서 떼어 두었다.
    /// </summary>
    internal static class UMXGltfSceneAssembler
    {
        internal static UMXGltfAssembledScene Assemble(UMXGltfLoadedDocument document, UMXGltfAssetContext assetContext, UMXGltfAnimationType animationType)
        {
            var materialBuilder = new UMXGltfMaterialBuilder(document, assetContext);
            var meshBuilder = new UMXGltfMeshBuilder(document, assetContext, materialBuilder);
            var builtMeshes = meshBuilder.BuildAll();
            var nodeBuilder = new UMXGltfNodeBuilder(document, builtMeshes);
            var rootObject = nodeBuilder.BuildSceneRoot();
            bool hasSkin = rootObject.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;

            // Humanoid 는 스킨이 있을 때만 시도한다. 필수 본이 모자라거나 아바타가 유효하지 않으면 경고 없이 Generic 으로 만든다.
            Avatar avatar = null;
            if (animationType == UMXGltfAnimationType.Humanoid && hasSkin)
            {
                UMXGltfHumanoidBuilder.TryBuildAvatar(rootObject, rootObject.name + "Avatar", out avatar);
            }

            var animationBuilder = new UMXGltfAnimationBuilder(document, assetContext, nodeBuilder.NodePaths, nodeBuilder.MorphBindings)
            {
                Legacy = animationType == UMXGltfAnimationType.Legacy,
                // 휴머노이드는 일반 클립을 굽는 재료로만 쓰고, 구운 클립을 같은 키로 등록한다
                RegisterAssets = avatar == null,
            };
            var clips = animationBuilder.BuildAll();
            var scene = new UMXGltfAssembledScene { Root = rootObject, Clips = clips, Avatar = avatar };

            if (animationType == UMXGltfAnimationType.Legacy)
            {
                AttachAnimationComponent(rootObject, clips);
                return scene;
            }

            if (avatar != null)
            {
                assetContext.AddObject("Avatar", avatar);
                for (int i = 0; i < clips.Length; ++i)
                {
                    var baked = UMXHumanoidClipBaker.BakeClip(rootObject, avatar, clips[i]);
                    Object.DestroyImmediate(clips[i]);
                    clips[i] = baked;
                    assetContext.AddObject(baked.name, baked);
                }

                rootObject.AddComponent<Animator>().avatar = avatar;
                return scene;
            }

            // Animator 는 움직일 것(스킨·클립)이 있을 때만 붙인다. 정적 모델은 예전처럼 컴포넌트가 없다.
            if (clips.Length > 0 || hasSkin)
            {
                rootObject.AddComponent<Animator>();
            }

            return scene;
        }

        // legacy Animation 컴포넌트의 path 기반 curve binding 은 glTF channel 의 (node, path) 모델과 자연스럽게
        // 매칭된다. clip.legacy = true 인 clip 만 AddClip 가능 — AnimationBuilder 에서 보장.
        private static void AttachAnimationComponent(GameObject rootObject, AnimationClip[] clips)
        {
            if (clips == null || clips.Length == 0)
            {
                return;
            }

            var animationComponent = rootObject.AddComponent<Animation>();
            foreach (var clip in clips)
            {
                if (clip == null)
                {
                    continue;
                }

                animationComponent.AddClip(clip, clip.name);
            }

            animationComponent.clip = clips[0];
            animationComponent.playAutomatically = false;
        }
    }
}
