﻿using System;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.Rendering;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    internal sealed class UMXGltfBuiltPrimitive
    {
        public Material Material;
        public Mesh Mesh;
        public string Name;
        /// <summary>
        /// 모프 타깃으로 만든 블렌드쉐이프 이름(인덱스 = 타깃 번호). 없으면 빈 배열.
        /// </summary>
        public string[] BlendShapeNames = Array.Empty<string>();
    }

    internal sealed class UMXGltfBuiltMesh
    {
        public string Name;
        public List<UMXGltfBuiltPrimitive> Primitives = new List<UMXGltfBuiltPrimitive>();
        /// <summary>
        /// mesh.weights(0~1). 없으면 null.
        /// </summary>
        public float[] DefaultWeights;
    }

    internal sealed class UMXGltfMeshBuilder
    {
        private readonly UMXGltfAssetContext assetContext;
        private readonly UMXGltfLoadedDocument document;
        private readonly UMXGltfMaterialBuilder materialBuilder;

        public UMXGltfMeshBuilder(
            UMXGltfLoadedDocument loadedDocument,
            UMXGltfAssetContext context,
            UMXGltfMaterialBuilder gltfMaterialBuilder)
        {
            document = loadedDocument;
            assetContext = context;
            materialBuilder = gltfMaterialBuilder;
        }

        public UMXGltfBuiltMesh[] BuildAll()
        {
            if (document.Root.meshes == null || document.Root.meshes.Length == 0)
            {
                return Array.Empty<UMXGltfBuiltMesh>();
            }

            var result = new UMXGltfBuiltMesh[document.Root.meshes.Length];
            for (var meshIndex = 0; meshIndex < result.Length; ++meshIndex)
            {
                result[meshIndex] = BuildMesh(document.Root.meshes[meshIndex], meshIndex);
            }

            return result;
        }

        private UMXGltfBuiltMesh BuildMesh(UMXGltfMesh sourceMesh, int meshIndex)
        {
            var builtMesh = new UMXGltfBuiltMesh();
            builtMesh.Name = string.IsNullOrEmpty(sourceMesh?.name) ? $"GLTF_Mesh_{meshIndex}" : sourceMesh.name;
            builtMesh.DefaultWeights = sourceMesh?.weights != null && sourceMesh.weights.Length > 0 ? sourceMesh.weights : null;

            if (sourceMesh?.primitives == null)
            {
                return builtMesh;
            }

            for (var primitiveIndex = 0; primitiveIndex < sourceMesh.primitives.Length; ++primitiveIndex)
            {
                var primitive = sourceMesh.primitives[primitiveIndex];
                if (primitive == null)
                {
                    continue;
                }

                var unityMesh = BuildPrimitiveMesh(sourceMesh, primitive, meshIndex, primitiveIndex, out var blendShapeNames);
                builtMesh.Primitives.Add(new UMXGltfBuiltPrimitive
                {
                    Mesh = unityMesh,
                    Material = materialBuilder.GetMaterial(primitive.material),
                    Name = unityMesh.name,
                    BlendShapeNames = blendShapeNames
                });
            }

            return builtMesh;
        }

        private Mesh BuildPrimitiveMesh(
            UMXGltfMesh sourceMesh,
            UMXGltfPrimitive primitive,
            int meshIndex,
            int primitiveIndex,
            out string[] blendShapeNames)
        {
            if (primitive.mode != UMXGltfSupportedSubset.TrianglesMode)
            {
                throw new NotSupportedException($"Primitive mode {primitive.mode} is not supported.");
            }

            var positions = UMXGltfAccessorReader.ReadVector3(document, primitive.attributes.POSITION);
            var normals = primitive.attributes.NORMAL >= 0
                ? UMXGltfAccessorReader.ReadVector3(document, primitive.attributes.NORMAL)
                : null;
            var tangents = primitive.attributes.TANGENT >= 0
                ? UMXGltfAccessorReader.ReadVector4(document, primitive.attributes.TANGENT)
                : null;
            var uvs = primitive.attributes.TEXCOORD_0 >= 0
                ? UMXGltfAccessorReader.ReadVector2(document, primitive.attributes.TEXCOORD_0)
                : null;
            var colors = primitive.attributes.COLOR_0 >= 0
                ? UMXGltfAccessorReader.ReadColors(document, primitive.attributes.COLOR_0)
                : null;
            var indices = primitive.indices >= 0
                ? UMXGltfAccessorReader.ReadIndices(document, primitive.indices)
                : BuildSequentialIndices(positions.Length);

            ConvertCoordinates(positions, normals, tangents, uvs);
            UMXGltfCoordinateUtility.ReverseTriangleWinding(indices);

            var mesh = new Mesh();
            mesh.name = BuildMeshName(sourceMesh, meshIndex, primitiveIndex);
            mesh.indexFormat = positions.Length > UInt16.MaxValue ? IndexFormat.UInt32 : IndexFormat.UInt16;
            mesh.vertices = positions;
            mesh.triangles = indices;

            if (normals != null && normals.Length == positions.Length)
            {
                mesh.normals = normals;
            }
            else
            {
                mesh.RecalculateNormals();
            }

            if (tangents != null && tangents.Length == positions.Length)
            {
                mesh.tangents = tangents;
            }

            if (uvs != null && uvs.Length == positions.Length)
            {
                mesh.uv = uvs;
            }

            if (colors != null && colors.Length == positions.Length)
            {
                mesh.colors = colors;
            }

            ApplyBoneWeights(mesh, primitive, positions.Length);
            blendShapeNames = AddBlendShapes(mesh, sourceMesh, primitive, positions.Length);

            mesh.RecalculateBounds();

            if ((tangents == null || tangents.Length == 0) && uvs != null && normals != null)
            {
                mesh.RecalculateTangents();
            }

            assetContext.AddObject(mesh.name, mesh);
            return mesh;
        }

        /// <summary>
        /// JOINTS_0/WEIGHTS_0 가 모두 있으면 <see cref="Mesh.boneWeights"/> 를 채운다.
        /// 첫 마일스톤은 vertex 당 4본 한정. weight 합이 1.0 에서 벗어난 데이터는 정규화.
        /// bindposes 는 NodeBuilder 에서 skin 단위로 채워진다(여기서는 다루지 않는다).
        /// </summary>
        private void ApplyBoneWeights(Mesh mesh, UMXGltfPrimitive primitive, int vertexCount)
        {
            if (primitive.attributes.JOINTS_0 < 0 || primitive.attributes.WEIGHTS_0 < 0)
            {
                return;
            }

            var joints = UMXGltfAccessorReader.ReadJointsVec4(document, primitive.attributes.JOINTS_0);
            var weights = UMXGltfAccessorReader.ReadWeightsVec4(document, primitive.attributes.WEIGHTS_0);

            if (joints.Length != vertexCount * 4 || weights.Length != vertexCount)
            {
                throw new InvalidOperationException(
                    $"JOINTS_0/WEIGHTS_0 length mismatch: joints={joints.Length}, weights={weights.Length}, vertices={vertexCount} (expected joints={vertexCount * 4}).");
            }

            var boneWeights = new BoneWeight[vertexCount];
            for (var i = 0; i < vertexCount; ++i)
            {
                var w = weights[i];
                var sum = w.x + w.y + w.z + w.w;
                if (sum > 0f)
                {
                    var inv = 1f / sum;
                    w.x *= inv; w.y *= inv; w.z *= inv; w.w *= inv;
                }

                boneWeights[i] = new BoneWeight
                {
                    boneIndex0 = joints[i * 4 + 0], weight0 = w.x,
                    boneIndex1 = joints[i * 4 + 1], weight1 = w.y,
                    boneIndex2 = joints[i * 4 + 2], weight2 = w.z,
                    boneIndex3 = joints[i * 4 + 3], weight3 = w.w,
                };
            }

            mesh.boneWeights = boneWeights;
        }

        /// <summary>
        /// 모프 타깃(POSITION·NORMAL·TANGENT 델타)을 블렌드쉐이프 프레임(가중치 100) 하나씩으로 넣는다.
        /// 델타도 방향이라 위치·법선과 같이 x 를 뒤집는다. 타깃이 없으면 빈 배열.
        /// </summary>
        private string[] AddBlendShapes(Mesh mesh, UMXGltfMesh sourceMesh, UMXGltfPrimitive primitive, int vertexCount)
        {
            var targets = primitive.targets;
            if (targets == null || targets.Length == 0)
            {
                return Array.Empty<string>();
            }

            var names = BuildBlendShapeNames(sourceMesh?.extras?.targetNames, targets.Length);
            for (var t = 0; t < targets.Length; ++t)
            {
                var target = targets[t];
                var deltaVertices = ReadMorphDeltas(target != null ? target.POSITION : -1, vertexCount) ?? new Vector3[vertexCount];
                var deltaNormals = ReadMorphDeltas(target != null ? target.NORMAL : -1, vertexCount);
                var deltaTangents = ReadMorphDeltas(target != null ? target.TANGENT : -1, vertexCount);
                mesh.AddBlendShapeFrame(names[t], 100f, deltaVertices, deltaNormals, deltaTangents);
            }

            return names;
        }

        private Vector3[] ReadMorphDeltas(int accessorIndex, int vertexCount)
        {
            if (accessorIndex < 0)
            {
                return null;
            }

            var deltas = UMXGltfAccessorReader.ReadVector3(document, accessorIndex);
            if (deltas.Length != vertexCount)
            {
                throw new InvalidOperationException(
                    $"Morph target accessor {accessorIndex} has {deltas.Length} elements, but the primitive has {vertexCount} vertices.");
            }

            for (var i = 0; i < deltas.Length; ++i)
            {
                deltas[i] = UMXGltfCoordinateUtility.ToUnityPosition(deltas[i]);
            }

            return deltas;
        }

        /// <summary>
        /// 블렌드쉐이프 이름. mesh.extras.targetNames 가 없으면 Target_번호, 겹치면 _1·_2… 를 붙인다(Unity 는 같은 이름을 거부한다).
        /// </summary>
        internal static string[] BuildBlendShapeNames(string[] targetNames, int count)
        {
            var names = new string[count];
            var used = new HashSet<string>();
            for (var i = 0; i < count; ++i)
            {
                var name = targetNames != null && i < targetNames.Length && string.IsNullOrEmpty(targetNames[i]) == false
                    ? targetNames[i]
                    : $"Target_{i}";
                var unique = name;
                for (var suffix = 1; used.Contains(unique); ++suffix)
                {
                    unique = $"{name}_{suffix}";
                }

                used.Add(unique);
                names[i] = unique;
            }

            return names;
        }

        private static string BuildMeshName(UMXGltfMesh sourceMesh, int meshIndex, int primitiveIndex)
        {
            var sourceName = string.IsNullOrEmpty(sourceMesh?.name) ? $"GLTF_Mesh_{meshIndex}" : sourceMesh.name;
            return $"{sourceName}_Primitive_{primitiveIndex}";
        }

        private static int[] BuildSequentialIndices(int count)
        {
            var result = new int[count];
            for (var i = 0; i < count; ++i)
            {
                result[i] = i;
            }

            return result;
        }

        private static void ConvertCoordinates(Vector3[] positions, Vector3[] normals, Vector4[] tangents, Vector2[] uvs)
        {
            if (positions != null)
            {
                for (var i = 0; i < positions.Length; ++i)
                {
                    positions[i] = UMXGltfCoordinateUtility.ToUnityPosition(positions[i]);
                }
            }

            if (normals != null)
            {
                for (var i = 0; i < normals.Length; ++i)
                {
                    normals[i] = UMXGltfCoordinateUtility.ToUnityNormal(normals[i]);
                }
            }

            if (tangents != null)
            {
                for (var i = 0; i < tangents.Length; ++i)
                {
                    tangents[i] = UMXGltfCoordinateUtility.ToUnityTangent(tangents[i]);
                }
            }

            if (uvs != null)
            {
                for (var i = 0; i < uvs.Length; ++i)
                {
                    uvs[i] = UMXGltfCoordinateUtility.ToUnityUv(uvs[i]);
                }
            }
        }
    }
}
