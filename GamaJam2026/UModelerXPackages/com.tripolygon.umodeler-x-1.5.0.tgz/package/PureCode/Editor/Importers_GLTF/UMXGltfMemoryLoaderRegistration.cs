﻿using Tripolygon.UModelerX.Editor.Utilities.LayoutPreset;
using UnityEditor;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// PureCode.Editor 어셈블리 로드 시 GlbMemoryLoader delegate 와 "UModeler X 임포터로 전환" 훅을 등록한다.
    /// </summary>
    static class UMXGltfMemoryLoaderRegistration
    {
        [InitializeOnLoadMethod]
        static void Register()
        {
            PicoBerryAssetLibraryManager.GlbMemoryLoader = UMXGltfMemoryLoader.LoadFromGlbBytes;
            UMXGltfImportHooks.SwitchToUmxImporter = UMXGltfImporterOverride.TrySwitchToUmxImporter;
        }
    }
}
