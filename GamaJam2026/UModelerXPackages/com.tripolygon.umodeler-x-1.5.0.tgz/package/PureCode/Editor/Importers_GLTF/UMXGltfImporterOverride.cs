// glTFast 가 .glb/.gltf 의 기본 임포터로 등록되는 조건(glTFast Editor/Scripts/GltfImporter.cs 와 같은 규칙)
#if GLTFAST_PRESENT && !GLTFAST_EDITOR_IMPORT_OFF && (!GLTFAST_FORCE_DEFAULT_IMPORTER_OFF || GLTFAST_FORCE_DEFAULT_IMPORTER_ON)
#define UMX_GLTFAST_IS_DEFAULT_IMPORTER
#endif

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

using UnityEditor;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTFast 가 기본 glb 임포터인 프로젝트에서 glb 를 UModeler X 임포터로 바꾸는 규칙.
    /// 기존 glb·다른 도구(Unity AI Assistant 등)가 만든 glb·우리가 못 읽는 glb 는 glTFast 에 남긴다(사용자 결정).
    /// 어떤 임포터를 쓰는지는 에셋 .meta 의 script guid 로 남으므로 UMXGltfImporter.cs.meta 의 guid 를 바꾸면 안 된다.
    /// </summary>
    internal static class UMXGltfImporterOverride
    {
        /// <summary>
        /// Unity AI Assistant 가 생성 에셋에 붙이는 라벨(com.unity.ai.assistant Legal.UnityAIGeneratedLabel).
        /// </summary>
        internal const string ThirdPartyGeneratedLabel = "UnityAI";

        // AI Assistant 의 작업·임시 폴더(TemporaryAssetUtilities 의 "Assets/AI Toolkit/Temp/<guid>/" 포함)
        private const string AiToolkitFolder = "Assets/AI Toolkit/";

        // AI Assistant 메시 생성: <프리팹 폴더>/<프리팹 이름>_Assets/selected.glb 옆에 <프리팹 이름>.prefab 이 있다(MeshFolderSync)
        private static readonly Regex SelectedModelInAssetsFolder = new Regex(@"^(?<dir>(.*/)?)(?<name>[^/]+)_Assets/selected\.(glb|gltf)$", RegexOptions.IgnoreCase);

        /// <summary>
        /// 다른 도구가 glTFast 임포터를 전제로 만든 glb 인지(경로로 판정). 전환하면 그 도구가 곧바로 만든 프리팹의 참조가 끊긴다.
        /// </summary>
        internal static bool IsThirdPartyToolOutput(string assetPath, Func<string, bool> fileExists)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                return false;
            }

            var path = assetPath.Replace('\\', '/');
            if (path.StartsWith(AiToolkitFolder, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            var match = SelectedModelInAssetsFolder.Match(path);
            return match.Success && fileExists(match.Groups["dir"].Value + match.Groups["name"].Value + ".prefab");
        }

        internal static bool HasThirdPartyLabel(IEnumerable<string> labels)
        {
            if (labels == null)
            {
                return false;
            }

            foreach (var label in labels)
            {
                if (string.Equals(label, ThirdPartyGeneratedLabel, StringComparison.Ordinal))
                {
                    return true;
                }
            }
            return false;
        }

        internal static bool IsGltfPath(string assetPath)
        {
            var extension = Path.GetExtension(assetPath);
            return string.Equals(extension, ".glb", StringComparison.OrdinalIgnoreCase) || string.Equals(extension, ".gltf", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// glb/gltf 를 UModeler X 임포터로 바꾼다. glTFast 가 기본 임포터가 아니면(우리 임포터가 이미 기본) 아무것도 하지 않는다.
        /// 이미 우리 임포터이거나, 사용자가 임포터를 골라 두었거나, 우리가 못 읽는 파일이면 바꾸지 않는다.
        /// 파일을 쓰고 임포트한 직후, 처음 로드하기 전에 부른다(UMXGltfImportHooks.SwitchToUmxImporter).
        /// </summary>
        /// <returns>바꿨으면 true.</returns>
        internal static bool TrySwitchToUmxImporter(string assetPath)
        {
#if UMX_GLTFAST_IS_DEFAULT_IMPORTER
            if (string.IsNullOrEmpty(assetPath) || IsGltfPath(assetPath) == false)
            {
                return false;
            }
            if (AssetImporter.GetAtPath(assetPath) is UMXGltfImporter || AssetDatabase.GetImporterOverride(assetPath) != null)
            {
                return false;
            }

            try
            {
                if (UMXGltfSupportedSubset.CollectIssues(UMXGltfDocumentLoader.ReadRoot(assetPath)).Count > 0)
                {
                    return false;
                }
            }
            catch (Exception)
            {
                // 읽을 수 없는 파일은 glTFast 에 맡긴다
                return false;
            }

            AssetDatabase.SetImporterOverride<UMXGltfImporter>(assetPath);
            if (AssetImporter.GetAtPath(assetPath) is UMXGltfImporter == false)
            {
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
            }

            // 사전 검사로 못 거른 실패(빌더 단계 예외)면 glTFast 로 되돌린다 — 잘 들어오던 파일을 실패 오브젝트로 만들지 않는다
            var mainAsset = AssetDatabase.LoadMainAssetAtPath(assetPath);
            if (mainAsset == null || mainAsset.name == UMXGltfImporter.ImportFailedObjectName)
            {
                AssetDatabase.ClearImporterOverride(assetPath);
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
                return false;
            }
            return true;
#else
            return false;
#endif
        }
    }
}
