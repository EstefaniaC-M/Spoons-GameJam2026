﻿using System.Collections.Generic;
using System.Text;

using UnityEditor.AssetImporters;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    internal sealed class UMXGltfAssetContext
    {
        private readonly Dictionary<string, int> idCounters = new Dictionary<string, int>();
        private readonly List<string> addedKeys = new List<string>();
        private readonly AssetImportContext importContext;

        /// <summary>
        /// 지금까지 등록한 서브에셋 식별자("키_번호"). standalone 문맥에서도 기록한다(식별자 안정성 확인용).
        /// </summary>
        public IReadOnlyList<string> AddedKeys => addedKeys;

        public UMXGltfAssetContext(AssetImportContext context)
        {
            importContext = context;
        }

        /// <summary>Standalone 모드: AssetImportContext 없이 메모리상에서만 빌드. AddObject는 no-op.</summary>
        public UMXGltfAssetContext()
        {
            importContext = null;
        }

        public void AddObject(string key, Object assetObject)
        {
            if (assetObject == null)
            {
                return;
            }

            var sanitizedKey = SanitizeKey(key);
            if (!idCounters.TryGetValue(sanitizedKey, out var count))
            {
                count = 0;
            }

            idCounters[sanitizedKey] = count + 1;
            var identifier = $"{sanitizedKey}_{count}";
            addedKeys.Add(identifier);
            if (importContext != null)
            {
                importContext.AddObjectToAsset(identifier, assetObject);
            }
        }

        private static string SanitizeKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return "gltf";
            }

            var builder = new StringBuilder(key.Length);
            for (var i = 0; i < key.Length; ++i)
            {
                var ch = key[i];
                if (char.IsLetterOrDigit(ch))
                {
                    builder.Append(ch);
                }
                else
                {
                    builder.Append('_');
                }
            }

            return builder.ToString();
        }
    }
}
