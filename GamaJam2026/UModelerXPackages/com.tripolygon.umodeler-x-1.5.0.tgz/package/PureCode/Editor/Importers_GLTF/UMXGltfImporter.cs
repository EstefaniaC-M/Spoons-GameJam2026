﻿// glTFast 가 .glb/.gltf 의 기본 임포터로 등록되는 조건(glTFast Editor/Scripts/GltfImporter.cs 와 같은 규칙)
#if GLTFAST_PRESENT && !GLTFAST_EDITOR_IMPORT_OFF && (!GLTFAST_FORCE_DEFAULT_IMPORTER_OFF || GLTFAST_FORCE_DEFAULT_IMPORTER_ON)
#define UMX_GLTFAST_IS_DEFAULT_IMPORTER
#endif

using System;

using UnityEditor.AssetImporters;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    // 2: 좌표 변환을 z 반전 → x 반전으로 바꿨다(glTFast 와 정면 일치).
    // 3: Animation Type(Humanoid·Generic·Legacy), 블렌드쉐이프. 버전을 올려 기존 에셋을 다시 임포트한다.
    // 유니티는 한 확장자에 기본 임포터를 하나만 허용한다. glTFast 가 기본이면 우리는 대체 임포터로 등록하고(Inspector Importer 드롭다운에서 고름),
    // 새로 들어온 glb 는 UMXGltfNewAssetImporterSwitcher 가 우리 쪽으로 바꾼다.
#if UMX_GLTFAST_IS_DEFAULT_IMPORTER
    [ScriptedImporter(3, null, overrideExts: new[] { "gltf", "glb" })]
#else
    [ScriptedImporter(3, new[] { "gltf", "glb" })]
#endif
    internal sealed class UMXGltfImporter : ScriptedImporter
    {
        /// <summary>
        /// 임포트에 실패했을 때 메인 오브젝트 이름. 자동 전환이 결과를 확인할 때도 쓴다(UMXGltfImporterOverride).
        /// </summary>
        internal const string ImportFailedObjectName = "GLTF Import Failed";

        // 기존 에셋(meta 에 이 필드가 없음)도 재임포트 때 기본값 Humanoid 를 받는다.
        [SerializeField]
        private UMXGltfAnimationType animationType = UMXGltfAnimationType.Humanoid;

        public override void OnImportAsset(AssetImportContext ctx)
        {
            try
            {
                var document = UMXGltfDocumentLoader.Load(ctx.assetPath);
                var assetContext = new UMXGltfAssetContext(ctx);
                var scene = UMXGltfSceneAssembler.Assemble(document, assetContext, animationType);

                assetContext.AddObject("main", scene.Root);
                ctx.SetMainObject(scene.Root);
            }
            catch (Exception exception)
            {
                var errorObject = new GameObject(ImportFailedObjectName);
                var assetContext = new UMXGltfAssetContext(ctx);
                assetContext.AddObject("main_error", errorObject);
                ctx.LogImportError(exception.ToString());
                ctx.SetMainObject(errorObject);
            }
        }
    }
}
