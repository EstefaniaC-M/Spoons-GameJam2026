// glTFast 가 .glb/.gltf 의 기본 임포터로 등록되는 조건(glTFast Editor/Scripts/GltfImporter.cs 와 같은 규칙)
#if GLTFAST_PRESENT && !GLTFAST_EDITOR_IMPORT_OFF && (!GLTFAST_FORCE_DEFAULT_IMPORTER_OFF || GLTFAST_FORCE_DEFAULT_IMPORTER_ON)
#define UMX_GLTFAST_IS_DEFAULT_IMPORTER
#endif

#if UMX_GLTFAST_IS_DEFAULT_IMPORTER
using System.Collections.Generic;
using System.IO;

using UnityEditor;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTFast 가 기본 임포터인 프로젝트에서 새로 추가된 glb/gltf(meta 가 없던 파일)를 UModeler X 임포터로 바꾼다.
    /// 처음 한 번은 glTFast 로 임포트되고, 지연 호출에서 우리 임포터로 다시 임포트된다.
    /// 다른 도구 산출물(경로·라벨)과 우리가 못 읽는 파일은 바꾸지 않는다(UMXGltfImporterOverride).
    /// </summary>
    internal sealed class UMXGltfNewAssetImporterSwitcher : AssetPostprocessor
    {
        private static readonly List<string> pendingPaths = new List<string>();

        private void OnPreprocessAsset()
        {
            if (assetImporter is UMXGltfImporter || assetImporter.importSettingsMissing == false)
            {
                return;
            }
            if (UMXGltfImporterOverride.IsGltfPath(assetPath) == false || UMXGltfImporterOverride.IsThirdPartyToolOutput(assetPath, File.Exists))
            {
                return;
            }

            if (pendingPaths.Count == 0)
            {
                EditorApplication.delayCall += SwitchPending;
            }
            if (pendingPaths.Contains(assetPath) == false)
            {
                pendingPaths.Add(assetPath);
            }
        }

        // 다른 도구는 임포트 직후 같은 흐름에서 라벨(UnityAI)을 붙이므로, 지연 호출 시점에 라벨을 한 번 더 본다
        private static void SwitchPending()
        {
            var paths = pendingPaths.ToArray();
            pendingPaths.Clear();
            foreach (var path in paths)
            {
                var mainAsset = AssetDatabase.LoadMainAssetAtPath(path);
                if (mainAsset == null || UMXGltfImporterOverride.HasThirdPartyLabel(AssetDatabase.GetLabels(mainAsset)))
                {
                    continue;
                }

                UMXGltfImporterOverride.TrySwitchToUmxImporter(path);
            }
        }
    }
}
#endif
