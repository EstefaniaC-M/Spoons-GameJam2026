using System.Runtime.CompilerServices;

/// glTF 임포터 내부 타입(문서 로더·빌더)을 테스트한다.
[assembly: InternalsVisibleTo("Tripolygon.UModelerX.Editor.GltfHumanoid.Tests")]

