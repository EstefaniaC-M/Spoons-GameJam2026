#if UNITY_EDITOR
#if UNITY_2021_2_OR_NEWER
using UnityEditor.Toolbars;
using UnityEngine.UIElements;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    /// <summary>
    /// UMX Object 오버레이로 옮겨 간 버튼을 UMX Settings 오버레이에서 대신 보여 줄 때 쓰는 표시 규칙.
    /// UMX Object 오버레이는 컨트롤을 숨기지 않고(쓰지 않으면 비활성) 항상 그리므로, 그 오버레이가 떠 있으면 숨고
    /// 닫혀 있을 때만 개편 전처럼 UMX Settings 에 나온다. 활성 여부는 UMX Object 오버레이와 같은 규칙을 따른다.
    /// </summary>
    internal static class UMXSettingsFallbackVisibility
    {
        /// <summary>
        /// 구독은 생성자가 아니라 패널에 붙을 때 건다. 오버레이는 레이아웃 전환·씬뷰 재마운트로
        /// 떼였다 다시 붙으므로, 생성자에서 한 번만 걸고 Detach 에서 풀면 재부착 이후로 영영 갱신되지 않는다.
        /// </summary>
        public static void Install(VisualElement element, UMXOverlayControls control)
        {
            if (element == null)
            {
                return;
            }

            void Apply()
            {
                // UMX Object 오버레이가 떠 있으면 그쪽이 이 컨트롤을 (쓰지 않을 때는 비활성으로) 항상 그리므로 여기선 숨는다.
                bool ownedByObjectOverlay = UMXOverlayContext.IsObjectOverlayDisplayed;

                // 동적 상태라 USS 클래스로는 표현할 수 없어 style.display 를 직접 설정한다.
                element.style.display = ownedByObjectOverlay ? DisplayStyle.None : DisplayStyle.Flex;

                // 지금 컨텍스트에서 쓰지 않는 컨트롤은 UMX Object 오버레이와 같이 비활성으로 보인다.
                element.SetEnabled(UMXOverlayContext.IsVisible(control));
            }

            element.RegisterCallback<AttachToPanelEvent>(_ =>
            {
                // 오버레이 표시 상태(ObjectOverlayDisplayChanged)와 컨트롤별 컨텍스트 가시성(Changed) 둘 다 본다.
                UMXOverlayContext.ObjectOverlayDisplayChanged -= Apply;
                UMXOverlayContext.ObjectOverlayDisplayChanged += Apply;
                UMXOverlayContext.Changed -= Apply;
                UMXOverlayContext.Changed += Apply;
                Apply();
            });

            element.RegisterCallback<DetachFromPanelEvent>(_ =>
            {
                UMXOverlayContext.ObjectOverlayDisplayChanged -= Apply;
                UMXOverlayContext.Changed -= Apply;
            });

            Apply();
        }
    }

    /// <summary>
    /// UMX Settings 오버레이가 쓰는 Coordinate System 버튼.
    /// UMX Object 오버레이용 인스턴스(UMXObjectControlSet)와 동작은 같고 표시 조건만 다르므로
    /// 원본을 건드리지 않고 파생 타입에 아이디를 따로 붙인다.
    /// </summary>
    [EditorToolbarElement(ElementId)]
    public class UMXCoordinateSystemSettingFallbackButton : UMXCoordinateSystemSettingToolbarButton
    {
        public const string ElementId = "SceneView/UMX Coordinate System Setting Fallback";

        public UMXCoordinateSystemSettingFallbackButton()
        {
            UMXSettingsFallbackVisibility.Install(this, UMXOverlayControls.CoordinateSystem);
        }
    }

    /// <summary>
    /// UMX Settings 오버레이가 쓰는 Element Snap(V-Snap) 버튼.
    /// </summary>
    [EditorToolbarElement(ElementId)]
    public class UMXElementSnapSettingFallbackButton : UMXElementSnapSettingToolbarButton
    {
        public const string ElementId = "SceneView/UMX Element Snap Setting Fallback";

        public UMXElementSnapSettingFallbackButton()
        {
            UMXSettingsFallbackVisibility.Install(this, UMXOverlayControls.ElementSnap);
        }
    }
}
#endif
#endif
