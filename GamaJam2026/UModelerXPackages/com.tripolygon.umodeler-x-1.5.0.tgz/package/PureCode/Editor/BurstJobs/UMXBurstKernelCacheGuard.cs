using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Unity.Burst;
using UnityEditor;
using UnityEditor.Compilation;

namespace Tripolygon.UModelerX.Editor
{
    /// <summary>
    /// 패키지 업데이트로 버스트 커널이 IL 을 가져다 쓰는 프리컴파일 DLL 이 바뀌었을 때 버스트가 낡은 커널로 돌지 않게 합니다.
    ///
    /// 버스트는 유니티 컴파일 이벤트(BurstLoader → BurstCompiler.NotifyAssemblyCompilationFinished)로만
    /// 어셈블리 변경을 통지받아 캐시를 무효화합니다. 프리컴파일 DLL 은 컴파일 대상이 아니라 이 통지가 없어서,
    /// 진입점(이 어셈블리)이 다시 컴파일돼도 커널은 Library/BurstCache 의 옛 네이티브 코드로 돕니다.
    /// 커널 구조체 배치가 바뀌었다면 옛 코드가 엉뚱한 포인터에 써서 결과가 틀리거나 메모리가 오염됩니다.
    ///
    /// 커널이 인라인하는 어셈블리는 둘입니다 (KernelSourceAssemblies) — 커널 구조체가 있는 BurstKernels DLL 과,
    /// 3D 불린 커널이 정적 함수 IL 을 인라인하는 Editor DLL (UMXExactPredicates.Orient3D·UMXInt128·UMXLimbMath·UMXLong3·
    /// UMXBoolean3DSigns.ComputePair·UMXBoolean3DClassifier.SolidAngle·브로드페이즈 HasNaN/Overlaps/LeafStart). Editor DLL 만 바뀐 릴리스도
    /// 커널의 네이티브 코드를 바꾸므로 두 DLL 의 MVID 를 모두 Library 기록 (어셈블리 이름과 MVID 를 줄마다) 과 비교합니다.
    /// 프리컴파일 DLL 로 들어온 어셈블리만 봅니다 — 소스로 컴파일되는 어셈블리는 유니티가 직접 통지하므로 (개발 프로젝트는 둘 다 소스) 할 일이 없습니다.
    ///
    /// 두 경우로 나눠 처리합니다.
    /// - 에디터가 켜진 채 업데이트된 세션: 버스트 컴파일 서버가 재시작 전까지 옛 DLL 을 보고 있어 통지해도 소용이 없다(실측).
    ///   기록하지 않고 재시작을 안내하며, 그 세션 동안 커널은 잡에 넣지 않고 관리 코드로 직접 실행한다.
    /// - 깨끗하게 시작한 세션에서 어느 DLL 의 MVID 라도 Library 기록과 다르면: 다른 어셈블리마다 컴파일 이벤트와 같은 통지를 보내고
    ///   잡들이 함수 포인터를 다시 요청하도록 재컴파일을 한 번 요청한 뒤 모든 MVID 를 기록한다.
    /// 기록 형식은 BurstKernels MVID 한 줄이던 이전 형식에서 바뀌었다 — 이전 형식은 어느 어셈블리의 줄로도 읽히지 않아 업데이트 뒤 첫 실행에서 한 번 통지·기록될 뿐이다.
    /// 커널을 처음 실행하기 직전에 도메인당 한 번 확인합니다. 버스트 통지는 내부 API 라 리플렉션으로 부르며,
    /// 없으면 경고만 남기고 가속은 그대로 둡니다.
    /// </summary>
    [InitializeOnLoad]
    internal static class UMXBurstKernelCacheGuard
    {
        private const string StampPath = "Library/UModelerX/BurstKernelsModuleVersionId.txt";
        private const string PackageName = "com.tripolygon.umodeler-x";
        private const string PackageChangedSessionKey = "UModelerX.BurstKernels.PackageChangedThisSession";

        /// <summary>버스트 커널이 IL 을 가져다 쓰는 어셈블리 (커널 구조체의 BurstKernels, 커널이 인라인하는 정적 함수의 Editor).</summary>
        private static readonly System.Reflection.Assembly[] KernelSourceAssemblies =
        {
            typeof(IUMXSingleKernel).Assembly,
            typeof(Tripolygon.UModelerX.Editor.Boolean3D.UMXExactPredicates).Assembly,
        };

        private static bool checkedThisDomain;
        private static bool requiresManagedRun;

        /// <summary>프리컴파일 DLL 로 들어온 커널 원천 어셈블리 하나.</summary>
        private struct TrackedAssembly
        {
            public string Name;
            public string DllPath;
            public string ModuleVersionId;
        }

        static UMXBurstKernelCacheGuard()
        {
            /// 다음 업데이트부터는 패키지 등록 이벤트로 "이 세션 중에 바뀌었다"를 확실히 남깁니다.
            /// SessionState 는 도메인 리로드를 넘어 유지되고 에디터를 재시작하면 지워집니다.
            UnityEditor.PackageManager.Events.registeredPackages += OnRegisteredPackages;
        }

        /// <summary>
        /// 커널 실행 전에 부릅니다. true 면 이 세션에서는 버스트를 믿을 수 없으니 커널을 관리 코드로 직접 실행해야 합니다.
        /// </summary>
        internal static bool RequiresManagedRun()
        {
            if (checkedThisDomain == false)
            {
                checkedThisDomain = true;
                try
                {
                    requiresManagedRun = Refresh();
                }
                catch (Exception exception)
                {
                    /// 이 어셈블리는 소스로 배포되고 배포판에는 UMXLog 콘솔 출력이 없어 유니티 콘솔에 직접 남깁니다.
                    UnityEngine.Debug.LogWarning($"UModeler X: Could not check the Burst cache for kernel updates. {exception.Message}");
                }
            }
            return requiresManagedRun;
        }

        private static void OnRegisteredPackages(UnityEditor.PackageManager.PackageRegistrationEventArgs args)
        {
            foreach (var package in args.changedTo)
            {
                if (package.name == PackageName)
                {
                    SessionState.SetBool(PackageChangedSessionKey, true);
                    return;
                }
            }
        }

        /// <returns>재시작 전까지 커널을 관리 코드로 돌려야 하면 true.</returns>
        private static bool Refresh()
        {
            /// 소스로 컴파일되는 어셈블리는 프리컴파일 목록에 없고 유니티가 직접 통지하므로 빼고 봅니다 (둘 다 소스면 할 일이 없습니다).
            var tracked = FindPrecompiledKernelSources();
            if (tracked.Count == 0)
            {
                return false;
            }

            var stored = ReadStamp();
            var changed = new List<TrackedAssembly>();
            foreach (var assembly in tracked)
            {
                if (stored.TryGetValue(assembly.Name, out var storedModuleVersionId) == false || storedModuleVersionId != assembly.ModuleVersionId)
                {
                    changed.Add(assembly);
                }
            }
            if (changed.Count == 0)
            {
                return false;
            }

            if (WasUpdatedThisSession(tracked))
            {
                /// 기록하지 않습니다 — 재시작한 다음 세션에서 여기로 다시 들어와 무효화합니다.
                Notice.BurstStatusToolbar.RestartRequiredAfterUpdate = true;
                UnityEngine.Debug.LogWarning("UModeler X was updated while Unity was running. Restart Unity to finish updating Burst acceleration.");
                return true;
            }

            /// 버스트 컴파일이 꺼져 있으면 기록하지 않습니다. 다시 켰을 때 다음 도메인에서 무효화합니다.
            if (BurstCompiler.IsEnabled == false)
            {
                return false;
            }

            const BindingFlags InternalStatic = BindingFlags.Static | BindingFlags.NonPublic;
            var notifyMethod = typeof(BurstCompiler).GetMethod("NotifyAssemblyCompilationFinished", InternalStatic,
                null, new[] { typeof(string), typeof(string[]) }, null);
            var recompileMethod = typeof(BurstCompiler).GetMethod("TriggerRecompilation", InternalStatic,
                null, Type.EmptyTypes, null);

            if (notifyMethod == null || recompileMethod == null)
            {
                UnityEngine.Debug.LogWarning("UModeler X: Burst kernels were updated, but this Burst version cannot refresh its cache automatically. "
                    + "If acceleration behaves oddly, close Unity and delete the Library/BurstCache folder.");
            }
            else
            {
                /// MVID 가 바뀐 어셈블리마다 컴파일 이벤트와 같은 통지를 보내고, 재컴파일은 한 번만 요청합니다.
                foreach (var assembly in changed)
                {
                    notifyMethod.Invoke(null, new object[] { assembly.Name, Array.Empty<string>() });
                }
                recompileMethod.Invoke(null, null);
                UnityEngine.Debug.Log("UModeler X: Burst kernels were updated. Refreshing the Burst cache.");
            }

            WriteStamp(tracked);
            return false;
        }

        /// <summary>커널 원천 어셈블리 중 프리컴파일 DLL 로 들어온 것 (이름·DLL 경로·MVID). 소스로 컴파일되는 어셈블리는 빠진다.</summary>
        private static List<TrackedAssembly> FindPrecompiledKernelSources()
        {
            var tracked = new List<TrackedAssembly>();
            var precompiledPaths = CompilationPipeline.GetPrecompiledAssemblyPaths(CompilationPipeline.PrecompiledAssemblySources.UserAssembly);
            foreach (var assembly in KernelSourceAssemblies)
            {
                var name = assembly.GetName().Name;
                var dllFileName = name + ".dll";
                foreach (var path in precompiledPaths)
                {
                    if (string.Equals(Path.GetFileName(path), dllFileName, StringComparison.OrdinalIgnoreCase))
                    {
                        tracked.Add(new TrackedAssembly
                        {
                            Name = name,
                            DllPath = path,
                            ModuleVersionId = assembly.ManifestModule.ModuleVersionId.ToString(),
                        });
                        break;
                    }
                }
            }
            return tracked;
        }

        /// <summary>
        /// Library 기록 (줄마다 "어셈블리 이름 MVID") 을 읽는다. 기록이 없거나 이름이 없는 줄 (BurstKernels MVID 한 줄이던 이전 형식) 은 비어 있는 것으로 본다.
        /// </summary>
        private static Dictionary<string, string> ReadStamp()
        {
            var stored = new Dictionary<string, string>(StringComparer.Ordinal);
            if (File.Exists(StampPath) == false)
            {
                return stored;
            }
            foreach (var line in File.ReadAllLines(StampPath))
            {
                var text = line.Trim();
                var separator = text.IndexOf(' ');
                if (separator <= 0)
                {
                    continue;
                }
                stored[text.Substring(0, separator)] = text.Substring(separator + 1).Trim();
            }
            return stored;
        }

        /// <summary>프리컴파일로 들어온 커널 원천 어셈블리의 MVID 를 모두 기록한다 (줄마다 "어셈블리 이름 MVID").</summary>
        private static void WriteStamp(List<TrackedAssembly> tracked)
        {
            var lines = new string[tracked.Count];
            for (var i = 0; i < tracked.Count; i++)
            {
                lines[i] = tracked[i].Name + " " + tracked[i].ModuleVersionId;
            }
            Directory.CreateDirectory(Path.GetDirectoryName(StampPath));
            File.WriteAllLines(StampPath, lines);
        }

        /// <summary>
        /// 이 에디터 프로세스가 켜진 뒤에 커널 원천 DLL 이 바뀌었는지.
        /// 패키지 등록 이벤트 기록이 있으면 그걸 믿고, 없으면(이 가드가 없던 버전에서 올라온 경우)
        /// 프리컴파일 DLL 중 하나라도 프로세스 시작 이후에 쓰였는지로 판별합니다(패키지 설치가 파일을 새로 씁니다).
        /// </summary>
        private static bool WasUpdatedThisSession(List<TrackedAssembly> tracked)
        {
            if (SessionState.GetBool(PackageChangedSessionKey, false))
            {
                return true;
            }
            var processStartUtc = System.Diagnostics.Process.GetCurrentProcess().StartTime.ToUniversalTime();
            foreach (var assembly in tracked)
            {
                if (File.GetLastWriteTimeUtc(assembly.DllPath) > processStartUtc)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
