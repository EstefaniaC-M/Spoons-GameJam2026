﻿using UnityEditor;
using System;
using System.Reflection;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    using Tripolygon.UModeler.UI;
#if UNITY_2021_2_OR_NEWER
    using UnityEditor.Toolbars;
    using UnityEngine.UIElements;
    [EditorToolbarElement("SceneView/UMX Coordinate System Setting")]
    public class UMXCoordinateSystemSettingToolbarButton : EditorToolbarDropdown
    {
        private const string SwitchShortcutID = "UModeler X/Transform/Switch Coordinate System";

        MethodInfo repaintMethod;

        public UMXCoordinateSystemSettingToolbarButton()
        {
            var toolbarType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.Toolbar");
            repaintMethod = toolbarType.GetMethod("RepaintToolbar", BindingFlags.NonPublic | BindingFlags.Static);
            var dropdown = new UMXCoordinateSystemSettingToolbarDropdown(this);

            // 메뉴 대상을 클릭 시점에 지정한다. 생성자에서만 잡으면 나중에 만들어진 인스턴스
            // (UMX Object 오버레이 / UMX Settings 폴백)가 앞의 것을 덮어쓴다.
            this.clicked += () => UMXCoordinateSystemSettingToolbarDropdown.ShowDropdown(this);
            Tools.pivotRotationChanged -= OnPivotRotationChanged;
            Tools.pivotRotationChanged += OnPivotRotationChanged;
            // UMXObjectControlSet.Build() 가 오버레이 레이아웃 전환·호스트 전환·씬뷰 마운트마다 반복 호출되어
            // 인스턴스가 계속 생성된다 — 해제하지 않으면 Tools.pivotRotationChanged 구독이 인스턴스 수만큼 누적된다.
            RegisterCallback<DetachFromPanelEvent>(_ => Dispose());
            // 단축키(Switch Coordinate System) 등 드롭다운 밖에서 바뀐 좌표계도 표시에 반영한다.
            // 다시 붙을 때 구독이 살아나도록 Attach/Detach 쌍으로 구독한다.
            RegisterCallback<AttachToPanelEvent>(_ => OnAttachToPanel());
            EditorApplication.update += Init;

        }

        private void Init()
        {
            this.text = UMXCoordinateSystemSettingToolbarDropdown.GetDisplayName(CoordinateSystemSetting.CoordinateSystem);
            this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), Enum.GetName(typeof(UMXCoordinateSystem), CoordinateSystemSetting.CoordinateSystem));
            RefreshTooltip();
            EditorApplication.update -= Init;
        }

        /// 순환 단축키(Switch Coordinate System)는 다른 오버레이 버튼처럼 둘째 줄에 동작 이름과 함께 적는다.
        private void RefreshTooltip()
        {
            var text = UMXLocalization.Tr("UModelerX Coordinate System");
            var shortcut = UMXShortcutQuery.GetTooltipBindingText(SwitchShortcutID);
            this.tooltip = string.IsNullOrEmpty(shortcut)
                ? text
                : $"{text}\n{UMXLocalization.Tr("Switch Coordinate System")}: {shortcut}";
        }

        private void OnShortcutChanged(object sender, EventArgs e)
        {
            RefreshTooltip();
        }

        private void OnAttachToPanel()
        {
            CoordinateSystemSetting.PropertyChanged -= OnCoordinateSystemSettingChanged;
            CoordinateSystemSetting.PropertyChanged += OnCoordinateSystemSettingChanged;
            // 단축키를 바꾸면 툴팁의 키 표기가 달라진다.
            UMXShortcutQuery.Changed -= OnShortcutChanged;
            UMXShortcutQuery.Changed += OnShortcutChanged;
            // 떨어져 있는 동안 바뀐 값은 생성 때와 같이 다음 업데이트에 다시 읽는다.
            EditorApplication.update -= Init;
            EditorApplication.update += Init;
        }

        private void OnCoordinateSystemSettingChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(CoordinateSystemSetting.CoordinateSystem))
            {
                return;
            }
            RefreshCoordinateSystem();
        }

        private void RefreshCoordinateSystem()
        {
            this.text = UMXCoordinateSystemSettingToolbarDropdown.GetDisplayName(CoordinateSystemSetting.CoordinateSystem);
            this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), Enum.GetName(typeof(UMXCoordinateSystem), CoordinateSystemSetting.CoordinateSystem));
        }

        public void Dispose()
        {
            Tools.pivotRotationChanged -= OnPivotRotationChanged;
            CoordinateSystemSetting.PropertyChanged -= OnCoordinateSystemSettingChanged;
            UMXShortcutQuery.Changed -= OnShortcutChanged;
        }
        // UNITY_2021_2_OR_NEWER
#elif UNITY_2020_1_OR_NEWER
    public class UMXCoordinateSystemSettingToolbarButton : ToolbarDropdownButton
    {
        Type toolbarType;
        MethodInfo repaintMethod;
        private PivotRotation editorPivot;

        public UMXCoordinateSystemSettingToolbarButton() : base()
        {
            toolbarType = typeof(UnityEditor.Editor).Assembly.GetType("UnityEditor.Toolbar");
            repaintMethod = toolbarType.GetMethod("RepaintToolbar", BindingFlags.NonPublic | BindingFlags.Static);
            this.text = UMXCoordinateSystemSettingToolbarDropdown.GetDisplayName(CoordinateSystemSetting.CoordinateSystem);
            editorPivot = Tools.pivotRotation;
            UMXCoordinateSystemSettingToolbarDropdown dropdown = new UMXCoordinateSystemSettingToolbarDropdown(this);
            onClicked += UMXCoordinateSystemSettingToolbarDropdown.ShowDropdown;
        }

        public override void Render(Rect rect)
        {
            // Tools pivotRotation 변경 확인
            if (editorPivot != Tools.pivotRotation)
            {
                editorPivot = Tools.pivotRotation;
                OnPivotRotationChanged();
            }

            base.Render(rect);
        }
#endif //UNITY_2020_1_OR_NEWER

        // 2020, 2021.2 ~ 6 공유 메소드
        private void OnPivotRotationChanged()
        {
            if (Tools.pivotRotation == PivotRotation.Global)
            {
                CoordinateSystemSetting.CoordinateSystem = UMXCoordinateSystem.Global;
                this.text = UMXCoordinateSystemSettingToolbarDropdown.GetDisplayName(UMXCoordinateSystem.Global);
                this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), nameof(UMXCoordinateSystem.Global));
            }
            else if (Tools.pivotRotation == PivotRotation.Local)
            {
                CoordinateSystemSetting.CoordinateSystem = UMXCoordinateSystem.Local;
                this.text = UMXCoordinateSystemSettingToolbarDropdown.GetDisplayName(UMXCoordinateSystem.Local);
                this.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), nameof(UMXCoordinateSystem.Local));
            }
            repaintMethod?.Invoke(null, null);
        }
    }
}
