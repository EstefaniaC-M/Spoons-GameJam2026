﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

using System;
using System.Runtime.InteropServices;

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// Port 의 모든 배열이 쓰는 비관리 메모리 버퍼 (std::vector 대신, 버스트 호환).
    /// 포인터와 길이만 가진 구조체라 버스트 잡의 필드로 그대로 넘길 수 있다.
    /// 구조체를 복사하면 같은 메모리를 가리키므로, 해제는 소유한 쪽 변수에서 한 번만 한다.
    /// </summary>
    public unsafe struct OsdBuffer<T> where T : unmanaged
    {
        public T* Ptr;
        public int Length;

        /// <summary>메모리를 가지고 있는가. 길이 0 버퍼는 메모리가 없어 false 다.</summary>
        public bool IsCreated
        {
            get { return Ptr != null; }
        }

        /// <summary>0 으로 채운 버퍼를 만든다. 길이가 0 이면 Ptr 은 null 이다. 관리 코드 전용 (버스트 함수 안에서 부르지 않는다).</summary>
        public static OsdBuffer<T> Allocate(int length)
        {
            if (length < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(length), "OsdBuffer length must not be negative.");
            }

            OsdBuffer<T> buffer = default;
            if (length == 0)
            {
                return buffer;
            }

            long byteCount = (long)length * sizeof(T);
            buffer.Ptr = (T*)Marshal.AllocHGlobal(new IntPtr(byteCount));
            buffer.Length = length;

            // AllocHGlobal 은 0 으로 채워 주지 않는다. Span 길이가 int 라 1GB 씩 나눠 지운다.
            const int chunkBytes = 1 << 30;
            byte* cursor = (byte*)buffer.Ptr;
            long remaining = byteCount;
            while (remaining > 0)
            {
                int size = (int)Math.Min(remaining, chunkBytes);
                new Span<byte>(cursor, size).Clear();
                cursor += size;
                remaining -= size;
            }
            return buffer;
        }

        /// <summary>메모리를 해제한다. 같은 변수에서 두 번 불러도 안전하다.</summary>
        public void Free()
        {
            if (Ptr != null)
            {
                Marshal.FreeHGlobal(new IntPtr(Ptr));
            }
            Ptr = null;
            Length = 0;
        }
    }

    /// <summary>연속 메모리의 int 구간 (포인터 + 개수). vtr/array.h 의 Array&lt;int&gt;/ConstArray&lt;int&gt; 에 해당한다.</summary>
    public unsafe struct OsdRange
    {
        public int* Ptr;
        public int Count;
    }

    /// <summary>연속 메모리의 ushort 구간 (포인터 + 개수). vtr/array.h 의 Array&lt;LocalIndex&gt; 에 해당한다.</summary>
    public unsafe struct OsdLocalRange
    {
        public ushort* Ptr;
        public int Count;
    }
}
