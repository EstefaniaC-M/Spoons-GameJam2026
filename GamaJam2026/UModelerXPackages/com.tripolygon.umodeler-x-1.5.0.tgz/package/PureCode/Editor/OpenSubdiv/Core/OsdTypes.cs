﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>vtr/types.h 와 sdc/crease.h 의 상수.</summary>
    public static class OsdConstants
    {
        /// <summary>무효 인덱스 (Vtr::INDEX_INVALID).</summary>
        public const int IndexInvalid = -1;

        /// <summary>정점 밸런스(valence)·페이스 크기의 상한 (Vtr::VALENCE_LIMIT, LocalIndex 의 최대값).</summary>
        public const int ValenceLimit = 0xFFFF;

        /// <summary>매끄러운 샤프니스 (Sdc::Crease::SHARPNESS_SMOOTH).</summary>
        public const float SharpnessSmooth = 0.0f;

        /// <summary>무한 샤프니스 (Sdc::Crease::SHARPNESS_INFINITE).</summary>
        public const float SharpnessInfinite = 10.0f;
    }

    /// <summary>
    /// 정점 경계 보간 (Sdc::Options::VtxBoundaryInterpolation).
    /// OpenSubdivOptions.VtxBoundaryInterpolation 과 같은 값이다. VTX_BOUNDARY_NONE(0) 은 쓰지 않는다.
    /// </summary>
    public enum OsdBoundaryInterpolation
    {
        EdgeOnly = 1,
        EdgeAndCorner = 2,
    }

    /// <summary>
    /// FVar(UV) 선형 보간 (Sdc::Options::FVarLinearInterpolation).
    /// OpenSubdivOptions.FVarLinearInterpolation 과 같은 값이다.
    /// </summary>
    public enum OsdFVarLinearInterpolation
    {
        None = 0,
        CornersOnly = 1,
        CornersPlus1 = 2,
        CornersPlus2 = 3,
        Boundaries = 4,
        All = 5,
    }

    /// <summary>정점 규칙 (Sdc::Crease::Rule). 값은 원본의 비트값 그대로다.</summary>
    public enum OsdRule : byte
    {
        Unknown = 0,
        Smooth = 1,
        Dart = 2,
        Crease = 4,
        Corner = 8,
    }

    /// <summary>레벨 0 생성·분할이 입력을 거절한 사유. 원본의 거절 조건과 같은 조건에서만 쓴다.</summary>
    public enum OsdStatus
    {
        Ok = 0,
        NoVertices,
        NoFaces,
        FaceTooLarge,
        ValenceOverflow,
        EmptyFVarChannel,
        InvalidInput,
    }
}
