﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 균일 쿼드 분할 (vtr/refinement.cpp 의 Refinement::refine 균일 경로 + vtr/quadRefinement.cpp 의 QuadRefinement, Catmark 전용).
    /// AllocateChild(관리 코드)가 원본의 크기 추정식으로 자식 레벨·분할 버퍼를 미리 할당하고(원본의 resize 를 대신한다),
    /// RefineTopology(버스트 호환)가 채운다. 자식 정점 순서는 정점 자식 → 페이스 자식 → 엣지 자식(orderVerticesFromFacesFirst = false)이다.
    /// 희소(sparse) 선택, semi-sharp 샤프니스 감쇠·재분류(reclassifySemisharpVertices), 삼각 분할(TriRefinement)은 옮기지 않았다:
    /// 래퍼는 균일 분할만 하고, 사용자 크리스가 없어 샤프니스는 0 또는 무한뿐이다.
    /// </summary>
    public static unsafe class OsdQuadRefiner
    {
        /// <summary>Catmark 의 정규 페이스 크기 (Refinement::_regFaceSize).</summary>
        private const int RegularFaceSize = 4;

        /// <summary>
        /// 자식 레벨과 분할 버퍼를 할당한다 (Refinement 생성자 + 각 단계의 resize). 관리 코드다.
        /// 크기는 부모 배열 길이로 정해진다: 자식 페이스 = |FaceVertIndices|, 자식 엣지 = 2E + |FaceVertIndices|, 자식 정점 = F + E + V,
        /// 엣지-페이스 = 2|FaceVertIndices| + 2|EdgeFaceIndices|, 정점-페이스 = |FaceVertIndices| + 2|EdgeFaceIndices| + |VertFaceIndices|,
        /// 정점-엣지 = |FaceVertIndices| + |EdgeFaceIndices| + 2E + |VertEdgeIndices| (quadRefinement.cpp 의 추정식).
        /// 부모는 여섯 관계를 다 가진 레벨이어야 한다 (레벨 0 또는 fullTopology 로 분할한 레벨).
        /// fullTopology == false(마지막 레벨)면 페이스-정점과 — hasFVar 면 — 정점-페이스만 할당한다. 태그·샤프니스·매핑은 늘 할당한다.
        /// </summary>
        public static void AllocateChild(in OsdLevel parent, bool fullTopology, bool hasFVar, out OsdLevel child, out OsdRefinement refinement)
        {
            child = default;
            refinement = default;

            int faceVertTotal = parent.FaceVertIndices.Length;
            int childFaceCount = faceVertTotal;
            int childEdgeCount = 2 * parent.EdgeCount + faceVertTotal;
            int childVertCount = parent.FaceCount + parent.EdgeCount + parent.VertCount;

            // Refinement 생성자: 자식 깊이
            child.Depth = parent.Depth + 1;

            // QuadRefinement::allocateParentChildIndices
            refinement.FaceChildFaceIndices = OsdBuffer<int>.Allocate(faceVertTotal);
            refinement.FaceChildEdgeIndices = OsdBuffer<int>.Allocate(parent.FaceEdgeIndices.Length);
            refinement.EdgeChildEdgeIndices = OsdBuffer<int>.Allocate(parent.EdgeVertIndices.Length);
            refinement.FaceChildVertIndex = OsdBuffer<int>.Allocate(parent.FaceCount);
            refinement.EdgeChildVertIndex = OsdBuffer<int>.Allocate(parent.EdgeCount);
            refinement.VertChildVertIndex = OsdBuffer<int>.Allocate(parent.VertCount);

            // populateChildToParentMapping
            refinement.ChildFaceParentIndex = OsdBuffer<int>.Allocate(childFaceCount);
            refinement.ChildFaceTags = OsdBuffer<byte>.Allocate(childFaceCount);
            refinement.ChildEdgeParentIndex = OsdBuffer<int>.Allocate(childEdgeCount);
            refinement.ChildEdgeTags = OsdBuffer<byte>.Allocate(childEdgeCount);
            refinement.ChildVertexParentIndex = OsdBuffer<int>.Allocate(childVertCount);
            refinement.ChildVertexTags = OsdBuffer<byte>.Allocate(childVertCount);

            // propagateComponentTags, subdivideSharpnessValues — 모든 레벨
            child.FaceTags = OsdBuffer<byte>.Allocate(childFaceCount);
            child.EdgeTags = OsdBuffer<byte>.Allocate(childEdgeCount);
            child.VertTags = OsdBuffer<ushort>.Allocate(childVertCount);
            child.EdgeSharpness = OsdBuffer<float>.Allocate(childEdgeCount);
            child.VertSharpness = OsdBuffer<float>.Allocate(childVertCount);

            // subdivideTopology — 페이스-정점은 늘 만든다
            child.FaceVertCountsAndOffsets = OsdBuffer<int>.Allocate(2 * childFaceCount);
            child.FaceVertIndices = OsdBuffer<int>.Allocate(4 * childFaceCount);

            if (fullTopology)
            {
                child.FaceEdgeIndices = OsdBuffer<int>.Allocate(4 * childFaceCount);
                child.EdgeVertIndices = OsdBuffer<int>.Allocate(2 * childEdgeCount);

                int edgeFaceEstimate = 2 * faceVertTotal + 2 * parent.EdgeFaceIndices.Length;
                child.EdgeFaceCountsAndOffsets = OsdBuffer<int>.Allocate(2 * childEdgeCount);
                child.EdgeFaceIndices = OsdBuffer<int>.Allocate(edgeFaceEstimate);
                child.EdgeFaceLocalIndices = OsdBuffer<ushort>.Allocate(edgeFaceEstimate);

                int vertEdgeEstimate = faceVertTotal + parent.EdgeFaceIndices.Length + 2 * parent.EdgeCount + parent.VertEdgeIndices.Length;
                child.VertEdgeCountsAndOffsets = OsdBuffer<int>.Allocate(2 * childVertCount);
                child.VertEdgeIndices = OsdBuffer<int>.Allocate(vertEdgeEstimate);
                child.VertEdgeLocalIndices = OsdBuffer<ushort>.Allocate(vertEdgeEstimate);
            }

            // FVar 분할은 마지막 레벨에서도 정점-페이스가 필요하다 (Refinement::refine 의 optionallyRefineFVar)
            if (fullTopology || hasFVar)
            {
                int vertFaceEstimate = faceVertTotal + 2 * parent.EdgeFaceIndices.Length + parent.VertFaceIndices.Length;
                child.VertFaceCountsAndOffsets = OsdBuffer<int>.Allocate(2 * childVertCount);
                child.VertFaceIndices = OsdBuffer<int>.Allocate(vertFaceEstimate);
                child.VertFaceLocalIndices = OsdBuffer<ushort>.Allocate(vertFaceEstimate);
            }
        }

        /// <summary>
        /// Refinement::refine 의 균일 경로. 버스트 호환 (포인터·blittable 만, 할당·예외 없음).
        /// data 의 Parent 는 다 만든 레벨, Child·Refinement 는 AllocateChild 결과여야 한다. 자식 개수를 정하고, 부모→자식·자식→부모 매핑,
        /// 자식 태그, 관계(FullTopology 면 여섯, 아니면 페이스-정점 + HasFVar 면 정점-페이스), 샤프니스를 채운다.
        /// 정점-페이스·정점-엣지·엣지-페이스 버퍼는 채운 뒤 실제 길이로 Length 를 줄인다 (메모리는 그대로 — Free 가 블록 전체를 푼다).
        /// </summary>
        public static void RefineTopology(OsdRefineLevelData* data)
        {
            OsdLevel* parent = &data->Parent;
            OsdLevel* child = &data->Child;
            OsdRefinement* refinement = &data->Refinement;

            bool fullTopology = data->FullTopology != 0;
            bool refineFVar = data->HasFVar != 0;

            // 부모→자식·자식→부모 매핑과 태그
            PopulateParentChildIndices(parent, refinement);
            InitializeChildComponentCounts(child, refinement);
            PopulateChildToParentMapping(parent, refinement);
            PropagateComponentTags(parent, child, refinement);

            // 토폴로지: minimalTopology 면 페이스-정점만, FVar 가 있으면 정점-페이스도
            SubdivideTopology(parent, child, refinement, fullTopology, fullTopology || refineFVar);

            // 샤프니스 (semi-sharp 재분류는 semi-sharp 가 없어 할 일이 없다)
            SubdivideEdgeSharpness(child, refinement);
            SubdivideVertexSharpness(child, refinement);

            data->Status = (int)OsdStatus.Ok;
        }

        // ------------------------------------------------------------------
        // 부모 → 자식 매핑 (Refinement::populateParentChildIndices, 균일)
        // ------------------------------------------------------------------

        private static void PopulateParentChildIndices(OsdLevel* parent, OsdRefinement* refinement)
        {
            // 자식 페이스·엣지
            refinement->ChildFaceFromFaceCount = SequenceFullIndexVector(refinement->FaceChildFaceIndices, 0);
            refinement->ChildEdgeFromFaceCount = SequenceFullIndexVector(refinement->FaceChildEdgeIndices, 0);
            refinement->ChildEdgeFromEdgeCount = SequenceFullIndexVector(refinement->EdgeChildEdgeIndices, refinement->ChildEdgeFromFaceCount);

            // 자식 정점: 정점 자식 → 페이스 자식 → 엣지 자식
            refinement->FirstChildVertFromVert = 0;
            refinement->ChildVertFromVertCount = SequenceFullIndexVector(refinement->VertChildVertIndex, refinement->FirstChildVertFromVert);

            refinement->FirstChildVertFromFace = refinement->FirstChildVertFromVert + refinement->ChildVertFromVertCount;
            refinement->ChildVertFromFaceCount = SequenceFullIndexVector(refinement->FaceChildVertIndex, refinement->FirstChildVertFromFace);

            refinement->FirstChildVertFromEdge = refinement->FirstChildVertFromFace + refinement->ChildVertFromFaceCount;
            refinement->ChildVertFromEdgeCount = SequenceFullIndexVector(refinement->EdgeChildVertIndex, refinement->FirstChildVertFromEdge);
        }

        /// <summary>baseValue 부터 차례로 번호를 매기고 개수를 돌려준다.</summary>
        private static int SequenceFullIndexVector(OsdBuffer<int> indexVector, int baseValue)
        {
            int indexCount = indexVector.Length;
            for (int i = 0; i < indexCount; ++i)
            {
                indexVector.Ptr[i] = baseValue++;
            }
            return indexCount;
        }

        /// <summary>Refinement::initializeChildComponentCounts.</summary>
        private static void InitializeChildComponentCounts(OsdLevel* child, OsdRefinement* refinement)
        {
            child->FaceCount = refinement->ChildFaceFromFaceCount;
            child->EdgeCount = refinement->ChildEdgeFromFaceCount + refinement->ChildEdgeFromEdgeCount;
            child->VertCount = refinement->ChildVertFromFaceCount + refinement->ChildVertFromEdgeCount + refinement->ChildVertFromVertCount;
        }

        // ------------------------------------------------------------------
        // 자식 → 부모 매핑 (Refinement::populateChildToParentMapping, 균일)
        // ------------------------------------------------------------------

        /// <summary>initialChildTags[0][indexInParent]: 완전(incomplete 0), 부모 종류 0, 부모 안 위치.</summary>
        private static byte CompleteChildTag(int indexInParent)
        {
            return (byte)(indexInParent << OsdChildTag.IndexInParentShift);
        }

        private static void PopulateChildToParentMapping(OsdLevel* parent, OsdRefinement* refinement)
        {
            PopulateFaceParentFromParentFaces(parent, refinement);

            PopulateEdgeParentFromParentFaces(parent, refinement);
            PopulateEdgeParentFromParentEdges(parent, refinement);

            // 균일 분할: 정점 태그는 모두 "완전한 유일한 자식"(initialChildTags[0][0])으로 시작한다
            for (int cVert = 0; cVert < refinement->ChildVertexTags.Length; ++cVert)
            {
                refinement->ChildVertexTags.Ptr[cVert] = CompleteChildTag(0);
            }
            PopulateVertexParentFromParentFaces(parent, refinement);
            PopulateVertexParentFromParentEdges(parent, refinement);
            PopulateVertexParentFromParentVertices(parent, refinement);
        }

        private static void PopulateFaceParentFromParentFaces(OsdLevel* parent, OsdRefinement* refinement)
        {
            int cFace = 0;
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange cFaces = refinement->GetFaceChildFaces(*parent, pFace);
                if (cFaces.Count == 4)
                {
                    refinement->ChildFaceTags.Ptr[cFace + 0] = CompleteChildTag(0);
                    refinement->ChildFaceTags.Ptr[cFace + 1] = CompleteChildTag(1);
                    refinement->ChildFaceTags.Ptr[cFace + 2] = CompleteChildTag(2);
                    refinement->ChildFaceTags.Ptr[cFace + 3] = CompleteChildTag(3);

                    refinement->ChildFaceParentIndex.Ptr[cFace + 0] = pFace;
                    refinement->ChildFaceParentIndex.Ptr[cFace + 1] = pFace;
                    refinement->ChildFaceParentIndex.Ptr[cFace + 2] = pFace;
                    refinement->ChildFaceParentIndex.Ptr[cFace + 3] = pFace;

                    cFace += 4;
                }
                else
                {
                    bool childTooLarge = cFaces.Count > 4;
                    for (int i = 0; i < cFaces.Count; ++i, ++cFace)
                    {
                        refinement->ChildFaceTags.Ptr[cFace] = CompleteChildTag(childTooLarge ? 0 : i);
                        refinement->ChildFaceParentIndex.Ptr[cFace] = pFace;
                    }
                }
            }
        }

        private static void PopulateEdgeParentFromParentFaces(OsdLevel* parent, OsdRefinement* refinement)
        {
            int cEdge = 0;
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange cEdges = refinement->GetFaceChildEdges(*parent, pFace);
                if (cEdges.Count == 4)
                {
                    refinement->ChildEdgeTags.Ptr[cEdge + 0] = CompleteChildTag(0);
                    refinement->ChildEdgeTags.Ptr[cEdge + 1] = CompleteChildTag(1);
                    refinement->ChildEdgeTags.Ptr[cEdge + 2] = CompleteChildTag(2);
                    refinement->ChildEdgeTags.Ptr[cEdge + 3] = CompleteChildTag(3);

                    refinement->ChildEdgeParentIndex.Ptr[cEdge + 0] = pFace;
                    refinement->ChildEdgeParentIndex.Ptr[cEdge + 1] = pFace;
                    refinement->ChildEdgeParentIndex.Ptr[cEdge + 2] = pFace;
                    refinement->ChildEdgeParentIndex.Ptr[cEdge + 3] = pFace;

                    cEdge += 4;
                }
                else
                {
                    bool childTooLarge = cEdges.Count > 4;
                    for (int i = 0; i < cEdges.Count; ++i, ++cEdge)
                    {
                        refinement->ChildEdgeTags.Ptr[cEdge] = CompleteChildTag(childTooLarge ? 0 : i);
                        refinement->ChildEdgeParentIndex.Ptr[cEdge] = pFace;
                    }
                }
            }
        }

        private static void PopulateEdgeParentFromParentEdges(OsdLevel* parent, OsdRefinement* refinement)
        {
            // 엣지 자식 엣지는 페이스 자식 엣지 뒤에서 시작한다 (getFirstChildEdgeFromEdges)
            int cEdge = refinement->ChildEdgeFromFaceCount;
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge, cEdge += 2)
            {
                refinement->ChildEdgeTags.Ptr[cEdge + 0] = CompleteChildTag(0);
                refinement->ChildEdgeTags.Ptr[cEdge + 1] = CompleteChildTag(1);

                refinement->ChildEdgeParentIndex.Ptr[cEdge + 0] = pEdge;
                refinement->ChildEdgeParentIndex.Ptr[cEdge + 1] = pEdge;
            }
        }

        private static void PopulateVertexParentFromParentFaces(OsdLevel* parent, OsdRefinement* refinement)
        {
            if (refinement->ChildVertFromFaceCount == 0)
            {
                return;
            }

            int cVert = refinement->FirstChildVertFromFace;
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace, ++cVert)
            {
                refinement->ChildVertexParentIndex.Ptr[cVert] = pFace;
            }
        }

        private static void PopulateVertexParentFromParentEdges(OsdLevel* parent, OsdRefinement* refinement)
        {
            int cVert = refinement->FirstChildVertFromEdge;
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge, ++cVert)
            {
                refinement->ChildVertexParentIndex.Ptr[cVert] = pEdge;
            }
        }

        private static void PopulateVertexParentFromParentVertices(OsdLevel* parent, OsdRefinement* refinement)
        {
            int cVert = refinement->FirstChildVertFromVert;
            for (int pVert = 0; pVert < parent->VertCount; ++pVert, ++cVert)
            {
                refinement->ChildVertexParentIndex.Ptr[cVert] = pVert;
            }
        }

        // ------------------------------------------------------------------
        // 태그 전파 (Refinement::propagateComponentTags, 균일)
        // ------------------------------------------------------------------

        private static void PropagateComponentTags(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // 페이스 자식 페이스는 부모 페이스 태그를 물려받는다
            for (int cFace = 0; cFace < refinement->ChildFaceFromFaceCount; ++cFace)
            {
                child->FaceTags.Ptr[cFace] = parent->FaceTags.Ptr[refinement->ChildFaceParentIndex.Ptr[cFace]];
            }

            // 페이스 자식 엣지는 늘 매끈한 내부 엣지, 엣지 자식 엣지는 부모 엣지 태그를 물려받는다
            for (int cEdge = 0; cEdge < refinement->ChildEdgeFromFaceCount; ++cEdge)
            {
                child->EdgeTags.Ptr[cEdge] = 0;
            }
            int cEdgeBegin = refinement->ChildEdgeFromFaceCount;
            int cEdgeEnd = cEdgeBegin + refinement->ChildEdgeFromEdgeCount;
            for (int cEdge = cEdgeBegin; cEdge < cEdgeEnd; ++cEdge)
            {
                child->EdgeTags.Ptr[cEdge] = parent->EdgeTags.Ptr[refinement->ChildEdgeParentIndex.Ptr[cEdge]];
            }

            PopulateVertexTagsFromParentFaces(parent, child, refinement);
            PopulateVertexTagsFromParentEdges(parent, child, refinement);
            PopulateVertexTagsFromParentVertices(parent, child, refinement);
        }

        /// <summary>
        /// 페이스 자식 정점은 늘 매끈한(Smooth) 정점이다. 레벨 0 은 N 각형 페이스가 있을 수 있어, 쿼드가 아닌 페이스의 중심 정점은 Xordinary 다.
        /// </summary>
        private static void PopulateVertexTagsFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            if (refinement->ChildVertFromFaceCount == 0)
            {
                return;
            }

            ushort vTag = OsdVTag.SetRule(0, OsdRule.Smooth);

            int cVert = refinement->FirstChildVertFromFace;
            int cVertEnd = cVert + refinement->ChildVertFromFaceCount;

            if (parent->Depth > 0)
            {
                for (; cVert < cVertEnd; ++cVert)
                {
                    child->VertTags.Ptr[cVert] = vTag;
                }
            }
            else
            {
                for (; cVert < cVertEnd; ++cVert)
                {
                    child->VertTags.Ptr[cVert] = vTag;

                    int pFace = refinement->ChildVertexParentIndex.Ptr[cVert];
                    if (parent->FaceVertCountsAndOffsets.Ptr[2 * pFace] != RegularFaceSize)
                    {
                        child->VertTags.Ptr[cVert] |= OsdVTag.Xordinary;
                    }
                }
            }
        }

        /// <summary>엣지 자식 정점은 빈 태그에서 부모 엣지 속성만 옮긴다. 샤프한 엣지면 Crease, 아니면 Smooth.</summary>
        private static void PopulateVertexTagsFromParentEdges(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge)
            {
                int cVert = refinement->EdgeChildVertIndex.Ptr[pEdge];

                byte pEdgeTag = parent->EdgeTags.Ptr[pEdge];
                bool nonManifold = (pEdgeTag & OsdETag.NonManifold) != 0;
                bool boundary = (pEdgeTag & OsdETag.Boundary) != 0;
                bool semiSharp = (pEdgeTag & OsdETag.SemiSharp) != 0;
                bool infSharp = (pEdgeTag & OsdETag.InfSharp) != 0;

                ushort vTag = 0;
                if (nonManifold)
                {
                    vTag |= OsdVTag.NonManifold;
                }
                if (boundary)
                {
                    vTag |= OsdVTag.Boundary;
                }
                if (semiSharp)
                {
                    vTag |= OsdVTag.SemiSharpEdges;
                }
                if (infSharp)
                {
                    vTag |= OsdVTag.InfSharpEdges;
                    vTag |= OsdVTag.InfSharpCrease;
                }
                if (infSharp && nonManifold)
                {
                    vTag |= OsdVTag.InfIrregular;
                }
                vTag = OsdVTag.SetRule(vTag, (semiSharp || infSharp) ? OsdRule.Crease : OsdRule.Smooth);

                child->VertTags.Ptr[cVert] = vTag;
            }
        }

        /// <summary>정점 자식 정점은 부모 정점 태그를 물려받고, 레벨 0 전용인 IncidIrregFace 만 지운다.</summary>
        private static void PopulateVertexTagsFromParentVertices(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            int cVert = refinement->FirstChildVertFromVert;
            int cVertEnd = cVert + refinement->ChildVertFromVertCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                ushort pTag = parent->VertTags.Ptr[refinement->ChildVertexParentIndex.Ptr[cVert]];
                child->VertTags.Ptr[cVert] = (ushort)(pTag & ~OsdVTag.IncidIrregFace);
            }
        }

        // ------------------------------------------------------------------
        // 토폴로지 분할 (Refinement::subdivideTopology + QuadRefinement::populate*Relation)
        // 균일 분할이라 모든 자식 인덱스가 유효하다 — 원본의 IndexIsValid 검사(희소 분할용)는 옮기지 않았다.
        // ------------------------------------------------------------------

        private static void SubdivideTopology(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement, bool fullTopology, bool vertexFaces)
        {
            PopulateFaceVertexRelation(parent, child, refinement);
            if (fullTopology)
            {
                PopulateFaceEdgeRelation(parent, child, refinement);
                PopulateEdgeVertexRelation(parent, child, refinement);
                PopulateEdgeFaceRelation(parent, child, refinement);
            }
            if (vertexFaces)
            {
                PopulateVertexFaceRelation(parent, child, refinement);
            }
            if (fullTopology)
            {
                PopulateVertexEdgeRelation(parent, child, refinement);
            }

            // 관계와 무관한 최대 밸런스 (쿼드 분할). 정점-엣지를 채우며 갱신한 값도 여기서 덮어쓴다 (원본과 같다)
            child->MaxValence = Max(parent->MaxValence, 4);
            child->MaxValence = Max(child->MaxValence, 2 + parent->MaxEdgeFaces);
        }

        // --- 페이스-정점 ---

        private static void PopulateFaceVertexRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // 페이스-정점과 페이스-엣지는 개수·오프셋을 함께 쓴다. 페이스-정점을 늘 먼저 채우므로 여기서 한 번 만든다
            PopulateFaceVertexCountsAndOffsets(child);
            PopulateFaceVerticesFromParentFaces(parent, child, refinement);
        }

        private static void PopulateFaceVertexCountsAndOffsets(OsdLevel* child)
        {
            for (int i = 0; i < child->FaceCount; ++i)
            {
                child->FaceVertCountsAndOffsets.Ptr[i * 2 + 0] = 4;
                child->FaceVertCountsAndOffsets.Ptr[i * 2 + 1] = i << 2;
            }
        }

        /// <summary>
        /// 부모 페이스의 코너 j 자식 페이스: 정점 자식, 다음 엣지 자식, 페이스 자식, 이전 엣지 자식.
        /// 쿼드 부모는 부모와 같은 회전(코너 j 에 정점 자식)으로, 그 밖은 코너 0 부터 놓는다.
        /// </summary>
        private static void PopulateFaceVerticesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange pFaceVerts = parent->GetFaceVertices(pFace);
                OsdRange pFaceEdges = parent->GetFaceEdges(pFace);
                OsdRange pFaceChildren = refinement->GetFaceChildFaces(*parent, pFace);

                int pFaceSize = pFaceVerts.Count;
                for (int j = 0; j < pFaceSize; ++j)
                {
                    int cFace = pFaceChildren.Ptr[j];
                    int jPrev = j != 0 ? (j - 1) : (pFaceSize - 1);

                    int cVertOfFace = refinement->FaceChildVertIndex.Ptr[pFace];
                    int cVertOfEPrev = refinement->EdgeChildVertIndex.Ptr[pFaceEdges.Ptr[jPrev]];
                    int cVertOfVert = refinement->VertChildVertIndex.Ptr[pFaceVerts.Ptr[j]];
                    int cVertOfENext = refinement->EdgeChildVertIndex.Ptr[pFaceEdges.Ptr[j]];

                    OsdRange cFaceVerts = child->GetFaceVertices(cFace);

                    if (pFaceSize == 4)
                    {
                        int jOpp = jPrev != 0 ? (jPrev - 1) : 3;
                        int jNext = jOpp != 0 ? (jOpp - 1) : 3;

                        cFaceVerts.Ptr[j] = cVertOfVert;
                        cFaceVerts.Ptr[jNext] = cVertOfENext;
                        cFaceVerts.Ptr[jOpp] = cVertOfFace;
                        cFaceVerts.Ptr[jPrev] = cVertOfEPrev;
                    }
                    else
                    {
                        cFaceVerts.Ptr[0] = cVertOfVert;
                        cFaceVerts.Ptr[1] = cVertOfENext;
                        cFaceVerts.Ptr[2] = cVertOfFace;
                        cFaceVerts.Ptr[3] = cVertOfEPrev;
                    }
                }
            }
        }

        // --- 페이스-엣지 ---

        private static void PopulateFaceEdgeRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // 개수·오프셋은 페이스-정점에서 이미 만들었다
            PopulateFaceEdgesFromParentFaces(parent, child, refinement);
        }

        /// <summary>
        /// 자식 페이스마다 코너 정점 쪽 이전·다음 부모 엣지의 자식 엣지(퇴화 엣지 주의)와, 페이스 자식 정점에서 나가는 수직 자식 엣지 둘.
        /// </summary>
        private static void PopulateFaceEdgesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange pFaceVerts = parent->GetFaceVertices(pFace);
                OsdRange pFaceEdges = parent->GetFaceEdges(pFace);
                OsdRange pFaceChildFaces = refinement->GetFaceChildFaces(*parent, pFace);
                OsdRange pFaceChildEdges = refinement->GetFaceChildEdges(*parent, pFace);

                int pFaceSize = pFaceVerts.Count;

                for (int j = 0; j < pFaceSize; ++j)
                {
                    int cFace = pFaceChildFaces.Ptr[j];

                    // 이전·다음 부모 엣지의 정점 쌍으로 이전·다음 자식 엣지를 정한다
                    int jPrev = j != 0 ? (j - 1) : (pFaceSize - 1);

                    int pPrevEdge = pFaceEdges.Ptr[jPrev];
                    int* pPrevEdgeVerts = parent->EdgeVertIndices.Ptr + 2 * pPrevEdge;

                    int pNextEdge = pFaceEdges.Ptr[j];
                    int* pNextEdgeVerts = parent->EdgeVertIndices.Ptr + 2 * pNextEdge;

                    int pCornerVert = pFaceVerts.Ptr[j];

                    int cornerInPrevEdge = (pPrevEdgeVerts[0] != pPrevEdgeVerts[1]) ? (pPrevEdgeVerts[0] != pCornerVert ? 1 : 0) : 1;
                    int cornerInNextEdge = (pNextEdgeVerts[0] != pNextEdgeVerts[1]) ? (pNextEdgeVerts[0] != pCornerVert ? 1 : 0) : 0;

                    int cEdgeOfEdgePrev = refinement->GetEdgeChildEdges(pPrevEdge).Ptr[cornerInPrevEdge];
                    int cEdgeOfEdgeNext = refinement->GetEdgeChildEdges(pNextEdge).Ptr[cornerInNextEdge];

                    int cEdgePerpEdgePrev = pFaceChildEdges.Ptr[jPrev];
                    int cEdgePerpEdgeNext = pFaceChildEdges.Ptr[j];

                    OsdRange cFaceEdges = child->GetFaceEdges(cFace);

                    if (pFaceSize == 4)
                    {
                        int jOpp = jPrev != 0 ? (jPrev - 1) : 3;
                        int jNext = jOpp != 0 ? (jOpp - 1) : 3;

                        cFaceEdges.Ptr[j] = cEdgeOfEdgeNext;
                        cFaceEdges.Ptr[jNext] = cEdgePerpEdgeNext;
                        cFaceEdges.Ptr[jOpp] = cEdgePerpEdgePrev;
                        cFaceEdges.Ptr[jPrev] = cEdgeOfEdgePrev;
                    }
                    else
                    {
                        cFaceEdges.Ptr[0] = cEdgeOfEdgeNext;
                        cFaceEdges.Ptr[1] = cEdgePerpEdgeNext;
                        cFaceEdges.Ptr[2] = cEdgePerpEdgePrev;
                        cFaceEdges.Ptr[3] = cEdgeOfEdgePrev;
                    }
                }
            }
        }

        // --- 엣지-정점 ---

        private static void PopulateEdgeVertexRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            PopulateEdgeVerticesFromParentFaces(parent, child, refinement);
            PopulateEdgeVerticesFromParentEdges(parent, child, refinement);
        }

        /// <summary>페이스 자식 엣지: [페이스 자식 정점, 수직인 부모 엣지의 자식 정점].</summary>
        private static void PopulateEdgeVerticesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange pFaceEdges = parent->GetFaceEdges(pFace);
                OsdRange pFaceChildEdges = refinement->GetFaceChildEdges(*parent, pFace);

                for (int j = 0; j < pFaceEdges.Count; ++j)
                {
                    int cEdge = pFaceChildEdges.Ptr[j];
                    int* cEdgeVerts = child->EdgeVertIndices.Ptr + 2 * cEdge;

                    cEdgeVerts[0] = refinement->FaceChildVertIndex.Ptr[pFace];
                    cEdgeVerts[1] = refinement->EdgeChildVertIndex.Ptr[pFaceEdges.Ptr[j]];
                }
            }
        }

        /// <summary>엣지 자식 엣지 j: [엣지 자식 정점, 부모 엣지 끝 정점 j 의 자식 정점].</summary>
        private static void PopulateEdgeVerticesFromParentEdges(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge)
            {
                int* pEdgeVerts = parent->EdgeVertIndices.Ptr + 2 * pEdge;
                OsdRange pEdgeChildren = refinement->GetEdgeChildEdges(pEdge);

                for (int j = 0; j < 2; ++j)
                {
                    int cEdge = pEdgeChildren.Ptr[j];
                    int* cEdgeVerts = child->EdgeVertIndices.Ptr + 2 * cEdge;

                    cEdgeVerts[0] = refinement->EdgeChildVertIndex.Ptr[pEdge];
                    cEdgeVerts[1] = refinement->VertChildVertIndex.Ptr[pEdgeVerts[j]];
                }
            }
        }

        // --- 엣지-페이스 ---

        private static void PopulateEdgeFaceRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // populateEdgeFacesFrom* 가 더 키울 수 있도록 부모 값에서 시작한다
            child->MaxEdgeFaces = parent->MaxEdgeFaces;

            PopulateEdgeFacesFromParentFaces(parent, child, refinement);
            PopulateEdgeFacesFromParentEdges(parent, child, refinement);

            // 추정치를 마지막 엣지의 개수 + 오프셋(실제 사용량)으로 줄인다
            int last = child->EdgeCount - 1;
            int used = child->EdgeFaceCountsAndOffsets.Ptr[2 * last] + child->EdgeFaceCountsAndOffsets.Ptr[2 * last + 1];
            child->EdgeFaceIndices.Length = used;
            child->EdgeFaceLocalIndices.Length = used;
        }

        /// <summary>페이스 자식 엣지 j 는 자식 페이스 j 와 j + 1 사이에 있다 (로컬 인덱스는 쿼드 부모와 그 밖이 다르다).</summary>
        private static void PopulateEdgeFacesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                OsdRange pFaceChildFaces = refinement->GetFaceChildFaces(*parent, pFace);
                OsdRange pFaceChildEdges = refinement->GetFaceChildEdges(*parent, pFace);

                int pFaceSize = pFaceChildFaces.Count;

                for (int j = 0; j < pFaceSize; ++j)
                {
                    int cEdge = pFaceChildEdges.Ptr[j];

                    ResizeEdgeFaces(child, cEdge, 2);

                    OsdRange cEdgeFaces = child->GetEdgeFaces(cEdge);
                    OsdLocalRange cEdgeInFace = child->GetEdgeFaceLocalIndices(cEdge);

                    int jNext = (j + 1) < pFaceSize ? (j + 1) : 0;

                    int cEdgeFaceCount = 0;

                    cEdgeFaces.Ptr[cEdgeFaceCount] = pFaceChildFaces.Ptr[j];
                    cEdgeInFace.Ptr[cEdgeFaceCount] = (ushort)((pFaceSize == 4) ? jNext : 1);
                    cEdgeFaceCount++;

                    cEdgeFaces.Ptr[cEdgeFaceCount] = pFaceChildFaces.Ptr[jNext];
                    cEdgeInFace.Ptr[cEdgeFaceCount] = (ushort)((pFaceSize == 4) ? ((jNext + 2) & 3) : 2);
                    cEdgeFaceCount++;

                    TrimEdgeFaces(child, cEdge, cEdgeFaceCount);
                }
            }
        }

        /// <summary>엣지 자식 엣지 j 는 부모 엣지에 닿는 페이스마다 그 끝 정점 쪽 자식 페이스 하나에 닿는다 (퇴화 엣지 주의).</summary>
        private static void PopulateEdgeFacesFromParentEdges(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge)
            {
                OsdRange pEdgeChildEdges = refinement->GetEdgeChildEdges(pEdge);

                OsdRange pEdgeFaces = parent->GetEdgeFaces(pEdge);
                OsdLocalRange pEdgeInFace = parent->GetEdgeFaceLocalIndices(pEdge);
                int* pEdgeVerts = parent->EdgeVertIndices.Ptr + 2 * pEdge;

                for (int j = 0; j < 2; ++j)
                {
                    int cEdge = pEdgeChildEdges.Ptr[j];

                    ResizeEdgeFaces(child, cEdge, pEdgeFaces.Count);

                    OsdRange cEdgeFaces = child->GetEdgeFaces(cEdge);
                    OsdLocalRange cEdgeInFace = child->GetEdgeFaceLocalIndices(cEdge);

                    int cEdgeFaceCount = 0;

                    for (int i = 0; i < pEdgeFaces.Count; ++i)
                    {
                        int pFace = pEdgeFaces.Ptr[i];
                        int edgeInFace = pEdgeInFace.Ptr[i];

                        OsdRange pFaceVerts = parent->GetFaceVertices(pFace);
                        OsdRange pFaceChildren = refinement->GetFaceChildFaces(*parent, pFace);

                        int childOfEdge = (pEdgeVerts[0] == pEdgeVerts[1]) ? j : (pFaceVerts.Ptr[edgeInFace] != pEdgeVerts[j] ? 1 : 0);

                        int childInFace = edgeInFace + childOfEdge;
                        if (childInFace == pFaceChildren.Count)
                        {
                            childInFace = 0;
                        }

                        cEdgeFaces.Ptr[cEdgeFaceCount] = pFaceChildren.Ptr[childInFace];
                        cEdgeInFace.Ptr[cEdgeFaceCount] = (ushort)((pFaceVerts.Count == 4) ? edgeInFace : (childOfEdge != 0 ? 3 : 0));
                        cEdgeFaceCount++;
                    }
                    TrimEdgeFaces(child, cEdge, cEdgeFaceCount);
                }
            }
        }

        // --- 정점-페이스 ---

        private static void PopulateVertexFaceRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // 정점 자식이 0 번부터라(orderVerticesFromFacesFirst = false) 정점 → 페이스 → 엣지 순서로 채워야 오프셋이 자식 정점 순서대로 이어진다
            PopulateVertexFacesFromParentVertices(parent, child, refinement);
            PopulateVertexFacesFromParentFaces(parent, child, refinement);
            PopulateVertexFacesFromParentEdges(parent, child, refinement);

            // 추정치를 마지막 정점의 개수 + 오프셋(실제 사용량)으로 줄인다
            int last = child->VertCount - 1;
            int used = child->VertFaceCountsAndOffsets.Ptr[2 * last] + child->VertFaceCountsAndOffsets.Ptr[2 * last + 1];
            child->VertFaceIndices.Length = used;
            child->VertFaceLocalIndices.Length = used;
        }

        private static void PopulateVertexFacesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                int cVert = refinement->FaceChildVertIndex.Ptr[pFace];

                OsdRange pFaceChildren = refinement->GetFaceChildFaces(*parent, pFace);
                int pFaceSize = pFaceChildren.Count;

                ResizeVertexFaces(child, cVert, pFaceSize);

                OsdRange cVertFaces = child->GetVertexFaces(cVert);
                OsdLocalRange cVertInFace = child->GetVertexFaceLocalIndices(cVert);

                int cVertFaceCount = 0;
                for (int j = 0; j < pFaceSize; ++j)
                {
                    cVertFaces.Ptr[cVertFaceCount] = pFaceChildren.Ptr[j];
                    cVertInFace.Ptr[cVertFaceCount] = (ushort)((pFaceSize == 4) ? ((j + 2) & 3) : 2);
                    cVertFaceCount++;
                }
                TrimVertexFaces(child, cVert, cVertFaceCount);
            }
        }

        /// <summary>부모 엣지에 닿는 페이스마다 자식 페이스 둘. 반시계 순서를 지키려고 둘째(faceChild1)를 먼저 넣는다.</summary>
        private static void PopulateVertexFacesFromParentEdges(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge)
            {
                int cVert = refinement->EdgeChildVertIndex.Ptr[pEdge];

                OsdRange pEdgeFaces = parent->GetEdgeFaces(pEdge);
                OsdLocalRange pEdgeInFace = parent->GetEdgeFaceLocalIndices(pEdge);

                ResizeVertexFaces(child, cVert, 2 * pEdgeFaces.Count);

                OsdRange cVertFaces = child->GetVertexFaces(cVert);
                OsdLocalRange cVertInFace = child->GetVertexFaceLocalIndices(cVert);

                int cVertFaceCount = 0;
                for (int i = 0; i < pEdgeFaces.Count; ++i)
                {
                    int pFace = pEdgeFaces.Ptr[i];
                    int edgeInFace = pEdgeInFace.Ptr[i];

                    OsdRange pFaceChildren = refinement->GetFaceChildFaces(*parent, pFace);
                    int pFaceSize = pFaceChildren.Count;

                    int faceChild0 = edgeInFace;
                    int faceChild1 = edgeInFace + 1;
                    if (faceChild1 == pFaceChildren.Count)
                    {
                        faceChild1 = 0;
                    }

                    cVertFaces.Ptr[cVertFaceCount] = pFaceChildren.Ptr[faceChild1];
                    cVertInFace.Ptr[cVertFaceCount] = (ushort)((pFaceSize == 4) ? faceChild0 : 3);
                    cVertFaceCount++;

                    cVertFaces.Ptr[cVertFaceCount] = pFaceChildren.Ptr[faceChild0];
                    cVertInFace.Ptr[cVertFaceCount] = (ushort)((pFaceSize == 4) ? faceChild1 : 1);
                    cVertFaceCount++;
                }
                TrimVertexFaces(child, cVert, cVertFaceCount);
            }
        }

        private static void PopulateVertexFacesFromParentVertices(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pVert = 0; pVert < parent->VertCount; ++pVert)
            {
                int cVert = refinement->VertChildVertIndex.Ptr[pVert];

                OsdRange pVertFaces = parent->GetVertexFaces(pVert);
                OsdLocalRange pVertInFace = parent->GetVertexFaceLocalIndices(pVert);

                ResizeVertexFaces(child, cVert, pVertFaces.Count);

                OsdRange cVertFaces = child->GetVertexFaces(cVert);
                OsdLocalRange cVertInFace = child->GetVertexFaceLocalIndices(cVert);

                // 부모 정점에 닿는 페이스마다 그 코너의 자식 페이스
                int cVertFaceCount = 0;
                for (int i = 0; i < pVertFaces.Count; ++i)
                {
                    int pFace = pVertFaces.Ptr[i];
                    int vertInFace = pVertInFace.Ptr[i];

                    OsdRange pFaceChildren = refinement->GetFaceChildFaces(*parent, pFace);
                    int pFaceSize = pFaceChildren.Count;

                    cVertFaces.Ptr[cVertFaceCount] = pFaceChildren.Ptr[vertInFace];
                    cVertInFace.Ptr[cVertFaceCount] = (ushort)((pFaceSize == 4) ? vertInFace : 0);
                    cVertFaceCount++;
                }
                TrimVertexFaces(child, cVert, cVertFaceCount);
            }
        }

        // --- 정점-엣지 ---

        private static void PopulateVertexEdgeRelation(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            // 정점-페이스와 같은 이유로 정점 → 페이스 → 엣지 순서
            PopulateVertexEdgesFromParentVertices(parent, child, refinement);
            PopulateVertexEdgesFromParentFaces(parent, child, refinement);
            PopulateVertexEdgesFromParentEdges(parent, child, refinement);

            // 추정치를 마지막 정점의 개수 + 오프셋(실제 사용량)으로 줄인다
            int last = child->VertCount - 1;
            int used = child->VertEdgeCountsAndOffsets.Ptr[2 * last] + child->VertEdgeCountsAndOffsets.Ptr[2 * last + 1];
            child->VertEdgeIndices.Length = used;
            child->VertEdgeLocalIndices.Length = used;
        }

        /// <summary>페이스 자식 정점의 엣지: 자식 페이스마다 "앞" 엣지(이전 부모 엣지 쪽 수직 자식 엣지)를 순서대로.</summary>
        private static void PopulateVertexEdgesFromParentFaces(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pFace = 0; pFace < parent->FaceCount; ++pFace)
            {
                int cVert = refinement->FaceChildVertIndex.Ptr[pFace];

                OsdRange pFaceVerts = parent->GetFaceVertices(pFace);
                OsdRange pFaceChildEdges = refinement->GetFaceChildEdges(*parent, pFace);

                ResizeVertexEdges(child, cVert, pFaceVerts.Count);

                OsdRange cVertEdges = child->GetVertexEdges(cVert);
                OsdLocalRange cVertInEdge = child->GetVertexEdgeLocalIndices(cVert);

                int cVertEdgeCount = 0;
                for (int j = 0; j < pFaceVerts.Count; ++j)
                {
                    int jLeadingEdge = j != 0 ? (j - 1) : (pFaceVerts.Count - 1);

                    cVertEdges.Ptr[cVertEdgeCount] = pFaceChildEdges.Ptr[jLeadingEdge];
                    cVertInEdge.Ptr[cVertEdgeCount] = 0;
                    cVertEdgeCount++;
                }
                TrimVertexEdges(child, cVert, cVertEdgeCount);
            }
        }

        /// <summary>
        /// 엣지 자식 정점의 엣지: 부모 엣지의 자식 엣지 둘을 먼저 넣고, 닿는 페이스마다 그 안의 자식 엣지를 붙인 뒤,
        /// 첫 페이스에서 [엣지, 페이스, 엣지, ...] 순서가 되도록 바꾼다 (첫 페이스 안의 부모 엣지 방향에 따라 앞 둘도 바꾼다).
        /// </summary>
        private static void PopulateVertexEdgesFromParentEdges(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pEdge = 0; pEdge < parent->EdgeCount; ++pEdge)
            {
                int cVert = refinement->EdgeChildVertIndex.Ptr[pEdge];

                OsdRange pEdgeFaces = parent->GetEdgeFaces(pEdge);
                OsdLocalRange pEdgeInFace = parent->GetEdgeFaceLocalIndices(pEdge);

                int* pEdgeVerts = parent->EdgeVertIndices.Ptr + 2 * pEdge;
                OsdRange pEdgeChildEdges = refinement->GetEdgeChildEdges(pEdge);

                ResizeVertexEdges(child, cVert, pEdgeFaces.Count + 2);

                OsdRange cVertEdges = child->GetVertexEdges(cVert);
                OsdLocalRange cVertInEdge = child->GetVertexEdgeLocalIndices(cVert);

                // 부모 엣지의 자식 엣지 둘 — 순서는 첫 페이스를 본 뒤 정한다
                int cVertEdgeCount = 0;

                cVertEdges.Ptr[cVertEdgeCount] = pEdgeChildEdges.Ptr[0];
                cVertInEdge.Ptr[cVertEdgeCount] = 0;
                cVertEdgeCount++;

                cVertEdges.Ptr[cVertEdgeCount] = pEdgeChildEdges.Ptr[1];
                cVertInEdge.Ptr[cVertEdgeCount] = 0;
                cVertEdgeCount++;

                // 닿는 부모 페이스마다 그 안의 자식 엣지를 붙인다
                for (int i = 0; i < pEdgeFaces.Count; ++i)
                {
                    int pFace = pEdgeFaces.Ptr[i];
                    int edgeInFace = pEdgeInFace.Ptr[i];

                    int cEdgeOfFace = refinement->GetFaceChildEdges(*parent, pFace).Ptr[edgeInFace];

                    cVertEdges.Ptr[cVertEdgeCount] = cEdgeOfFace;
                    cVertInEdge.Ptr[cVertEdgeCount] = 1;
                    cVertEdgeCount++;

                    // 첫 페이스 엣지와 둘째 엣지 자식 엣지를 바꾼다
                    if ((i == 0) && (cVertEdgeCount == 3))
                    {
                        // 첫 페이스 안의 부모 엣지 방향에 맞춰 엣지 자식 엣지 둘의 순서를 정한다
                        if ((pEdgeVerts[0] != pEdgeVerts[1]) && (parent->GetFaceVertices(pFace).Ptr[edgeInFace] == pEdgeVerts[0]))
                        {
                            SwapIndex(cVertEdges.Ptr, 0, 1);
                            SwapLocalIndex(cVertInEdge.Ptr, 0, 1);
                        }
                        SwapIndex(cVertEdges.Ptr, 1, 2);
                        SwapLocalIndex(cVertInEdge.Ptr, 1, 2);
                    }
                }
                TrimVertexEdges(child, cVert, cVertEdgeCount);
            }
        }

        /// <summary>정점 자식 정점의 엣지: 부모 정점-엣지 순서대로 그 정점 쪽 자식 엣지.</summary>
        private static void PopulateVertexEdgesFromParentVertices(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement)
        {
            for (int pVert = 0; pVert < parent->VertCount; ++pVert)
            {
                int cVert = refinement->VertChildVertIndex.Ptr[pVert];

                OsdRange pVertEdges = parent->GetVertexEdges(pVert);
                OsdLocalRange pVertInEdge = parent->GetVertexEdgeLocalIndices(pVert);

                ResizeVertexEdges(child, cVert, pVertEdges.Count);

                OsdRange cVertEdges = child->GetVertexEdges(cVert);
                OsdLocalRange cVertInEdge = child->GetVertexEdgeLocalIndices(cVert);

                int cVertEdgeCount = 0;
                for (int i = 0; i < pVertEdges.Count; ++i)
                {
                    int pEdgeIndex = pVertEdges.Ptr[i];
                    int pEdgeVert = pVertInEdge.Ptr[i];

                    cVertEdges.Ptr[cVertEdgeCount] = refinement->GetEdgeChildEdges(pEdgeIndex).Ptr[pEdgeVert];
                    cVertInEdge.Ptr[cVertEdgeCount] = 1;
                    cVertEdgeCount++;
                }
                TrimVertexEdges(child, cVert, cVertEdgeCount);
            }
        }

        // --- Level 의 resize*/trim* (요소 순서대로 불러야 오프셋이 앞 요소 뒤에 이어진다) ---

        private static void ResizeEdgeFaces(OsdLevel* level, int edgeIndex, int count)
        {
            int* countOffsetPair = level->EdgeFaceCountsAndOffsets.Ptr + 2 * edgeIndex;

            countOffsetPair[0] = count;
            countOffsetPair[1] = (edgeIndex == 0) ? 0 : (countOffsetPair[-2] + countOffsetPair[-1]);

            level->MaxEdgeFaces = Max(level->MaxEdgeFaces, count);
        }

        private static void TrimEdgeFaces(OsdLevel* level, int edgeIndex, int count)
        {
            level->EdgeFaceCountsAndOffsets.Ptr[2 * edgeIndex] = count;
        }

        private static void ResizeVertexFaces(OsdLevel* level, int vertIndex, int count)
        {
            int* countOffsetPair = level->VertFaceCountsAndOffsets.Ptr + 2 * vertIndex;

            countOffsetPair[0] = count;
            countOffsetPair[1] = (vertIndex == 0) ? 0 : (countOffsetPair[-2] + countOffsetPair[-1]);
        }

        private static void TrimVertexFaces(OsdLevel* level, int vertIndex, int count)
        {
            level->VertFaceCountsAndOffsets.Ptr[2 * vertIndex] = count;
        }

        /// <summary>원본은 여기서 MaxValence 도 키우지만 subdivideTopology 끝에서 덮어쓰므로 생략한다.</summary>
        private static void ResizeVertexEdges(OsdLevel* level, int vertIndex, int count)
        {
            int* countOffsetPair = level->VertEdgeCountsAndOffsets.Ptr + 2 * vertIndex;

            countOffsetPair[0] = count;
            countOffsetPair[1] = (vertIndex == 0) ? 0 : (countOffsetPair[-2] + countOffsetPair[-1]);
        }

        private static void TrimVertexEdges(OsdLevel* level, int vertIndex, int count)
        {
            level->VertEdgeCountsAndOffsets.Ptr[2 * vertIndex] = count;
        }

        // ------------------------------------------------------------------
        // 샤프니스 분할 (Refinement::subdivideEdgeSharpness / subdivideVertexSharpness 의 무한·0 경로)
        // ------------------------------------------------------------------

        /// <summary>
        /// 자식 엣지는 매끈(0)으로 시작하고, 엣지 자식 엣지 중 무한 샤프 태그가 있는 것만 무한이 된다.
        /// semi-sharp 엣지는 생기지 않는다 (사용자 크리스가 없어 레벨 0 샤프니스가 0 또는 무한뿐이다).
        /// </summary>
        private static void SubdivideEdgeSharpness(OsdLevel* child, OsdRefinement* refinement)
        {
            for (int cEdge = 0; cEdge < child->EdgeCount; ++cEdge)
            {
                child->EdgeSharpness.Ptr[cEdge] = OsdConstants.SharpnessSmooth;
            }

            int cEdgeBegin = refinement->ChildEdgeFromFaceCount;
            int cEdgeEnd = cEdgeBegin + refinement->ChildEdgeFromEdgeCount;
            for (int cEdge = cEdgeBegin; cEdge < cEdgeEnd; ++cEdge)
            {
                if ((child->EdgeTags.Ptr[cEdge] & OsdETag.InfSharp) != 0)
                {
                    child->EdgeSharpness.Ptr[cEdge] = OsdConstants.SharpnessInfinite;
                }
            }
        }

        /// <summary>자식 정점은 매끈(0)으로 시작하고, 정점 자식 정점 중 무한 샤프 태그가 있는 것만 무한이 된다 (semi-sharp 없음).</summary>
        private static void SubdivideVertexSharpness(OsdLevel* child, OsdRefinement* refinement)
        {
            for (int cVert = 0; cVert < child->VertCount; ++cVert)
            {
                child->VertSharpness.Ptr[cVert] = OsdConstants.SharpnessSmooth;
            }

            int cVertBegin = refinement->FirstChildVertFromVert;
            int cVertEnd = cVertBegin + refinement->ChildVertFromVertCount;
            for (int cVert = cVertBegin; cVert < cVertEnd; ++cVert)
            {
                if ((child->VertTags.Ptr[cVert] & OsdVTag.InfSharp) != 0)
                {
                    child->VertSharpness.Ptr[cVert] = OsdConstants.SharpnessInfinite;
                }
            }
        }

        // ------------------------------------------------------------------
        // 도우미 (버스트 호환)
        // ------------------------------------------------------------------

        private static int Max(int a, int b)
        {
            return a > b ? a : b;
        }

        private static void SwapIndex(int* values, int a, int b)
        {
            int temp = values[a];
            values[a] = values[b];
            values[b] = temp;
        }

        private static void SwapLocalIndex(ushort* values, int a, int b)
        {
            ushort temp = values[a];
            values[a] = values[b];
            values[b] = temp;
        }
    }
}
