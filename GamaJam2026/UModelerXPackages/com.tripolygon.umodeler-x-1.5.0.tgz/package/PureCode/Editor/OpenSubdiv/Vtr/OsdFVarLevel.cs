﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>FVar 엣지 태그 비트 (vtr/fvarLevel.h 의 FVarLevel::ETag 비트필드를 같은 비트 위치의 byte 로 옮긴 것).</summary>
    public static class OsdFVarETag
    {
        /// <summary>이 엣지의 FVar 토폴로지가 정점 토폴로지와 다르다 (양쪽 페이스의 값이 끊긴다).</summary>
        public const byte Mismatch = 1;

        /// <summary>엣지 끝 정점 0 쪽에서 끊긴다.</summary>
        public const byte DisctsV0 = 2;

        /// <summary>엣지 끝 정점 1 쪽에서 끊긴다.</summary>
        public const byte DisctsV1 = 4;

        /// <summary>선형 경계 제약 (FVar 경계가 선형 보간된다).</summary>
        public const byte Linear = 8;
    }

    /// <summary>
    /// FVar 값 태그 비트 (FVarLevel::ValueTag 비트필드를 같은 비트 위치의 byte 로 옮긴 것). Mismatch 가 없으면 다른 비트는 보지 않는다.
    /// 질의 함수는 ValueTag 의 is*/has* 와 같다 (버스트 호환).
    /// </summary>
    public static class OsdValueTag
    {
        public const byte Mismatch = 1;
        public const byte Xordinary = 2;
        public const byte NonManifold = 4;

        /// <summary>매끈한 경계(크리스) 값. 없으면 코너다.</summary>
        public const byte Crease = 8;

        /// <summary>크리스로 줄어드는 코너 값 (semi-sharp — 이 이식에서는 생기지 않는다).</summary>
        public const byte SemiSharp = 16;

        /// <summary>다른 값에 기대어 코너가 된 값.</summary>
        public const byte DepSharp = 32;

        /// <summary>무한 샤프 특징 때문에 코너인 값.</summary>
        public const byte InfSharpEdges = 64;

        /// <summary>값 구간에 무한 샤프 불규칙성이 있다.</summary>
        public const byte InfIrregular = 128;

        public static bool IsMismatch(byte tag)
        {
            return (tag & Mismatch) != 0;
        }

        public static bool IsCrease(byte tag)
        {
            return (tag & Crease) != 0;
        }

        public static bool IsCorner(byte tag)
        {
            return (tag & Crease) == 0;
        }

        public static bool IsSemiSharp(byte tag)
        {
            return (tag & SemiSharp) != 0;
        }

        public static bool IsInfSharp(byte tag)
        {
            return (tag & (SemiSharp | Crease)) == 0;
        }

        public static bool IsDepSharp(byte tag)
        {
            return (tag & DepSharp) != 0;
        }

        public static bool HasCreaseEnds(byte tag)
        {
            return (tag & (Crease | SemiSharp)) != 0;
        }

        public static bool HasInfSharpEdges(byte tag)
        {
            return (tag & InfSharpEdges) != 0;
        }

        public static bool HasInfIrregularity(byte tag)
        {
            return (tag & InfIrregular) != 0;
        }
    }

    /// <summary>
    /// 한 레벨의 FVar(UV) 채널 토폴로지 (vtr/fvarLevel.h 의 FVarLevel). 연결된 레벨(OsdLevel)은 들고 있지 않으므로 레벨이 필요한 질의는 레벨을 인자로 받는다.
    /// "값"은 FVar 데이터 인덱스, 정점마다 하나 이상의 값(형제, sibling)을 가진다. 레벨 0 의 VertValueIndices 는 입력 값 인덱스이고,
    /// 분할된 레벨에서는 값 오프셋과 같다(항등). 구조체를 복사하면 같은 메모리를 가리키므로 Free 는 소유한 쪽 변수에서 한 번만 부른다.
    /// 질의 함수는 버스트 호환이다 (포인터만 쓰고 예외·관리 객체 없음).
    /// </summary>
    public unsafe struct OsdFVarLevel
    {
        /// <summary>FVar 선형 보간 옵션 (Sdc::Options 중 채널마다 다른 것).</summary>
        public OsdFVarLinearInterpolation Linear;

        public byte IsLinear;
        public byte HasLinearBoundaries;
        public byte HasDependentSharpness;

        /// <summary>값 수 (레벨 0 은 입력 값 수, 분할된 레벨은 정점 값 수).</summary>
        public int ValueCount;

        /// <summary>페이스별: 레벨 페이스-정점과 같은 개수·오프셋의 코너 값.</summary>
        public OsdBuffer<int> FaceVertValues;

        /// <summary>엣지별: OsdFVarETag 비트.</summary>
        public OsdBuffer<byte> EdgeTags;

        /// <summary>정점별: 값(형제) 수.</summary>
        public OsdBuffer<ushort> VertSiblingCounts;

        /// <summary>정점별: 첫 값의 오프셋 (값 버퍼 안 위치).</summary>
        public OsdBuffer<int> VertSiblingOffsets;

        /// <summary>정점-페이스별: 레벨 정점-페이스와 같은 개수·오프셋으로, 그 페이스 코너가 쓰는 정점 값의 형제 번호.</summary>
        public OsdBuffer<ushort> VertFaceSiblings;

        /// <summary>값별: 값 인덱스.</summary>
        public OsdBuffer<int> VertValueIndices;

        /// <summary>값별: OsdValueTag 비트.</summary>
        public OsdBuffer<byte> VertValueTags;

        /// <summary>값별 2 칸: 크리스 끝 페이스 (정점-페이스 안 위치) 시작·끝. 매끈한 경계일 때만 쓴다.</summary>
        public OsdBuffer<ushort> VertValueCreaseEnds;

        public readonly bool HasSmoothBoundaries
        {
            get { return HasLinearBoundaries == 0; }
        }

        public readonly bool HasCreaseEnds
        {
            get { return HasLinearBoundaries == 0; }
        }

        /// <summary>페이스 코너 값 (페이스-정점과 같은 개수·오프셋).</summary>
        public readonly OsdRange GetFaceValues(in OsdLevel level, int f)
        {
            OsdRange range;
            range.Ptr = FaceVertValues.Ptr + level.FaceVertCountsAndOffsets.Ptr[2 * f + 1];
            range.Count = level.FaceVertCountsAndOffsets.Ptr[2 * f];
            return range;
        }

        public readonly byte GetEdgeTag(int e)
        {
            return EdgeTags.Ptr[e];
        }

        public readonly bool EdgeTopologyMatches(int e)
        {
            return (EdgeTags.Ptr[e] & OsdFVarETag.Mismatch) == 0;
        }

        public readonly int GetNumVertexValues(int v)
        {
            return VertSiblingCounts.Ptr[v];
        }

        public readonly int GetVertexValueOffset(int v)
        {
            return VertSiblingOffsets.Ptr[v];
        }

        public readonly int GetVertexValueOffset(int v, int sibling)
        {
            return VertSiblingOffsets.Ptr[v] + sibling;
        }

        public readonly int GetVertexValue(int v, int sibling)
        {
            return VertValueIndices.Ptr[VertSiblingOffsets.Ptr[v] + sibling];
        }

        /// <summary>정점의 값 인덱스들 (형제 순).</summary>
        public readonly OsdRange GetVertexValues(int v)
        {
            OsdRange range;
            range.Ptr = VertValueIndices.Ptr + VertSiblingOffsets.Ptr[v];
            range.Count = VertSiblingCounts.Ptr[v];
            return range;
        }

        /// <summary>정점의 값 태그 (GetNumVertexValues(v) 개).</summary>
        public readonly byte* GetVertexValueTags(int v)
        {
            return VertValueTags.Ptr + VertSiblingOffsets.Ptr[v];
        }

        /// <summary>정점의 값 크리스 끝 (값마다 시작·끝 2 칸, GetNumVertexValues(v) 쌍).</summary>
        public readonly ushort* GetVertexValueCreaseEnds(int v)
        {
            return VertValueCreaseEnds.Ptr + 2 * VertSiblingOffsets.Ptr[v];
        }

        /// <summary>정점-페이스마다 형제 번호 (레벨 정점-페이스와 같은 개수·오프셋).</summary>
        public readonly OsdLocalRange GetVertexFaceSiblings(in OsdLevel level, int v)
        {
            OsdLocalRange range;
            range.Ptr = VertFaceSiblings.Ptr + level.VertFaceCountsAndOffsets.Ptr[2 * v + 1];
            range.Count = level.VertFaceCountsAndOffsets.Ptr[2 * v];
            return range;
        }

        public readonly byte GetValueTag(int valueIndex)
        {
            return VertValueTags.Ptr[valueIndex];
        }

        public readonly bool ValueTopologyMatches(int valueIndex)
        {
            return (VertValueTags.Ptr[valueIndex] & OsdValueTag.Mismatch) == 0;
        }

        /// <summary>정점 v 의 값 중 valueIndex 인 것의 오프셋. 분할된 레벨은 값 인덱스가 곧 오프셋이다 (FVarLevel::findVertexValueIndex).</summary>
        public readonly int FindVertexValueIndex(in OsdLevel level, int vertexIndex, int valueIndex)
        {
            if (level.Depth > 0)
            {
                return valueIndex;
            }

            int vvIndex = VertSiblingOffsets.Ptr[vertexIndex];
            while (VertValueIndices.Ptr[vvIndex] != valueIndex)
            {
                ++vvIndex;
            }
            return vvIndex;
        }

        /// <summary>
        /// 크리스 값의 두 끝 값 (FVarLevel::getVertexCreaseEndValues). 크리스 끝 페이스의 다음 코너·앞 코너 값을 endValues[0]·[1] 에 쓴다.
        /// </summary>
        public readonly void GetVertexCreaseEndValues(in OsdLevel level, int vIndex, int sibling, int* endValues)
        {
            ushort* vValueCreaseEnds = GetVertexValueCreaseEnds(vIndex);

            OsdRange vFaces = level.GetVertexFaces(vIndex);
            OsdLocalRange vInFace = level.GetVertexFaceLocalIndices(vIndex);

            int vertFace0 = vValueCreaseEnds[2 * sibling];
            int vertFace1 = vValueCreaseEnds[2 * sibling + 1];

            OsdRange face0Values = GetFaceValues(level, vFaces.Ptr[vertFace0]);
            OsdRange face1Values = GetFaceValues(level, vFaces.Ptr[vertFace1]);

            int endInFace0 = vInFace.Ptr[vertFace0];
            int endInFace1 = vInFace.Ptr[vertFace1];

            endInFace0 = (endInFace0 == (face0Values.Count - 1)) ? 0 : (endInFace0 + 1);
            endInFace1 = (endInFace1 != 0 ? endInFace1 : face1Values.Count) - 1;

            endValues[0] = face0Values.Ptr[endInFace0];
            endValues[1] = face1Values.Ptr[endInFace1];
        }

        /// <summary>
        /// 엣지의 두 끝 정점 값 (FVarLevel::getEdgeFaceValues). 끝 정점에 값이 둘 이상이면 엣지의 fIncToEdge 번째 페이스에서 읽는다.
        /// 레벨 0 이면 값 인덱스, 분할된 레벨이면 값 오프셋을 valuesPerVert[0]·[1] 에 쓴다.
        /// </summary>
        public readonly void GetEdgeFaceValues(in OsdLevel level, int eIndex, int fIncToEdge, int* valuesPerVert)
        {
            OsdRange eVerts = level.GetEdgeVertices(eIndex);

            if ((GetNumVertexValues(eVerts.Ptr[0]) + GetNumVertexValues(eVerts.Ptr[1])) > 2)
            {
                int eFace = level.GetEdgeFaces(eIndex).Ptr[fIncToEdge];
                int eInFace = level.GetEdgeFaceLocalIndices(eIndex).Ptr[fIncToEdge];

                OsdRange fValues = GetFaceValues(level, eFace);

                valuesPerVert[0] = fValues.Ptr[eInFace];
                valuesPerVert[1] = fValues.Ptr[((eInFace + 1) < fValues.Count) ? (eInFace + 1) : 0];

                // 두 끝 값은 같은 가중치로 쓰이므로 순서를 정점 순서에 맞추는 것은 원본과 같게 하려는 것뿐이다
                if (eVerts.Ptr[0] != level.GetFaceVertices(eFace).Ptr[eInFace])
                {
                    int temp = valuesPerVert[0];
                    valuesPerVert[0] = valuesPerVert[1];
                    valuesPerVert[1] = temp;
                }
            }
            else
            {
                // 레벨 0 의 간접 참조를 피한다
                if (level.Depth > 0)
                {
                    valuesPerVert[0] = GetVertexValueOffset(eVerts.Ptr[0]);
                    valuesPerVert[1] = GetVertexValueOffset(eVerts.Ptr[1]);
                }
                else
                {
                    valuesPerVert[0] = GetVertexValue(eVerts.Ptr[0], 0);
                    valuesPerVert[1] = GetVertexValue(eVerts.Ptr[1], 0);
                }
            }
        }

        /// <summary>
        /// 정점 엣지마다 맞은편 정점의 값 (FVarLevel::getVertexEdgeValues). 정점 주변 엣지가 FVar 로 이어져 있다고 가정한다.
        /// valuesPerEdge 는 정점 엣지 수만큼.
        /// </summary>
        public readonly void GetVertexEdgeValues(in OsdLevel level, int vIndex, int* valuesPerEdge)
        {
            OsdRange vEdges = level.GetVertexEdges(vIndex);
            OsdLocalRange vInEdge = level.GetVertexEdgeLocalIndices(vIndex);

            OsdRange vFaces = level.GetVertexFaces(vIndex);
            OsdLocalRange vInFace = level.GetVertexFaceLocalIndices(vIndex);

            ushort vTag = level.VertTags.Ptr[vIndex];
            bool vIsBoundary = (vTag & OsdVTag.Boundary) != 0;
            bool vIsManifold = (vTag & OsdVTag.NonManifold) == 0;

            bool isBaseLevel = level.Depth == 0;

            for (int i = 0; i < vEdges.Count; ++i)
            {
                int eIndex = vEdges.Ptr[i];
                OsdRange eVerts = level.GetEdgeVertices(eIndex);

                int vOther = eVerts.Ptr[vInEdge.Ptr[i] == 0 ? 1 : 0];
                if (GetNumVertexValues(vOther) == 1)
                {
                    valuesPerEdge[i] = isBaseLevel ? GetVertexValue(vOther, 0) : GetVertexValueOffset(vOther);
                }
                else if (vIsManifold)
                {
                    if (vIsBoundary && (i == (vEdges.Count - 1)))
                    {
                        OsdRange fValues = GetFaceValues(level, vFaces.Ptr[i - 1]);

                        int prevInFace = vInFace.Ptr[i - 1] != 0 ? (vInFace.Ptr[i - 1] - 1) : (fValues.Count - 1);
                        valuesPerEdge[i] = fValues.Ptr[prevInFace];
                    }
                    else
                    {
                        OsdRange fValues = GetFaceValues(level, vFaces.Ptr[i]);

                        int nextInFace = (vInFace.Ptr[i] == (fValues.Count - 1)) ? 0 : (vInFace.Ptr[i] + 1);
                        valuesPerEdge[i] = fValues.Ptr[nextInFace];
                    }
                }
                else
                {
                    int eFace0 = level.GetEdgeFaces(eIndex).Ptr[0];
                    int eInFace0 = level.GetEdgeFaceLocalIndices(eIndex).Ptr[0];

                    OsdRange fVerts = level.GetFaceVertices(eFace0);
                    OsdRange fValues = GetFaceValues(level, eFace0);
                    if (vOther == fVerts.Ptr[eInFace0])
                    {
                        valuesPerEdge[i] = fValues.Ptr[eInFace0];
                    }
                    else
                    {
                        int valueInFace = (eInFace0 == (fValues.Count - 1)) ? 0 : (eInFace0 + 1);
                        valuesPerEdge[i] = fValues.Ptr[valueInFace];
                    }
                }
            }
        }

        /// <summary>모든 버퍼를 해제하고 개수·옵션을 0 으로 되돌린다. 같은 변수에서 두 번 불러도 안전하다. 관리 코드 전용.</summary>
        public void Free()
        {
            FaceVertValues.Free();
            EdgeTags.Free();
            VertSiblingCounts.Free();
            VertSiblingOffsets.Free();
            VertFaceSiblings.Free();
            VertValueIndices.Free();
            VertValueTags.Free();
            VertValueCreaseEnds.Free();

            Linear = OsdFVarLinearInterpolation.None;
            IsLinear = 0;
            HasLinearBoundaries = 0;
            HasDependentSharpness = 0;
            ValueCount = 0;
        }
    }

    /// <summary>
    /// 레벨 0 FVar 채널 생성 (vtr/level.cpp 의 createFVarChannel + far/topologyRefinerFactory.cpp 의 prepareFaceVaryingChannels
    /// + vtr/fvarLevel.cpp 의 completeTopologyFromFaceValues). 관리 코드다 (버스트 함수가 아니다).
    /// </summary>
    public static unsafe class OsdFVarLevelBuilder
    {
        /// <summary>Catmark 의 정규 경계 밸런스 (정규 정점 밸런스 4 / 2).</summary>
        private const int RegularBoundaryValence = 2;

        /// <summary>
        /// 다 만들고 태그를 붙인 레벨 0(OsdLevelBuilder.BuildBaseLevel + OsdBaseLevelTags.Apply)에 FVar 채널 하나를 만든다.
        /// faceVertValues 는 페이스 순서대로 이어 붙인 코너 값 인덱스(레벨 페이스-정점 수만큼)이고 [0, valueCount) 안이어야 한다 (호출자 계약).
        /// valueCount 가 0 이면 원본처럼 거절한다(EmptyFVarChannel), 음수이거나 faceVertValues 가 null 이면 InvalidInput.
        /// boundary 는 정점 경계 보간 — 원본 완성 단계가 코너를 매끈하게 보는지(geomCornersAreSmooth) 정하는 데 쓴다.
        /// </summary>
        public static OsdStatus BuildBaseChannel(in OsdLevel level, int valueCount, int* faceVertValues, OsdBoundaryInterpolation boundary, OsdFVarLinearInterpolation linear, out OsdFVarLevel fvar)
        {
            fvar = default;
            if (valueCount == 0)
            {
                return OsdStatus.EmptyFVarChannel;
            }
            if (valueCount < 0 || faceVertValues == null)
            {
                return OsdStatus.InvalidInput;
            }

            try
            {
                // createFVarChannel: setOptions + resizeValues + resizeComponents
                fvar.Linear = linear;
                fvar.ValueCount = valueCount;

                int faceVertTotal = level.FaceVertIndices.Length;
                fvar.FaceVertValues = OsdBuffer<int>.Allocate(faceVertTotal);
                fvar.EdgeTags = OsdBuffer<byte>.Allocate(level.EdgeCount);
                fvar.VertSiblingCounts = OsdBuffer<ushort>.Allocate(level.VertCount);
                fvar.VertSiblingOffsets = OsdBuffer<int>.Allocate(level.VertCount);
                fvar.VertFaceSiblings = OsdBuffer<ushort>.Allocate(level.VertFaceIndices.Length);

                // 팩토리의 assignFaceVaryingTopology: 페이스 값을 그대로 옮긴다
                for (int i = 0; i < faceVertTotal; ++i)
                {
                    fvar.FaceVertValues.Ptr[i] = faceVertValues[i];
                }

                CompleteTopologyFromFaceValues(level, ref fvar, boundary, RegularBoundaryValence);
            }
            catch
            {
                fvar.Free();
                throw;
            }
            return OsdStatus.Ok;
        }

        /// <summary>값 하나의 "구간" — 정점 주변에서 FVar 로 이어진 엣지를 함께 쓰는 페이스들 (FVarLevel::ValueSpan, 레벨 0 분석용 임시 정보).</summary>
        private struct ValueSpan
        {
            public int Size;
            public int Start;
            public int DisctsEdgeCount;
            public int SemiSharpEdgeCount;
            public int InfSharpEdgeCount;
        }

        /// <summary>
        /// FVarLevel::completeTopologyFromFaceValues. 첫 번째 정점 순회로 끊긴 엣지를 표시하고 정점마다 값(형제) 수·오프셋·정점-페이스 형제를 정한 뒤,
        /// 값 버퍼를 잡고 두 번째 순회로 값 인덱스와 값 태그(코너/크리스·크리스 끝)를 정한다.
        /// </summary>
        private static void CompleteTopologyFromFaceValues(in OsdLevel level, ref OsdFVarLevel fvar, OsdBoundaryInterpolation boundary, int regularBoundaryValence)
        {
            // 보간 옵션에 따른 멤버와 지역 변수
            OsdFVarLinearInterpolation fvarOptions = fvar.Linear;

            fvar.IsLinear = (byte)(fvarOptions == OsdFVarLinearInterpolation.All ? 1 : 0);

            fvar.HasLinearBoundaries = (byte)((fvarOptions == OsdFVarLinearInterpolation.All || fvarOptions == OsdFVarLinearInterpolation.Boundaries) ? 1 : 0);

            fvar.HasDependentSharpness = (byte)((fvarOptions == OsdFVarLinearInterpolation.CornersPlus1 || fvarOptions == OsdFVarLinearInterpolation.CornersPlus2) ? 1 : 0);

            bool hasLinearBoundaries = fvar.HasLinearBoundaries != 0;
            bool hasDependentSharpness = fvar.HasDependentSharpness != 0;

            bool geomCornersAreSmooth = boundary != OsdBoundaryInterpolation.EdgeAndCorner;
            bool fvarCornersAreSharp = fvarOptions != OsdFVarLinearInterpolation.None;

            bool makeSmoothCornersSharp = geomCornersAreSmooth && fvarCornersAreSharp;

            bool sharpenBothIfOneCorner = fvarOptions == OsdFVarLinearInterpolation.CornersPlus2;

            bool sharpenDarts = sharpenBothIfOneCorner || hasLinearBoundaries;

            // 첫 번째 순회: 끊긴 엣지 표시, 정점마다 값 수·오프셋·정점-페이스 형제.
            // 끊긴 엣지는 양 끝 정점을 모두 "불일치"로 만든다
            bool[] vertexMismatch = new bool[level.VertCount];

            int bufferSize = level.MaxValence > 16 ? level.MaxValence : 16;
            int[] vValues = new int[bufferSize];
            int[] uniqueValues = new int[bufferSize];
            ushort[] vValueSiblings = new ushort[bufferSize];
            ValueSpan[] vValueSpans = new ValueSpan[bufferSize];

            int totalValueCount = 0;
            for (int vIndex = 0; vIndex < level.VertCount; ++vIndex)
            {
                // 닿는 페이스마다 이 정점 코너의 값을 모은다
                OsdRange vFaces = level.GetVertexFaces(vIndex);
                OsdLocalRange vInFace = level.GetVertexFaceLocalIndices(vIndex);

                if (vFaces.Count > vValues.Length)
                {
                    int grown = vFaces.Count;
                    vValues = new int[grown];
                    uniqueValues = new int[grown];
                    vValueSiblings = new ushort[grown];
                    vValueSpans = new ValueSpan[grown];
                }

                for (int i = 0; i < vFaces.Count; ++i)
                {
                    vValues[i] = fvar.FaceVertValues.Ptr[level.FaceVertCountsAndOffsets.Ptr[2 * vFaces.Ptr[i] + 1] + vInFace.Ptr[i]];
                }

                // 닿는 엣지 중 양쪽 페이스의 값이 끊긴 것을 표시한다. 다양체면 이웃 페이스 값끼리 비교하면 되고,
                // 비다양체는 엣지와 페이스 목록 사이에 대응이 없어 엣지마다 페이스들을 본다
                OsdRange vEdges = level.GetVertexEdges(vIndex);
                OsdLocalRange vInEdge = level.GetVertexEdgeLocalIndices(vIndex);

                ushort vTag = level.VertTags.Ptr[vIndex];
                bool vIsManifold = (vTag & OsdVTag.NonManifold) == 0;
                bool vIsBoundary = (vTag & OsdVTag.Boundary) != 0;

                if (vIsManifold)
                {
                    // 페이스 인덱스로 돈다: 이 범위가 경계·내부 정점의 내부 엣지에 대응한다
                    for (int i = vIsBoundary ? 1 : 0; i < vFaces.Count; ++i)
                    {
                        int vFaceNext = i;
                        int vFacePrev = i != 0 ? (i - 1) : (vFaces.Count - 1);

                        if (vValues[vFaceNext] != vValues[vFacePrev])
                        {
                            int eIndex = vEdges.Ptr[i];
                            MarkEdgeDiscontinuous(level, ref fvar, vertexMismatch, eIndex, vIndex, hasLinearBoundaries);
                        }
                    }
                }
                else if (vFaces.Count > 0)
                {
                    for (int i = 0; i < vEdges.Count; ++i)
                    {
                        int eIndex = vEdges.Ptr[i];

                        OsdRange eFaces = level.GetEdgeFaces(eIndex);
                        if (eFaces.Count < 2)
                        {
                            continue;
                        }

                        OsdLocalRange eInFace = level.GetEdgeFaceLocalIndices(eIndex);
                        OsdRange eVerts = level.GetEdgeVertices(eIndex);

                        int vertInEdge = vInEdge.Ptr[i];
                        bool markEdgeDiscts = false;
                        int valueIndexInFace0 = 0;
                        for (int j = 0; markEdgeDiscts == false && (j < eFaces.Count); ++j)
                        {
                            int fIndex = eFaces.Ptr[j];
                            OsdRange fVerts = level.GetFaceVertices(fIndex);
                            OsdRange fValues = fvar.GetFaceValues(level, fIndex);

                            int edgeInFace = eInFace.Ptr[j];
                            int edgeReversed = (eVerts.Ptr[0] != fVerts.Ptr[edgeInFace]) ? 1 : 0;
                            int vertInFace = edgeInFace + ((vertInEdge != edgeReversed) ? 1 : 0);
                            if (vertInFace == fVerts.Count)
                            {
                                vertInFace = 0;
                            }

                            if (j == 0)
                            {
                                valueIndexInFace0 = fValues.Ptr[vertInFace];
                            }
                            else
                            {
                                markEdgeDiscts = fValues.Ptr[vertInFace] != valueIndexInFace0;
                            }
                        }
                        if (markEdgeDiscts)
                        {
                            MarkEdgeDiscontinuous(level, ref fvar, vertexMismatch, eIndex, vIndex, hasLinearBoundaries);
                        }
                    }
                }

                // 끊긴 엣지가 없어도 FVar 보간 규칙이 기하 경계 정점을 다르게 다루면 불일치로 본다
                if (vIsBoundary && vertexMismatch[vIndex] == false)
                {
                    if (hasLinearBoundaries && (vFaces.Count > 0))
                    {
                        vertexMismatch[vIndex] = true;

                        if (vIsManifold)
                        {
                            fvar.EdgeTags.Ptr[vEdges.Ptr[0]] |= OsdFVarETag.Linear;
                            fvar.EdgeTags.Ptr[vEdges.Ptr[vEdges.Count - 1]] |= OsdFVarETag.Linear;
                        }
                        else
                        {
                            for (int i = 0; i < vEdges.Count; ++i)
                            {
                                if ((level.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdETag.Boundary) != 0)
                                {
                                    fvar.EdgeTags.Ptr[vEdges.Ptr[i]] |= OsdFVarETag.Linear;
                                }
                            }
                        }
                    }
                    else if (vFaces.Count == 1)
                    {
                        if (makeSmoothCornersSharp)
                        {
                            vertexMismatch[vIndex] = true;
                        }
                    }
                }

                // 정점 주변 값 중 서로 다른 값의 수를 세면서, 값마다 형제 번호(서로 다른 값 목록 안 위치)를 붙인다
                int uniqueValueCount = 1;

                if (vFaces.Count > 0)
                {
                    uniqueValues[0] = vValues[0];
                    vValueSiblings[0] = 0;
                }

                for (int i = 1; i < vFaces.Count; ++i)
                {
                    if (vValues[i] == vValues[i - 1])
                    {
                        vValueSiblings[i] = vValueSiblings[i - 1];
                    }
                    else
                    {
                        // 찾지 못하면 다음(새) 값의 형제 번호가 된다
                        vValueSiblings[i] = (ushort)uniqueValueCount;

                        if (uniqueValueCount == 1)
                        {
                            uniqueValues[uniqueValueCount++] = vValues[i];
                        }
                        else if ((uniqueValueCount == 2) && (uniqueValues[0] != vValues[i]))
                        {
                            // 원본과 같게 둘째 값과 같은지 보지 않는다 (A B A B 같은 순서에서는 B 가 새 형제가 된다)
                            uniqueValues[uniqueValueCount++] = vValues[i];
                        }
                        else
                        {
                            int found = -1;
                            for (int k = 0; k < uniqueValueCount; ++k)
                            {
                                if (uniqueValues[k] == vValues[i])
                                {
                                    found = k;
                                    break;
                                }
                            }
                            if (found < 0)
                            {
                                uniqueValues[uniqueValueCount++] = vValues[i];
                            }
                            else
                            {
                                vValueSiblings[i] = (ushort)found;
                            }
                        }
                    }
                }

                // 비다양체는 끊긴 엣지 없이도 값이 여럿일 수 있다 (예: 정점 하나만 함께 쓰는 두 페이스)
                if (vIsManifold == false && vertexMismatch[vIndex] == false)
                {
                    vertexMismatch[vIndex] = uniqueValueCount > 1;
                }

                // 정점의 값 수·오프셋과 누계
                fvar.VertSiblingCounts.Ptr[vIndex] = (ushort)uniqueValueCount;
                fvar.VertSiblingOffsets.Ptr[vIndex] = totalValueCount;

                totalValueCount += uniqueValueCount;

                // 정점-페이스 형제
                if (uniqueValueCount > 1)
                {
                    OsdLocalRange vFaceSiblings = fvar.GetVertexFaceSiblings(level, vIndex);
                    for (int i = 0; i < vFaces.Count; ++i)
                    {
                        vFaceSiblings.Ptr[i] = vValueSiblings[i];
                    }
                }
            }

            // 전체 값 수를 알았으니 값 버퍼를 잡는다 (resizeVertexValues — 값 태그는 "일치"로 시작한다)
            fvar.VertValueIndices = OsdBuffer<int>.Allocate(totalValueCount);
            fvar.VertValueTags = OsdBuffer<byte>.Allocate(totalValueCount);
            if (fvar.HasCreaseEnds)
            {
                fvar.VertValueCreaseEnds = OsdBuffer<ushort>.Allocate(2 * totalValueCount);
            }

            // 두 번째 순회: 정점 값 인덱스를 채우고 불일치 정점의 값을 분류한다
            for (int vIndex = 0; vIndex < level.VertCount; ++vIndex)
            {
                OsdRange vFaces = level.GetVertexFaces(vIndex);
                OsdLocalRange vInFace = level.GetVertexFaceLocalIndices(vIndex);

                OsdRange vValueRange = fvar.GetVertexValues(vIndex);

                if (vFaces.Count > 0)
                {
                    vValueRange.Ptr[0] = fvar.FaceVertValues.Ptr[level.FaceVertCountsAndOffsets.Ptr[2 * vFaces.Ptr[0] + 1] + vInFace.Ptr[0]];
                }
                else
                {
                    vValueRange.Ptr[0] = 0;
                }
                if (vertexMismatch[vIndex] == false)
                {
                    continue;
                }
                if (vValueRange.Count > 1)
                {
                    OsdLocalRange vFaceSiblings = fvar.GetVertexFaceSiblings(level, vIndex);

                    for (int i = 1, nextSibling = 1; i < vFaces.Count; ++i)
                    {
                        if (vFaceSiblings.Ptr[i] == nextSibling)
                        {
                            vValueRange.Ptr[nextSibling++] = fvar.FaceVertValues.Ptr[level.FaceVertCountsAndOffsets.Ptr[2 * vFaces.Ptr[i] + 1] + vInFace.Ptr[i]];
                        }
                    }
                }

                // 모든 값이 샤프 코너가 되는 경우는 값 구간을 보지 않고 미리 정한다 (원본의 선제 샤프닝).
                // 정점 자체의 샤프니스만 근거로 쓴다 — 닿는 무한 샤프 엣지만으로는 단정하지 않는다
                int vCount = vValueRange.Count;
                byte* vValueTags = fvar.GetVertexValueTags(vIndex);

                ushort vTag = level.VertTags.Ptr[vIndex];
                bool vTagInfSharp = (vTag & OsdVTag.InfSharp) != 0;
                bool vTagNonManifold = (vTag & OsdVTag.NonManifold) != 0;
                bool vTagBoundary = (vTag & OsdVTag.Boundary) != 0;
                bool vTagSemiSharp = (vTag & OsdVTag.SemiSharp) != 0;

                bool allCornersAreSharp = hasLinearBoundaries || vTagInfSharp || vTagNonManifold ||
                                          (hasDependentSharpness && (vCount > 2)) ||
                                          (sharpenDarts && (vCount == 1) && vTagBoundary == false);

                // 값마다 페이스 구간 정보를 모은다 (같은 값이 떨어진 여러 영역을 가지면 "끊김"으로 센다)
                for (int i = 0; i < vCount; ++i)
                {
                    vValueSpans[i] = default;
                }
                GatherValueSpans(level, fvar, vIndex, vValueSpans);

                // 한 값의 샤프함이 다른 값에 기댈 수 있다 (선형 보간 옵션). 가능하면 둘 다 무한 샤프로 만든다
                bool hasDependentValuesToSharpen = false;
                if (allCornersAreSharp == false)
                {
                    if (hasDependentSharpness && (vCount == 2))
                    {
                        // 내부 무한 샤프·끊긴 엣지
                        allCornersAreSharp = vValueSpans[0].InfSharpEdgeCount != 0 || vValueSpans[1].InfSharpEdgeCount != 0 ||
                                             vValueSpans[0].DisctsEdgeCount != 0 || vValueSpans[1].DisctsEdgeCount != 0;

                        // 한쪽이 샤프 코너면 둘 다
                        if (sharpenBothIfOneCorner)
                        {
                            allCornersAreSharp |= (vValueSpans[0].Size == 1) || (vValueSpans[1].Size == 1);
                        }

                        // 한쪽만 semi-sharp 면 다른 쪽을 그것에 기대게 표시한다
                        hasDependentValuesToSharpen = (vValueSpans[0].SemiSharpEdgeCount > 0) != (vValueSpans[1].SemiSharpEdgeCount > 0);
                    }
                }

                // 값마다 매끈한 경계(크리스)인지 정해 태그를 붙인다
                for (int i = 0; i < vCount; ++i)
                {
                    byte valueTag = OsdValueTag.Mismatch;

                    ValueSpan vSpan = vValueSpans[i];
                    if (vSpan.DisctsEdgeCount != 0)
                    {
                        valueTag |= OsdValueTag.NonManifold;
                        vValueTags[i] = valueTag;
                        continue;
                    }

                    bool isInfSharp = allCornersAreSharp || vSpan.InfSharpEdgeCount != 0 ||
                                      ((vSpan.Size == 1) && fvarCornersAreSharp);

                    bool xordinary;
                    if (vSpan.Size == 1)
                    {
                        xordinary = isInfSharp == false;
                    }
                    else
                    {
                        xordinary = vSpan.Size != regularBoundaryValence;
                    }
                    if (xordinary)
                    {
                        valueTag |= OsdValueTag.Xordinary;
                    }

                    if (vSpan.InfSharpEdgeCount > 0)
                    {
                        valueTag |= OsdValueTag.InfSharpEdges;
                    }

                    bool infIrregular = vSpan.InfSharpEdgeCount != 0 ? ((vSpan.Size - vSpan.InfSharpEdgeCount) > 1)
                                      : (isInfSharp ? (vSpan.Size > 1) : xordinary);
                    if (infIrregular)
                    {
                        valueTag |= OsdValueTag.InfIrregular;
                    }

                    if (isInfSharp == false)
                    {
                        // semi-sharp 값(또는 그것에 기댄 값)은 샤프니스가 줄 때까지 코너로 다루므로 크리스로 표시하지 않는다.
                        // 크리스 끝은 필요해질 때까지 초기화해 유지한다
                        if (vSpan.SemiSharpEdgeCount != 0 || vTagSemiSharp)
                        {
                            valueTag |= OsdValueTag.SemiSharp;
                        }
                        else if (hasDependentValuesToSharpen)
                        {
                            valueTag |= OsdValueTag.SemiSharp;
                            valueTag |= OsdValueTag.DepSharp;
                        }
                        else
                        {
                            valueTag |= OsdValueTag.Crease;
                        }

                        if (fvar.HasCreaseEnds)
                        {
                            ushort* valueCrease = fvar.GetVertexValueCreaseEnds(vIndex) + 2 * i;

                            valueCrease[0] = (ushort)vSpan.Start;
                            if ((i == 0) && (vSpan.Start != 0))
                            {
                                valueCrease[1] = (ushort)(vSpan.Start + vSpan.Size - 1 - vFaces.Count);
                            }
                            else
                            {
                                valueCrease[1] = (ushort)(vSpan.Start + vSpan.Size - 1);
                            }
                        }
                    }
                    vValueTags[i] = valueTag;
                }
            }
        }

        /// <summary>엣지를 끊김으로 표시하고 양 끝 정점을 불일치로 만든다. 끊긴 쪽 비트는 이 정점 기준으로 덮어쓴다 (원본과 같다).</summary>
        private static void MarkEdgeDiscontinuous(in OsdLevel level, ref OsdFVarLevel fvar, bool[] vertexMismatch, int eIndex, int vIndex, bool hasLinearBoundaries)
        {
            OsdRange eVerts = level.GetEdgeVertices(eIndex);
            vertexMismatch[eVerts.Ptr[0]] = true;
            vertexMismatch[eVerts.Ptr[1]] = true;

            byte eTag = fvar.EdgeTags.Ptr[eIndex];
            eTag = (byte)(eTag & ~(OsdFVarETag.DisctsV0 | OsdFVarETag.DisctsV1 | OsdFVarETag.Linear));
            if (eVerts.Ptr[0] == vIndex)
            {
                eTag |= OsdFVarETag.DisctsV0;
            }
            if (eVerts.Ptr[1] == vIndex)
            {
                eTag |= OsdFVarETag.DisctsV1;
            }
            eTag |= OsdFVarETag.Mismatch;
            if (hasLinearBoundaries)
            {
                eTag |= OsdFVarETag.Linear;
            }
            fvar.EdgeTags.Ptr[eIndex] = eTag;
        }

        /// <summary>
        /// FVarLevel::gatherValueSpans. 값마다 그 값이 나오는 페이스 수(Size)·첫 페이스(Start)와, 구간 안의 끊긴·semi-sharp·무한 샤프 엣지 수를 센다.
        /// 첫 값의 구간이 정점을 한 바퀴 돌아 이어지는 경우를 조심한다.
        /// </summary>
        private static void GatherValueSpans(in OsdLevel level, in OsdFVarLevel fvar, int vIndex, ValueSpan[] vValueSpans)
        {
            OsdRange vEdges = level.GetVertexEdges(vIndex);
            OsdRange vFaces = level.GetVertexFaces(vIndex);

            OsdLocalRange vFaceSiblings = fvar.GetVertexFaceSiblings(level, vIndex);

            bool vHasSingleValue = fvar.GetNumVertexValues(vIndex) == 1;
            bool vIsBoundary = vEdges.Count > vFaces.Count;
            bool vIsNonManifold = (level.VertTags.Ptr[vIndex] & OsdVTag.NonManifold) != 0;

            if (vIsNonManifold)
            {
                // 비다양체 정점 주변 구간도 다양체일 수 있지만, 지금은 모든 구간을 끊김으로 표시해 비다양체로 다룬다
                int vValueCount = fvar.GetNumVertexValues(vIndex);
                for (int i = 0; i < vValueCount; ++i)
                {
                    vValueSpans[i].Size = 0;
                    vValueSpans[i].DisctsEdgeCount = 1;
                }
            }
            else if (vHasSingleValue && vIsBoundary == false)
            {
                // 끊긴 엣지가 둘 이상인 내부 다트는 떨어진 구간으로 표시한다
                vValueSpans[0].Size = 0;
                vValueSpans[0].Start = 0;
                for (int i = 0; i < vEdges.Count; ++i)
                {
                    if ((fvar.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdFVarETag.Mismatch) != 0)
                    {
                        if (vValueSpans[0].Size > 0)
                        {
                            vValueSpans[0].DisctsEdgeCount = 1;
                            break;
                        }
                        else
                        {
                            vValueSpans[0].Size = vFaces.Count;
                            vValueSpans[0].Start = i;
                        }
                    }
                    else if ((level.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdETag.InfSharp) != 0)
                    {
                        ++vValueSpans[0].InfSharpEdgeCount;
                    }
                    else if ((level.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdETag.SemiSharp) != 0)
                    {
                        ++vValueSpans[0].SemiSharpEdgeCount;
                    }
                }
                vValueSpans[0].Size = vFaces.Count;
            }
            else
            {
                // 정점을 돌며 값마다 구간 정보를 쌓는다
                vValueSpans[0].Size = 1;
                vValueSpans[0].Start = 0;
                if (vIsBoundary == false && (vFaceSiblings.Ptr[vFaces.Count - 1] == 0))
                {
                    if ((fvar.EdgeTags.Ptr[vEdges.Ptr[0]] & OsdFVarETag.Mismatch) != 0)
                    {
                        ++vValueSpans[0].DisctsEdgeCount;
                    }
                    else if ((level.EdgeTags.Ptr[vEdges.Ptr[0]] & OsdETag.InfSharp) != 0)
                    {
                        ++vValueSpans[0].InfSharpEdgeCount;
                    }
                    else if ((level.EdgeTags.Ptr[vEdges.Ptr[0]] & OsdETag.SemiSharp) != 0)
                    {
                        ++vValueSpans[0].SemiSharpEdgeCount;
                    }
                }
                for (int i = 1; i < vFaces.Count; ++i)
                {
                    int sibling = vFaceSiblings.Ptr[i];
                    if (sibling == vFaceSiblings.Ptr[i - 1])
                    {
                        if ((fvar.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdFVarETag.Mismatch) != 0)
                        {
                            ++vValueSpans[sibling].DisctsEdgeCount;
                        }
                        else if ((level.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdETag.InfSharp) != 0)
                        {
                            ++vValueSpans[sibling].InfSharpEdgeCount;
                        }
                        else if ((level.EdgeTags.Ptr[vEdges.Ptr[i]] & OsdETag.SemiSharp) != 0)
                        {
                            ++vValueSpans[sibling].SemiSharpEdgeCount;
                        }
                    }
                    else
                    {
                        // 이 값의 구간을 이미 시작했다면 떨어진 구간으로 표시한다
                        if (vValueSpans[sibling].Size > 0)
                        {
                            ++vValueSpans[sibling].DisctsEdgeCount;
                        }
                        vValueSpans[sibling].Start = i;
                    }
                    ++vValueSpans[sibling].Size;
                }

                // 첫 값의 구간이 한 바퀴 돌아 이어졌으면, 그 구간이 다시 시작된 내부 엣지에서 더한 끊김을 뺀다
                if ((vFaceSiblings.Ptr[vFaces.Count - 1] == 0) && vIsBoundary == false)
                {
                    --vValueSpans[0].DisctsEdgeCount;
                }
            }
        }
    }
}
