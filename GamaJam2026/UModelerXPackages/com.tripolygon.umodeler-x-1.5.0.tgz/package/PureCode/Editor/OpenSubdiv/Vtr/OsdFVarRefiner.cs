﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 한 레벨 분할의 FVar(UV) 채널 매핑 (vtr/fvarRefinement.h 의 FVarRefinement). 부모↔자식 요소 매핑은 OsdRefinement 가 갖고,
    /// 여기에는 자식 값마다 부모 쪽 출처만 둔다. 버퍼는 OsdFVarRefiner.AllocateChild 가 할당하고 OsdFVarRefiner.RefineValues 가 채운다.
    /// 구조체를 복사하면 같은 메모리를 가리키므로 Free 는 소유한 쪽 변수에서 한 번만 부른다.
    /// </summary>
    public unsafe struct OsdFVarRefinement
    {
        /// <summary>
        /// 자식 값(값 오프셋 순)마다 부모 쪽 출처: 정점 자식이면 부모 정점의 형제 번호, 끊긴 엣지 자식이면 부모 엣지의 페이스 번호, 그 밖은 0.
        /// </summary>
        public OsdBuffer<ushort> ChildValueParentSource;

        /// <summary>자식 정점 vIndex 의 sibling 번째 값의 부모 쪽 출처 (FVarRefinement::getChildValueParentSource).</summary>
        public readonly int GetChildValueParentSource(in OsdFVarLevel childFVar, int vIndex, int sibling)
        {
            return ChildValueParentSource.Ptr[childFVar.GetVertexValueOffset(vIndex, sibling)];
        }

        /// <summary>버퍼를 해제한다. 같은 변수에서 두 번 불러도 안전하다. 관리 코드 전용.</summary>
        public void Free()
        {
            ChildValueParentSource.Free();
        }
    }

    /// <summary>
    /// FVar 채널의 균일 분할 (vtr/fvarRefinement.cpp 의 FVarRefinement::applyRefinement 균일 경로, Catmark 전용).
    /// EstimateChildValueCount·AllocateChild(관리 코드)가 원본의 estimateAndAllocateChildValues 처럼 자식 값 수를 위로 어림해 미리 할당하고,
    /// RefineValues(버스트 호환)가 채운 뒤 실제 값 수로 길이를 줄인다(trimAndFinalizeChildValues).
    /// 셋 다 OsdQuadRefiner.RefineTopology 앞에 부를 수 있도록 부모 레벨·FVar 와 버퍼 길이만 본다 (버스트 커널은 토폴로지와 FVar 분할을 한 번에 돈다).
    /// semi-sharp 재분류(reclassifySemisharpValues)는 옮기지 않았다: 사용자 크리스가 없어 semi-sharp 값이 생기지 않는다.
    /// </summary>
    public static unsafe class OsdFVarRefiner
    {
        /// <summary>Catmark 에서 자식 엣지 정점의 크리스 하나가 차지하는 자식 페이스 수 (정규 페이스 크기 4 → 2).</summary>
        private const int IncidentChildFacesPerEdge = 2;

        /// <summary>
        /// 자식 값 수의 상한 (FVarRefinement::estimateAndAllocateChildValues — 균일 분할에서는 정확한 값).
        /// 페이스 자식마다 1, 엣지 자식마다 (FVar 로 이어진 엣지면 1, 끊긴 엣지면 닿는 페이스 수), 정점 자식마다 부모 정점 값 수.
        /// 균일 분할이라 자식 정점은 부모 요소마다 하나다: 개수는 refinement 의 부모→자식 버퍼 길이(OsdQuadRefiner.AllocateChild 가 정한다)로 센다.
        /// 관리 코드다.
        /// </summary>
        public static int EstimateChildValueCount(in OsdLevel parent, in OsdFVarLevel parentFVar, in OsdRefinement refinement)
        {
            checked
            {
                int maxVertexValueCount = refinement.FaceChildVertIndex.Length;

                int edgeCount = refinement.EdgeChildVertIndex.Length;
                for (int pEdge = 0; pEdge < edgeCount; ++pEdge)
                {
                    maxVertexValueCount += parentFVar.EdgeTopologyMatches(pEdge) ? 1 : parent.EdgeFaceCountsAndOffsets.Ptr[2 * pEdge];
                }

                int vertCount = refinement.VertChildVertIndex.Length;
                for (int pVert = 0; pVert < vertCount; ++pVert)
                {
                    maxVertexValueCount += parentFVar.GetNumVertexValues(pVert);
                }
                return maxVertexValueCount;
            }
        }

        /// <summary>
        /// 자식 FVar 레벨과 FVar 분할 버퍼를 할당한다 (FVarLevel::resizeComponents + 값 버퍼 어림 할당). 관리 코드다.
        /// child 는 OsdQuadRefiner.AllocateChild 결과(분할 전이어도 된다)여야 한다: 개수 필드는 아직 0 일 수 있으므로 자식 레벨 버퍼 길이로 크기를 정한다
        /// (페이스 값 = 페이스-정점 길이, 엣지 태그 = 엣지 수, 정점별 = 정점 수, 정점-페이스 형제 = 정점-페이스 길이(어림치)).
        /// 값 버퍼는 estimatedValueCount 로 잡는다. 크리스 끝은 매끈한 경계에서만 쓰지만 부모 옵션을 모르므로 늘 잡는다. 모두 0 으로 채워진다.
        /// </summary>
        public static void AllocateChild(in OsdLevel child, int estimatedValueCount, out OsdFVarLevel childFVar, out OsdFVarRefinement fvarRefinement)
        {
            childFVar = default;
            fvarRefinement = default;
            try
            {
                childFVar.FaceVertValues = OsdBuffer<int>.Allocate(child.FaceVertIndices.Length);
                childFVar.EdgeTags = OsdBuffer<byte>.Allocate(child.EdgeTags.Length);
                childFVar.VertSiblingCounts = OsdBuffer<ushort>.Allocate(child.VertTags.Length);
                childFVar.VertSiblingOffsets = OsdBuffer<int>.Allocate(child.VertTags.Length);
                childFVar.VertFaceSiblings = OsdBuffer<ushort>.Allocate(child.VertFaceIndices.Length);

                childFVar.VertValueIndices = OsdBuffer<int>.Allocate(estimatedValueCount);
                childFVar.VertValueTags = OsdBuffer<byte>.Allocate(estimatedValueCount);
                childFVar.VertValueCreaseEnds = OsdBuffer<ushort>.Allocate(2 * estimatedValueCount);

                fvarRefinement.ChildValueParentSource = OsdBuffer<ushort>.Allocate(estimatedValueCount);
            }
            catch
            {
                childFVar.Free();
                fvarRefinement.Free();
                throw;
            }
        }

        /// <summary>
        /// FVarRefinement::applyRefinement 의 균일 경로. 버스트 호환 (포인터·blittable 만, 할당·예외 없음).
        /// OsdQuadRefiner.RefineTopology 를 마친 data(정점-페이스 포함)에, OsdFVarRefiner.AllocateChild 결과를 ChildFVar·FVarRefinement 로 넣어 부른다.
        /// 부모 옵션을 물려받고, 자식 값(정점 자식 → 페이스 자식 → 엣지 자식 순, 자식 정점 순서와 같다)·엣지 태그·값 태그·크리스 끝·페이스 값을 채운 뒤
        /// 값 버퍼 길이를 실제 값 수로 줄인다 (메모리는 그대로 — Free 가 블록 전체를 푼다).
        /// 어림치보다 값이 많으면(균일 분할에서는 생기지 않는다) 쓰기 전에 멈추고 Status 를 InvalidInput 으로 바꾼다. 성공하면 Status 는 건드리지 않는다.
        /// </summary>
        public static void RefineValues(OsdRefineLevelData* data)
        {
            OsdLevel* parent = &data->Parent;
            OsdLevel* child = &data->Child;
            OsdRefinement* refinement = &data->Refinement;
            OsdFVarLevel* parentFVar = &data->ParentFVar;
            OsdFVarLevel* childFVar = &data->ChildFVar;
            OsdFVarRefinement* fvarRefinement = &data->FVarRefinement;

            // 부모 → 자식 속성
            childFVar->Linear = parentFVar->Linear;
            childFVar->IsLinear = parentFVar->IsLinear;
            childFVar->HasLinearBoundaries = parentFVar->HasLinearBoundaries;
            childFVar->HasDependentSharpness = parentFVar->HasDependentSharpness;

            // resizeComponents: 정점-페이스 형제는 RefineTopology 가 줄인 실제 정점-페이스 길이에 맞춘다.
            // 원본은 0 으로 초기화한 버퍼에 일부만 쓰므로, 다시 불려도 같은 결과가 되게 0 으로 지운다
            childFVar->VertFaceSiblings.Length = child->VertFaceIndices.Length;
            Clear(childFVar->VertFaceSiblings.Ptr, childFVar->VertFaceSiblings.Length);
            Clear(fvarRefinement->ChildValueParentSource.Ptr, fvarRefinement->ChildValueParentSource.Length);
            Clear(childFVar->VertValueCreaseEnds.Ptr, childFVar->VertValueCreaseEnds.Length);

            if (PopulateChildValues(parent, child, refinement, parentFVar, childFVar, fvarRefinement) == false)
            {
                data->Status = (int)OsdStatus.InvalidInput;
                return;
            }
            TrimAndFinalizeChildValues(childFVar, fvarRefinement);

            PropagateEdgeTags(child, refinement, parentFVar, childFVar);
            PropagateValueTags(refinement, parentFVar, childFVar);
            if (childFVar->HasSmoothBoundaries)
            {
                PropagateValueCreases(refinement, parentFVar, childFVar);
            }

            // 자식 페이스 값은 정점-페이스 형제로 만들 수 있어 중복이지만, 쓰기 편하도록 여기서 만든다
            if (childFVar->ValueCount > child->VertCount)
            {
                InitializeFaceValuesFromVertexFaceSiblings(child, childFVar);
            }
            else
            {
                InitializeFaceValuesFromFaceVertices(child, childFVar);
            }
        }

        // ------------------------------------------------------------------
        // 자식 값 (FVarRefinement::populateChildValues*)
        // ------------------------------------------------------------------

        /// <summary>
        /// 자식 정점 순서와 같은 순서(정점 자식 → 페이스 자식 → 엣지 자식, orderVerticesFromFacesFirst = false)로 값을 매긴다.
        /// 어림치(ChildValueParentSource 길이)를 넘으면 false.
        /// </summary>
        private static bool PopulateChildValues(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement,
            OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement)
        {
            childFVar->ValueCount = 0;
            int capacity = fvarRefinement->ChildValueParentSource.Length;

            return PopulateChildValuesFromVertexVertices(parent, child, refinement, parentFVar, childFVar, fvarRefinement, capacity)
                && PopulateChildValuesFromFaceVertices(refinement, childFVar, capacity)
                && PopulateChildValuesFromEdgeVertices(parent, child, refinement, parentFVar, childFVar, fvarRefinement, capacity);
        }

        private static bool PopulateChildValuesFromFaceVertices(OsdRefinement* refinement, OsdFVarLevel* childFVar, int capacity)
        {
            int cVert = refinement->FirstChildVertFromFace;
            int cVertEnd = cVert + refinement->ChildVertFromFaceCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                if (childFVar->ValueCount + 1 > capacity)
                {
                    return false;
                }
                childFVar->VertSiblingOffsets.Ptr[cVert] = childFVar->ValueCount;
                childFVar->VertSiblingCounts.Ptr[cVert] = 1;
                childFVar->ValueCount++;
            }
            return true;
        }

        private static bool PopulateChildValuesFromEdgeVertices(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement,
            OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement, int capacity)
        {
            int cVert = refinement->FirstChildVertFromEdge;
            int cVertEnd = cVert + refinement->ChildVertFromEdgeCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                int pEdge = refinement->ChildVertexParentIndex.Ptr[cVert];

                childFVar->VertSiblingOffsets.Ptr[cVert] = childFVar->ValueCount;
                if (parentFVar->EdgeTopologyMatches(pEdge))
                {
                    if (childFVar->ValueCount + 1 > capacity)
                    {
                        return false;
                    }
                    childFVar->VertSiblingCounts.Ptr[cVert] = 1;
                    childFVar->ValueCount++;
                }
                else
                {
                    // 끊긴 엣지의 자식 값 수는 부모 엣지에 닿는 페이스 수다(적어도 1) — 쓰기 전에 확인한다
                    int edgeFaceCount = parent->EdgeFaceCountsAndOffsets.Ptr[2 * pEdge];
                    if (childFVar->ValueCount + (edgeFaceCount > 1 ? edgeFaceCount : 1) > capacity)
                    {
                        return false;
                    }
                    int cValueCount = PopulateChildValuesForEdgeVertex(parent, child, refinement, childFVar, fvarRefinement, cVert, pEdge);
                    childFVar->VertSiblingCounts.Ptr[cVert] = (ushort)cValueCount;
                    childFVar->ValueCount += cValueCount;
                }
            }
            return true;
        }

        private static bool PopulateChildValuesFromVertexVertices(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement,
            OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement, int capacity)
        {
            int cVert = refinement->FirstChildVertFromVert;
            int cVertEnd = cVert + refinement->ChildVertFromVertCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                int pVert = refinement->ChildVertexParentIndex.Ptr[cVert];

                childFVar->VertSiblingOffsets.Ptr[cVert] = childFVar->ValueCount;
                if (parentFVar->ValueTopologyMatches(parentFVar->GetVertexValueOffset(pVert)))
                {
                    if (childFVar->ValueCount + 1 > capacity)
                    {
                        return false;
                    }
                    childFVar->VertSiblingCounts.Ptr[cVert] = 1;
                    childFVar->ValueCount++;
                }
                else
                {
                    if (childFVar->ValueCount + parentFVar->GetNumVertexValues(pVert) > capacity)
                    {
                        return false;
                    }
                    int cValueCount = PopulateChildValuesForVertexVertex(parent, child, parentFVar, childFVar, fvarRefinement, cVert, pVert);
                    childFVar->VertSiblingCounts.Ptr[cVert] = (ushort)cValueCount;
                    childFVar->ValueCount += cValueCount;
                }
            }
            return true;
        }

        /// <summary>
        /// 끊긴 엣지의 자식 정점: 엣지에 닿는 부모 페이스마다 값 하나 (비다양체 엣지도 모두 다룬다). 자식 정점 주변 페이스의 형제 번호를
        /// 그 자식 페이스의 부모 페이스가 엣지-페이스 몇 번째인지로 정한다 (FVarRefinement::populateChildValuesForEdgeVertex).
        /// </summary>
        private static int PopulateChildValuesForEdgeVertex(OsdLevel* parent, OsdLevel* child, OsdRefinement* refinement,
            OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement, int cVert, int pEdge)
        {
            OsdRange pEdgeFaces = parent->GetEdgeFaces(pEdge);
            if (pEdgeFaces.Count == 1)
            {
                // 형제가 없어 첫 페이스(0)가 출처이고 페이스마다 형제 번호도 0 이다 — 초기화로 이미 됐다
                return 1;
            }

            // 자식 값마다 부모 쪽 출처
            int cValueCount = pEdgeFaces.Count;
            int cValueOffset = childFVar->GetVertexValueOffset(cVert);

            for (int i = 0; i < cValueCount; ++i)
            {
                fvarRefinement->ChildValueParentSource.Ptr[cValueOffset + i] = (ushort)i;
            }

            // 자식 정점에 닿는 페이스의 형제 번호
            OsdRange cVertFaces = child->GetVertexFaces(cVert);
            OsdLocalRange cVertFaceSiblings = childFVar->GetVertexFaceSiblings(*child, cVert);

            for (int i = 0; i < cVertFaceSiblings.Count; ++i)
            {
                int pFaceI = refinement->ChildFaceParentIndex.Ptr[cVertFaces.Ptr[i]];
                if (pEdgeFaces.Count == 2)
                {
                    // 부모 페이스가 둘뿐이고 형제 번호는 0 으로 초기화돼 있다
                    if (pFaceI == pEdgeFaces.Ptr[1])
                    {
                        cVertFaceSiblings.Ptr[i] = 1;
                    }
                }
                else
                {
                    // 부모 페이스가 셋 이상인 비다양체: 자식 페이스를 부모 페이스에 맞춘다
                    for (int j = 0; j < pEdgeFaces.Count; ++j)
                    {
                        if (pFaceI == pEdgeFaces.Ptr[j])
                        {
                            cVertFaceSiblings.Ptr[i] = (ushort)j;
                        }
                    }
                }
            }
            return cValueCount;
        }

        /// <summary>
        /// 불일치 정점의 자식 정점: 균일 분할이라 부모 정점 값과 일대일이다. 출처는 부모 형제 번호, 정점-페이스 형제는 부모 것을 그대로 쓴다
        /// (자식 정점의 페이스는 부모 정점의 페이스와 같은 순서다) (FVarRefinement::populateChildValuesForVertexVertex).
        /// </summary>
        private static int PopulateChildValuesForVertexVertex(OsdLevel* parent, OsdLevel* child,
            OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement, int cVert, int pVert)
        {
            int cValueCount = parentFVar->GetNumVertexValues(pVert);

            if (cValueCount > 1)
            {
                int cValueIndex = childFVar->GetVertexValueOffset(cVert);

                for (int j = 1; j < cValueCount; ++j)
                {
                    fvarRefinement->ChildValueParentSource.Ptr[cValueIndex + j] = (ushort)j;
                }

                OsdLocalRange pVertFaceSiblings = parentFVar->GetVertexFaceSiblings(*parent, pVert);
                OsdLocalRange cVertFaceSiblings = childFVar->GetVertexFaceSiblings(*child, cVert);
                for (int j = 0; j < cVertFaceSiblings.Count; ++j)
                {
                    cVertFaceSiblings.Ptr[j] = pVertFaceSiblings.Ptr[j];
                }
            }
            return cValueCount;
        }

        /// <summary>FVarRefinement::trimAndFinalizeChildValues: 값 버퍼를 실제 값 수로 줄이고, 분할된 레벨의 값 인덱스는 항등으로 채운다.</summary>
        private static void TrimAndFinalizeChildValues(OsdFVarLevel* childFVar, OsdFVarRefinement* fvarRefinement)
        {
            int valueCount = childFVar->ValueCount;

            childFVar->VertValueTags.Length = valueCount;
            childFVar->VertValueCreaseEnds.Length = 2 * valueCount;
            fvarRefinement->ChildValueParentSource.Length = valueCount;

            childFVar->VertValueIndices.Length = valueCount;
            for (int i = 0; i < valueCount; ++i)
            {
                childFVar->VertValueIndices.Ptr[i] = i;
            }
        }

        // ------------------------------------------------------------------
        // 태그·크리스 끝 전파 (FVarRefinement::propagate*)
        // ------------------------------------------------------------------

        /// <summary>
        /// 자식 엣지 태그: 페이스 자식 엣지는 이어진 것(0), 엣지 자식 엣지는 부모 엣지 태그를 물려받는다.
        /// </summary>
        private static void PropagateEdgeTags(OsdLevel* child, OsdRefinement* refinement, OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar)
        {
            int faceEdgeCount = refinement->ChildEdgeFromFaceCount;
            for (int eIndex = 0; eIndex < faceEdgeCount; ++eIndex)
            {
                childFVar->EdgeTags.Ptr[eIndex] = 0;
            }
            for (int eIndex = faceEdgeCount; eIndex < child->EdgeCount; ++eIndex)
            {
                int pEdge = refinement->ChildEdgeParentIndex.Ptr[eIndex];

                childFVar->EdgeTags.Ptr[eIndex] = parentFVar->EdgeTags.Ptr[pEdge];
            }
        }

        /// <summary>
        /// 자식 값 태그: 페이스 자식은 일치, 엣지 자식은 부모 엣지가 끊기거나 선형이면 불일치(매끈한 경계면 크리스까지), 정점 자식은 부모 값 태그를 물려받는다.
        /// </summary>
        private static void PropagateValueTags(OsdRefinement* refinement, OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar)
        {
            // 페이스 자식 값: 모두 일치하고 이어진 번호다
            const byte valTagMatch = 0;

            int cVert = refinement->FirstChildVertFromFace;
            int cVertEnd = cVert + refinement->ChildVertFromFaceCount;
            if (cVert < cVertEnd)
            {
                int cVertValue = childFVar->GetVertexValueOffset(cVert);
                for (; cVert < cVertEnd; ++cVert, ++cVertValue)
                {
                    childFVar->VertValueTags.Ptr[cVertValue] = valTagMatch;
                }
            }

            // 엣지 자식 값: 나뉜 엣지면 불일치, 부모에 크리스가 있으면(매끈한 경계) 크리스로
            const byte valTagMismatch = OsdValueTag.Mismatch;
            const byte valTagCrease = OsdValueTag.Mismatch | OsdValueTag.Crease;

            byte valTagSplitEdge = parentFVar->HasSmoothBoundaries ? valTagCrease : valTagMismatch;

            cVert = refinement->FirstChildVertFromEdge;
            cVertEnd = cVert + refinement->ChildVertFromEdgeCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                int pEdge = refinement->ChildVertexParentIndex.Ptr[cVert];

                byte* cValueTags = childFVar->GetVertexValueTags(cVert);
                int cValueCount = childFVar->GetNumVertexValues(cVert);

                byte pEdgeTag = parentFVar->EdgeTags.Ptr[pEdge];
                byte fill = ((pEdgeTag & (OsdFVarETag.Mismatch | OsdFVarETag.Linear)) != 0) ? valTagSplitEdge : valTagMatch;
                for (int i = 0; i < cValueCount; ++i)
                {
                    cValueTags[i] = fill;
                }
            }

            // 정점 자식 값: 완전한 자식이라 부모 값 태그를 그대로 물려받는다
            cVert = refinement->FirstChildVertFromVert;
            cVertEnd = cVert + refinement->ChildVertFromVertCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                int pVert = refinement->ChildVertexParentIndex.Ptr[cVert];

                byte* pValueTags = parentFVar->GetVertexValueTags(pVert);
                byte* cValueTags = childFVar->GetVertexValueTags(cVert);

                // 원본은 부모 값 수만큼 복사한다. 균일 분할에서는 자식 값 수와 같다 (다르면 자식 범위 밖을 쓰지 않도록 작은 쪽까지)
                int copyCount = parentFVar->GetNumVertexValues(pVert);
                int cValueCount = childFVar->GetNumVertexValues(cVert);
                if (copyCount > cValueCount)
                {
                    copyCount = cValueCount;
                }
                for (int i = 0; i < copyCount; ++i)
                {
                    cValueTags[i] = pValueTags[i];
                }
            }
        }

        /// <summary>
        /// 크리스 끝 (매끈한 경계에서만): 끊긴 엣지의 완전한 자식 정점은 크리스가 아닌 값(무한 샤프 제외)마다 자식 페이스 둘씩의 구간,
        /// 완전한 정점 자식은 부모 값의 크리스 끝을 그대로 쓴다.
        /// </summary>
        private static void PropagateValueCreases(OsdRefinement* refinement, OsdFVarLevel* parentFVar, OsdFVarLevel* childFVar)
        {
            // 페이스 자식은 건너뛴다

            int cVert = refinement->FirstChildVertFromEdge;
            int cVertEnd = cVert + refinement->ChildVertFromEdgeCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                byte* cValueTags = childFVar->GetVertexValueTags(cVert);

                if (OsdValueTag.IsMismatch(cValueTags[0]) == false)
                {
                    continue;
                }
                if (IsChildVertexComplete(refinement, cVert) == false)
                {
                    continue;
                }

                ushort* cValueCreaseEnds = childFVar->GetVertexValueCreaseEnds(cVert);
                int cValueCount = childFVar->GetNumVertexValues(cVert);

                int creaseStartFace = 0;
                int creaseEndFace = creaseStartFace + IncidentChildFacesPerEdge - 1;

                for (int i = 0; i < cValueCount; ++i)
                {
                    if (OsdValueTag.IsInfSharp(cValueTags[i]) == false)
                    {
                        cValueCreaseEnds[2 * i] = (ushort)creaseStartFace;
                        cValueCreaseEnds[2 * i + 1] = (ushort)creaseEndFace;
                    }
                    creaseStartFace += IncidentChildFacesPerEdge;
                    creaseEndFace += IncidentChildFacesPerEdge;
                }
            }

            cVert = refinement->FirstChildVertFromVert;
            cVertEnd = cVert + refinement->ChildVertFromVertCount;
            for (; cVert < cVertEnd; ++cVert)
            {
                byte* cValueTags = childFVar->GetVertexValueTags(cVert);

                if (OsdValueTag.IsMismatch(cValueTags[0]) == false)
                {
                    continue;
                }
                if (IsChildVertexComplete(refinement, cVert) == false)
                {
                    continue;
                }

                int pVert = refinement->ChildVertexParentIndex.Ptr[cVert];

                ushort* pCreaseEnds = parentFVar->GetVertexValueCreaseEnds(pVert);
                ushort* cCreaseEnds = childFVar->GetVertexValueCreaseEnds(cVert);
                int cValueCount = childFVar->GetNumVertexValues(cVert);

                for (int j = 0; j < cValueCount; ++j)
                {
                    if (OsdValueTag.IsInfSharp(cValueTags[j]) == false)
                    {
                        cCreaseEnds[2 * j] = pCreaseEnds[2 * j];
                        cCreaseEnds[2 * j + 1] = pCreaseEnds[2 * j + 1];
                    }
                }
            }
        }

        // ------------------------------------------------------------------
        // 페이스 값 (FVarLevel::initializeFaceValuesFrom*)
        // ------------------------------------------------------------------

        /// <summary>값과 정점이 일대일이면 페이스 값 = 페이스 정점.</summary>
        private static void InitializeFaceValuesFromFaceVertices(OsdLevel* child, OsdFVarLevel* childFVar)
        {
            int total = child->FaceVertIndices.Length;
            int* source = child->FaceVertIndices.Ptr;
            int* destination = childFVar->FaceVertValues.Ptr;
            for (int i = 0; i < total; ++i)
            {
                destination[i] = source[i];
            }
        }

        /// <summary>
        /// 페이스 코너마다 그 정점의 첫 값 오프셋을 넣고, 값이 여럿인 정점만 정점-페이스 형제 번호를 더한다
        /// (메모리 순서가 좋은 첫 순회 + 드문 둘째 순회).
        /// </summary>
        private static void InitializeFaceValuesFromVertexFaceSiblings(OsdLevel* child, OsdFVarLevel* childFVar)
        {
            int total = child->FaceVertIndices.Length;
            int* fvIndices = child->FaceVertIndices.Ptr;
            int* faceVertValues = childFVar->FaceVertValues.Ptr;
            for (int i = 0; i < total; ++i)
            {
                faceVertValues[i] = childFVar->GetVertexValueOffset(fvIndices[i]);
            }

            for (int vIndex = 0; vIndex < child->VertCount; ++vIndex)
            {
                if (childFVar->GetNumVertexValues(vIndex) > 1)
                {
                    OsdRange vFaces = child->GetVertexFaces(vIndex);
                    OsdLocalRange vInFace = child->GetVertexFaceLocalIndices(vIndex);
                    OsdLocalRange vSiblings = childFVar->GetVertexFaceSiblings(*child, vIndex);

                    for (int j = 0; j < vFaces.Count; ++j)
                    {
                        if (vSiblings.Ptr[j] != 0)
                        {
                            int fvOffset = child->FaceVertCountsAndOffsets.Ptr[2 * vFaces.Ptr[j] + 1];

                            faceVertValues[fvOffset + vInFace.Ptr[j]] += vSiblings.Ptr[j];
                        }
                    }
                }
            }
        }

        // ------------------------------------------------------------------
        // 도우미 (버스트 호환)
        // ------------------------------------------------------------------

        /// <summary>Refinement::isChildVertexComplete (균일 분할에서는 늘 완전하다).</summary>
        private static bool IsChildVertexComplete(OsdRefinement* refinement, int cVert)
        {
            return (refinement->ChildVertexTags.Ptr[cVert] & OsdChildTag.Incomplete) == 0;
        }

        private static void Clear(ushort* values, int count)
        {
            for (int i = 0; i < count; ++i)
            {
                values[i] = 0;
            }
        }
    }
}
