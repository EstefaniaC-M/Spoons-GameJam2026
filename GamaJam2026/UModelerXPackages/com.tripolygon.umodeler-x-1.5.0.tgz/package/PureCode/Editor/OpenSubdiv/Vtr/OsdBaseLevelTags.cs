﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 레벨 0 의 태그와 경계 샤프니스 (far/topologyRefinerFactory.cpp 의 prepareComponentTagsAndSharpness, Catmark 전용).
    /// 관리 코드다 (버스트 함수가 아니다). 사용자 크리스·구멍은 없다 (래퍼가 넘기지 않는다):
    /// 엣지 샤프니스는 0 에서 시작해 경계·비다양체 규칙으로만 무한이 된다.
    /// 정점 샤프니스는 호출자가 레벨 0 에 0 또는 무한을 미리 넣어 둘 수 있고, 그 값에서 시작해 경계·비다양체·코너 규칙으로 무한이 된다.
    /// </summary>
    public static unsafe class OsdBaseLevelTags
    {
        // Catmark 의 정규 페이스 크기와 정규 내부·경계 밸런스 (Sdc::SchemeTypeTraits)
        private const int RegularFaceSize = 4;
        private const int RegularInteriorValence = 4;
        private const int RegularBoundaryValence = RegularInteriorValence / 2;

        /// <summary>
        /// OsdLevelBuilder.BuildBaseLevel 이 만든 레벨에 엣지·정점 태그와 샤프니스를 붙인다. 레벨마다 한 번만 부른다.
        /// hasIrregularFaces 는 쿼드가 아닌 페이스가 있는지 (TopologyRefiner::_hasIrregFaces).
        /// </summary>
        public static void Apply(ref OsdLevel level, OsdBoundaryInterpolation boundary, out bool hasIrregularFaces)
        {
            // 원본은 페이스 크기를 넣을 때(setNumBaseFaceVertices) 정한다
            hasIrregularFaces = false;
            for (int f = 0; f < level.FaceCount; ++f)
            {
                if (level.FaceVertCountsAndOffsets.Ptr[2 * f] != RegularFaceSize)
                {
                    hasIrregularFaces = true;
                    break;
                }
            }

            // makeBoundaryFacesHoles 는 VTX_BOUNDARY_NONE 일 때만 참이다. 이 이식은 NONE 을 쓰지 않으므로 경계 페이스 구멍 처리는 옮기지 않았다.
            bool sharpenCornerVerts = boundary == OsdBoundaryInterpolation.EdgeAndCorner;
            const bool sharpenNonManFeatures = true;

            // 엣지 태그를 먼저 정한다 (정점 태그, 특히 규칙이 닿는 엣지 속성에 기댄다)
            for (int eIndex = 0; eIndex < level.EdgeCount; ++eIndex)
            {
                byte eTag = level.EdgeTags.Ptr[eIndex];
                float eSharpness = level.EdgeSharpness.Ptr[eIndex];

                bool isBoundary = level.EdgeFaceCountsAndOffsets.Ptr[2 * eIndex] < 2;
                eTag = Assign(eTag, OsdETag.Boundary, isBoundary);
                if (isBoundary || ((eTag & OsdETag.NonManifold) != 0 && sharpenNonManFeatures))
                {
                    eSharpness = OsdConstants.SharpnessInfinite;
                }
                bool infSharp = OsdCrease.IsInfinite(eSharpness);
                eTag = Assign(eTag, OsdETag.InfSharp, infSharp);
                eTag = Assign(eTag, OsdETag.SemiSharp, OsdCrease.IsSharp(eSharpness) && infSharp == false);

                level.EdgeTags.Ptr[eIndex] = eTag;
                level.EdgeSharpness.Ptr[eIndex] = eSharpness;
            }

            // 정점 태그 (semi-sharp 와 규칙은 닿는 엣지를 모두 봐야 한다)
            for (int vIndex = 0; vIndex < level.VertCount; ++vIndex)
            {
                ushort vTag = level.VertTags.Ptr[vIndex];
                float vSharpness = level.VertSharpness.Ptr[vIndex];

                OsdRange vEdges = level.GetVertexEdges(vIndex);
                OsdRange vFaces = level.GetVertexFaces(vIndex);

                // 닿는 엣지의 속성 집계
                int boundaryEdgeCount = 0;
                int infSharpEdgeCount = 0;
                int semiSharpEdgeCount = 0;
                int nonManifoldEdgeCount = 0;
                for (int i = 0; i < vEdges.Count; ++i)
                {
                    byte eTag = level.EdgeTags.Ptr[vEdges.Ptr[i]];

                    boundaryEdgeCount += (eTag & OsdETag.Boundary) != 0 ? 1 : 0;
                    infSharpEdgeCount += (eTag & OsdETag.InfSharp) != 0 ? 1 : 0;
                    semiSharpEdgeCount += (eTag & OsdETag.SemiSharp) != 0 ? 1 : 0;
                    nonManifoldEdgeCount += (eTag & OsdETag.NonManifold) != 0 ? 1 : 0;
                }
                int sharpEdgeCount = infSharpEdgeCount + semiSharpEdgeCount;

                // 규칙을 정하기 전에 정점을 샤프하게 만든다
                bool isNonManifold = (vTag & OsdVTag.NonManifold) != 0;
                bool isTopologicalCorner = vFaces.Count == 1 && vEdges.Count == 2;
                bool isSharpenedCorner = isTopologicalCorner && sharpenCornerVerts;
                if (isSharpenedCorner)
                {
                    vSharpness = OsdConstants.SharpnessInfinite;
                }
                else if (isNonManifold && sharpenNonManFeatures)
                {
                    // 내부 비다양체 크리스(마주 보는 비다양체 엣지 둘, 경계 없음, 지느러미만큼 페이스가 엣지보다 많음)의 정점은 샤프하게 만들지 않는다
                    if ((nonManifoldEdgeCount == 2 && boundaryEdgeCount == 0 && vFaces.Count > vEdges.Count) == false)
                    {
                        vSharpness = OsdConstants.SharpnessInfinite;
                    }
                }

                bool isInfSharp = OsdCrease.IsInfinite(vSharpness);
                vTag = Assign(vTag, OsdVTag.InfSharp, isInfSharp);
                vTag = Assign(vTag, OsdVTag.SemiSharp, OsdCrease.IsSemiSharp(vSharpness));
                vTag = Assign(vTag, OsdVTag.SemiSharpEdges, semiSharpEdgeCount > 0);

                vTag = OsdVTag.SetRule(vTag, OsdCrease.DetermineVertexVertexRule(vSharpness, sharpEdgeCount));

                // 위상 태그 — 비다양체면 Xordinary 를 붙이지 않는다
                bool isBoundary = boundaryEdgeCount > 0;
                bool isCorner = isTopologicalCorner && isInfSharp;
                bool isXordinary;
                if (isNonManifold)
                {
                    isXordinary = false;
                }
                else if (isCorner)
                {
                    isXordinary = false;
                }
                else if (isBoundary)
                {
                    isXordinary = vFaces.Count != RegularBoundaryValence;
                }
                else
                {
                    isXordinary = vFaces.Count != RegularInteriorValence;
                }
                vTag = Assign(vTag, OsdVTag.Boundary, isBoundary);
                vTag = Assign(vTag, OsdVTag.Corner, isCorner);
                vTag = Assign(vTag, OsdVTag.Xordinary, isXordinary);
                vTag = Assign(vTag, OsdVTag.Incomplete, false);

                // 무한 샤프 크리스가 정규 토폴로지를 나누는 경우를 가리는 태그 (semi-sharp 없음, 지금은 다양체만)
                bool hasInfSharpEdges = infSharpEdgeCount > 0;
                bool isInfSharpCrease = false;
                bool isInfIrregular = isInfSharp || hasInfSharpEdges;

                if (hasInfSharpEdges)
                {
                    // 무한 규칙에서는 semi-sharp 정점 샤프니스를 무시한다
                    OsdRule infRule = OsdCrease.DetermineVertexVertexRule(isInfSharp ? vSharpness : 0.0f, infSharpEdgeCount);

                    if (infRule == OsdRule.Crease)
                    {
                        isInfSharpCrease = true;

                        // 정규 무한 크리스는 다양체 정규 경계를 따라가거나 다양체 내부를 둘로 가를 때뿐이다
                        if (isXordinary == false && isNonManifold == false)
                        {
                            if (isBoundary)
                            {
                                isInfIrregular = false;
                            }
                            else
                            {
                                // Catmark 정규 내부 밸런스 4: 마주 보는 엣지 0·2 의 무한 샤프 여부가 다르면 불규칙
                                bool edge0InfSharp = (level.EdgeTags.Ptr[vEdges.Ptr[0]] & OsdETag.InfSharp) != 0;
                                bool edge2InfSharp = (level.EdgeTags.Ptr[vEdges.Ptr[2]] & OsdETag.InfSharp) != 0;
                                isInfIrregular = edge0InfSharp != edge2InfSharp;
                            }
                        }
                    }
                    else if (infRule == OsdRule.Corner)
                    {
                        // 모든 엣지가 샤프하고 매끈한 코너가 아니면 정규 무한 코너다
                        if (infSharpEdgeCount == vEdges.Count && (vEdges.Count > 2 || isInfSharp))
                        {
                            isInfIrregular = false;
                        }
                    }
                }
                vTag = Assign(vTag, OsdVTag.InfSharpEdges, hasInfSharpEdges);
                vTag = Assign(vTag, OsdVTag.InfSharpCrease, isInfSharpCrease);
                vTag = Assign(vTag, OsdVTag.InfIrregular, isInfIrregular);

                // 쿼드 아닌 페이스가 있으면 정점마다 그런 페이스에 닿는지 표시한다
                if (hasIrregularFaces)
                {
                    for (int i = 0; i < vFaces.Count; ++i)
                    {
                        if (level.FaceVertCountsAndOffsets.Ptr[2 * vFaces.Ptr[i]] != RegularFaceSize)
                        {
                            vTag |= OsdVTag.IncidIrregFace;
                            break;
                        }
                    }
                }

                level.VertTags.Ptr[vIndex] = vTag;
                level.VertSharpness.Ptr[vIndex] = vSharpness;
            }
        }

        private static byte Assign(byte tag, byte bit, bool value)
        {
            return value ? (byte)(tag | bit) : (byte)(tag & ~bit);
        }

        private static ushort Assign(ushort tag, ushort bit, bool value)
        {
            return value ? (ushort)(tag | bit) : (ushort)(tag & ~bit);
        }
    }
}
