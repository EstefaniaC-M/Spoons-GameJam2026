﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 정점 태그 비트 (vtr/level.h 의 Level::VTag 비트필드를 같은 비트 위치의 ushort 로 옮긴 것).
    /// Rule 은 4 비트 필드라 GetRule/SetRule 로 읽고 쓴다.
    /// </summary>
    public static class OsdVTag
    {
        public const ushort NonManifold = 1 << 0;
        public const ushort Xordinary = 1 << 1;
        public const ushort Boundary = 1 << 2;
        public const ushort Corner = 1 << 3;
        public const ushort InfSharp = 1 << 4;
        public const ushort SemiSharp = 1 << 5;
        public const ushort SemiSharpEdges = 1 << 6;
        public const ushort RuleShift = 7;
        public const ushort RuleMask = 0xF << 7;

        /// <summary>분할된 레벨에서만 쓴다.</summary>
        public const ushort Incomplete = 1 << 11;

        /// <summary>레벨 0 에서만 쓴다: 쿼드가 아닌 페이스에 닿는다.</summary>
        public const ushort IncidIrregFace = 1 << 12;

        public const ushort InfSharpEdges = 1 << 13;
        public const ushort InfSharpCrease = 1 << 14;
        public const ushort InfIrregular = 1 << 15;

        public static OsdRule GetRule(ushort tag)
        {
            return (OsdRule)((tag & RuleMask) >> RuleShift);
        }

        public static ushort SetRule(ushort tag, OsdRule rule)
        {
            return (ushort)((tag & ~RuleMask) | (((int)rule << RuleShift) & RuleMask));
        }
    }

    /// <summary>엣지 태그 비트 (Level::ETag).</summary>
    public static class OsdETag
    {
        public const byte NonManifold = 1;
        public const byte Boundary = 2;
        public const byte InfSharp = 4;
        public const byte SemiSharp = 8;
    }

    /// <summary>페이스 태그 비트 (Level::FTag).</summary>
    public static class OsdFTag
    {
        public const byte Hole = 1;
    }

    /// <summary>
    /// 한 분할 레벨의 토폴로지 (vtr/level.h 의 Level). 여섯 관계(페이스-정점·페이스-엣지·엣지-정점·엣지-페이스·정점-페이스·정점-엣지)를
    /// 비관리 버퍼의 SOA 로 가진다. "CountsAndOffsets" 버퍼는 요소마다 (개수, 시작 오프셋) 두 칸이다.
    /// 구조체를 복사하면 같은 메모리를 가리키므로 Free 는 소유한 쪽 변수에서 한 번만 부른다.
    /// 접근자는 버스트 호환이다 (포인터만 쓰고 예외·관리 객체 없음, readonly 라 in 매개변수로 넘겨도 복사가 생기지 않는다).
    /// FVar 채널은 레벨에 두지 않고 따로 다룬다.
    /// </summary>
    public unsafe struct OsdLevel
    {
        public int FaceCount;
        public int EdgeCount;
        public int VertCount;

        /// <summary>분할 깊이 (레벨 0 은 0).</summary>
        public int Depth;

        public int MaxEdgeFaces;

        /// <summary>정점 밸런스와 페이스 크기의 최대값 (데이터 버퍼 크기 산정용).</summary>
        public int MaxValence;

        // 페이스별
        public OsdBuffer<int> FaceVertCountsAndOffsets;
        public OsdBuffer<int> FaceVertIndices;
        public OsdBuffer<int> FaceEdgeIndices;
        public OsdBuffer<byte> FaceTags;

        // 엣지별
        public OsdBuffer<int> EdgeVertIndices;
        public OsdBuffer<int> EdgeFaceCountsAndOffsets;
        public OsdBuffer<int> EdgeFaceIndices;
        public OsdBuffer<ushort> EdgeFaceLocalIndices;
        public OsdBuffer<float> EdgeSharpness;
        public OsdBuffer<byte> EdgeTags;

        // 정점별
        public OsdBuffer<int> VertFaceCountsAndOffsets;
        public OsdBuffer<int> VertFaceIndices;
        public OsdBuffer<ushort> VertFaceLocalIndices;
        public OsdBuffer<int> VertEdgeCountsAndOffsets;
        public OsdBuffer<int> VertEdgeIndices;
        public OsdBuffer<ushort> VertEdgeLocalIndices;
        public OsdBuffer<float> VertSharpness;
        public OsdBuffer<ushort> VertTags;

        public readonly OsdRange GetFaceVertices(int f)
        {
            OsdRange range;
            range.Ptr = FaceVertIndices.Ptr + FaceVertCountsAndOffsets.Ptr[2 * f + 1];
            range.Count = FaceVertCountsAndOffsets.Ptr[2 * f];
            return range;
        }

        /// <summary>페이스-엣지는 페이스-정점과 같은 개수·오프셋을 쓴다. 엣지 i 는 코너 i 에서 코너 i + 1 로 간다.</summary>
        public readonly OsdRange GetFaceEdges(int f)
        {
            OsdRange range;
            range.Ptr = FaceEdgeIndices.Ptr + FaceVertCountsAndOffsets.Ptr[2 * f + 1];
            range.Count = FaceVertCountsAndOffsets.Ptr[2 * f];
            return range;
        }

        public readonly OsdRange GetEdgeVertices(int e)
        {
            OsdRange range;
            range.Ptr = EdgeVertIndices.Ptr + 2 * e;
            range.Count = 2;
            return range;
        }

        public readonly OsdRange GetEdgeFaces(int e)
        {
            OsdRange range;
            range.Ptr = EdgeFaceIndices.Ptr + EdgeFaceCountsAndOffsets.Ptr[2 * e + 1];
            range.Count = EdgeFaceCountsAndOffsets.Ptr[2 * e];
            return range;
        }

        /// <summary>정점에 닿는 페이스. 다양체 정점은 반시계로 정렬돼 있다.</summary>
        public readonly OsdRange GetVertexFaces(int v)
        {
            OsdRange range;
            range.Ptr = VertFaceIndices.Ptr + VertFaceCountsAndOffsets.Ptr[2 * v + 1];
            range.Count = VertFaceCountsAndOffsets.Ptr[2 * v];
            return range;
        }

        /// <summary>정점에 닿는 엣지. 다양체 정점은 반시계로 정렬돼 있다 (엣지 i 는 페이스 i 의 앞 엣지).</summary>
        public readonly OsdRange GetVertexEdges(int v)
        {
            OsdRange range;
            range.Ptr = VertEdgeIndices.Ptr + VertEdgeCountsAndOffsets.Ptr[2 * v + 1];
            range.Count = VertEdgeCountsAndOffsets.Ptr[2 * v];
            return range;
        }

        /// <summary>엣지-페이스 i 의 페이스 안에서 이 엣지의 위치.</summary>
        public readonly OsdLocalRange GetEdgeFaceLocalIndices(int e)
        {
            OsdLocalRange range;
            range.Ptr = EdgeFaceLocalIndices.Ptr + EdgeFaceCountsAndOffsets.Ptr[2 * e + 1];
            range.Count = EdgeFaceCountsAndOffsets.Ptr[2 * e];
            return range;
        }

        /// <summary>정점-페이스 i 의 페이스 안에서 이 정점의 위치.</summary>
        public readonly OsdLocalRange GetVertexFaceLocalIndices(int v)
        {
            OsdLocalRange range;
            range.Ptr = VertFaceLocalIndices.Ptr + VertFaceCountsAndOffsets.Ptr[2 * v + 1];
            range.Count = VertFaceCountsAndOffsets.Ptr[2 * v];
            return range;
        }

        /// <summary>정점-엣지 i 의 엣지 안에서 이 정점의 위치 (0 또는 1).</summary>
        public readonly OsdLocalRange GetVertexEdgeLocalIndices(int v)
        {
            OsdLocalRange range;
            range.Ptr = VertEdgeLocalIndices.Ptr + VertEdgeCountsAndOffsets.Ptr[2 * v + 1];
            range.Count = VertEdgeCountsAndOffsets.Ptr[2 * v];
            return range;
        }

        /// <summary>
        /// v0 의 엣지 중 v1 에 닿는 첫 엣지 (없으면 OsdConstants.IndexInvalid). v0 == v1 이면 퇴화 엣지(양 끝이 같은 엣지)를 찾는다.
        /// </summary>
        public readonly int FindEdge(int v0, int v1)
        {
            OsdRange v0Edges = GetVertexEdges(v0);
            if (v0 != v1)
            {
                for (int j = 0; j < v0Edges.Count; ++j)
                {
                    int* eVerts = EdgeVertIndices.Ptr + 2 * v0Edges.Ptr[j];
                    if (eVerts[0] == v1 || eVerts[1] == v1)
                    {
                        return v0Edges.Ptr[j];
                    }
                }
            }
            else
            {
                for (int j = 0; j < v0Edges.Count; ++j)
                {
                    int* eVerts = EdgeVertIndices.Ptr + 2 * v0Edges.Ptr[j];
                    if (eVerts[0] == eVerts[1])
                    {
                        return v0Edges.Ptr[j];
                    }
                }
            }
            return OsdConstants.IndexInvalid;
        }

        /// <summary>모든 버퍼를 해제하고 개수를 0 으로 되돌린다. 같은 변수에서 두 번 불러도 안전하다. 관리 코드 전용.</summary>
        public void Free()
        {
            FaceVertCountsAndOffsets.Free();
            FaceVertIndices.Free();
            FaceEdgeIndices.Free();
            FaceTags.Free();

            EdgeVertIndices.Free();
            EdgeFaceCountsAndOffsets.Free();
            EdgeFaceIndices.Free();
            EdgeFaceLocalIndices.Free();
            EdgeSharpness.Free();
            EdgeTags.Free();

            VertFaceCountsAndOffsets.Free();
            VertFaceIndices.Free();
            VertFaceLocalIndices.Free();
            VertEdgeCountsAndOffsets.Free();
            VertEdgeIndices.Free();
            VertEdgeLocalIndices.Free();
            VertSharpness.Free();
            VertTags.Free();

            FaceCount = 0;
            EdgeCount = 0;
            VertCount = 0;
            Depth = 0;
            MaxEdgeFaces = 0;
            MaxValence = 0;
        }
    }
}
