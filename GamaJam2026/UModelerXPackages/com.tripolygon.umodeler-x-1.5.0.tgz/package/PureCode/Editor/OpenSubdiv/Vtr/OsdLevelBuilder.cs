﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

using System;
using System.Collections.Generic;

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 페이스-정점 목록에서 레벨 0 토폴로지를 완성한다. far/topologyRefinerFactory.cpp 의 크기 검사(prepareComponentTopologySizing)와
    /// TopologyDescriptor 입력 처리(오른손 와인딩), vtr/level.cpp 의 completeTopologyFromFaceVertices·orientIncidentComponents·
    /// orderVertexFacesAndEdges·populateLocalIndices 를 옮겼다. 관리 코드다 (버스트 함수가 아니다). 결과만 OsdBuffer 에 담는다.
    /// 태그·샤프니스는 OsdBaseLevelTags.Apply 가 이어서 붙인다.
    /// </summary>
    public static unsafe class OsdLevelBuilder
    {
        /// <summary>정점-페이스·정점-엣지 동적 관계가 요소마다 미리 잡는 멤버 수 (원본 avgSize).</summary>
        private const int AverageMemberCount = 6;

        /// <summary>
        /// 레벨 0 을 만든다. 정점 수만큼의 정점을 그대로 쓴다 (페이스가 쓰지 않는 고립 정점도 포함 — 원본과 같다).
        /// 호출자 계약(원본도 검사하지 않는다): 페이스 크기는 0 이상, 페이스-정점 인덱스는 [0, vertCount) 안.
        /// 실패하면 level 은 아무것도 할당하지 않은 default 다.
        /// </summary>
        /// <param name="faceVertCounts">페이스마다 코너 수 (faceCount 개).</param>
        /// <param name="faceVertIndices">페이스 순서대로 이어 붙인 코너 정점 인덱스 (코너 수 합계 개).</param>
        public static OsdStatus BuildBaseLevel(int vertCount, int faceCount, int* faceVertCounts, int* faceVertIndices, out OsdLevel level)
        {
            level = default;

            // prepareComponentTopologySizing 의 거절 조건 (원본 순서 그대로)
            if (vertCount <= 0)
            {
                return OsdStatus.NoVertices;
            }
            if (faceCount <= 0)
            {
                return OsdStatus.NoFaces;
            }

            // 원본은 resizeFaceVertices 가 페이스 크기 최대값으로 MaxValence 를 먼저 초기화하고 그 값으로 페이스 크기를 검사한다
            int maxFaceSize = 0;
            int faceVertTotal = 0;
            for (int f = 0; f < faceCount; ++f)
            {
                int count = faceVertCounts[f];
                maxFaceSize = Math.Max(maxFaceSize, count);
                faceVertTotal += count;
            }
            if (maxFaceSize > OsdConstants.ValenceLimit)
            {
                return OsdStatus.FaceTooLarge;
            }
            if (faceVertTotal == 0)
            {
                // 원본: "mesh contains no face-vertices"
                return OsdStatus.InvalidInput;
            }

            level.VertCount = vertCount;
            level.FaceCount = faceCount;
            level.Depth = 0;
            level.MaxValence = maxFaceSize;

            // resizeComponentTopology + assignComponentTopology (TopologyDescriptor, isLeftHanded == false)
            level.FaceVertCountsAndOffsets = OsdBuffer<int>.Allocate(2 * faceCount);
            level.FaceVertIndices = OsdBuffer<int>.Allocate(faceVertTotal);
            level.FaceEdgeIndices = OsdBuffer<int>.Allocate(faceVertTotal);
            level.FaceTags = OsdBuffer<byte>.Allocate(faceCount);
            level.VertSharpness = OsdBuffer<float>.Allocate(vertCount);
            level.VertTags = OsdBuffer<ushort>.Allocate(vertCount);

            int offset = 0;
            for (int f = 0; f < faceCount; ++f)
            {
                level.FaceVertCountsAndOffsets.Ptr[2 * f] = faceVertCounts[f];
                level.FaceVertCountsAndOffsets.Ptr[2 * f + 1] = offset;
                offset += faceVertCounts[f];
            }
            for (int i = 0; i < faceVertTotal; ++i)
            {
                level.FaceVertIndices.Ptr[i] = faceVertIndices[i];
            }

            if (CompleteTopologyFromFaceVertices(ref level) == false)
            {
                level.Free();
                level = default;
                return OsdStatus.ValenceOverflow;
            }
            return OsdStatus.Ok;
        }

        /// <summary>
        /// Level::completeTopologyFromFaceVertices. 엣지를 만들고 엣지-페이스·정점-페이스·정점-엣지를 채운 뒤,
        /// 비다양체 엣지와 그 끝 정점을 표시하고 정점 주변을 정렬하고 로컬 인덱스를 채운다. 밸런스가 한도를 넘으면 false.
        /// </summary>
        private static bool CompleteTopologyFromFaceVertices(ref OsdLevel level)
        {
            int vCount = level.VertCount;
            int fCount = level.FaceCount;

            // 엣지 수는 아직 모른다: 원본처럼 정점 수 × 2 를 추정치로 예약한다
            int eCountEstimate = vCount << 1;
            List<int> edgeVertIndices = new List<int>(eCountEstimate * 2);
            int edgeCount = 0;

            DynamicRelation dynEdgeFaces = new DynamicRelation(0, 2, eCountEstimate);
            DynamicRelation dynVertFaces = new DynamicRelation(vCount, AverageMemberCount, vCount);
            DynamicRelation dynVertEdges = new DynamicRelation(vCount, AverageMemberCount, vCount);

            // 만들면서 비다양체로 판정한 엣지
            List<int> nonManifoldEdges = new List<int>();

            int* countsAndOffsets = level.FaceVertCountsAndOffsets.Ptr;
            for (int fIndex = 0; fIndex < fCount; ++fIndex)
            {
                int fSize = countsAndOffsets[2 * fIndex];
                int* fVerts = level.FaceVertIndices.Ptr + countsAndOffsets[2 * fIndex + 1];
                int* fEdges = level.FaceEdgeIndices.Ptr + countsAndOffsets[2 * fIndex + 1];

                for (int i = 0; i < fSize; ++i)
                {
                    int v0Index = fVerts[i];
                    int v1Index = fVerts[(i + 1) % fSize];

                    // 퇴화(v0 == v1)가 아니면 v0 의 엣지에서 [v0, v1] 을 찾는다. 퇴화면 매번 새 엣지를 만들도록 무효로 둔다
                    int eIndex;
                    if (v0Index != v1Index)
                    {
                        eIndex = FindEdge(edgeVertIndices, dynVertEdges, v0Index, v1Index);
                    }
                    else
                    {
                        eIndex = OsdConstants.IndexInvalid;
                        nonManifoldEdges.Add(edgeCount);
                    }

                    // 이미 있는 엣지면 비다양체인지 본다: 이미 페이스 둘에 쓰였거나, 첫 페이스와 같은 방향이면(와인딩 반대) 비다양체.
                    // 이 페이스가 이미 이 엣지를 쓰고 있으면 새 인스턴스를 만든다
                    if (eIndex != OsdConstants.IndexInvalid)
                    {
                        int eFaceCount = dynEdgeFaces.GetMemberCount(eIndex);
                        if (dynEdgeFaces.GetMember(eIndex, eFaceCount - 1) == fIndex)
                        {
                            nonManifoldEdges.Add(eIndex);
                            nonManifoldEdges.Add(edgeCount);
                            eIndex = OsdConstants.IndexInvalid;
                        }
                        else if (eFaceCount > 1)
                        {
                            nonManifoldEdges.Add(eIndex);
                        }
                        else if (v0Index == edgeVertIndices[2 * eIndex])
                        {
                            nonManifoldEdges.Add(eIndex);
                        }
                    }
                    if (eIndex == OsdConstants.IndexInvalid)
                    {
                        eIndex = edgeCount;

                        ++edgeCount;
                        edgeVertIndices.Add(v0Index);
                        edgeVertIndices.Add(v1Index);

                        dynEdgeFaces.AppendComponent();

                        dynVertEdges.AppendCompMember(v0Index, eIndex);
                        dynVertEdges.AppendCompMember(v1Index, eIndex);
                    }

                    dynEdgeFaces.AppendCompMember(eIndex, fIndex);
                    dynVertFaces.AppendCompMember(v0Index, fIndex);

                    fEdges[i] = eIndex;
                }
            }

            // 멤버를 압축하며 최대값을 구한다. MaxValence 는 페이스 크기 최대값으로 시작했고,
            // 비다양체에서는 페이스 수가 엣지 수보다 많을 수 있어 둘 다 본다
            int maxEdgeFaces = dynEdgeFaces.CompressMemberIndices();
            int maxVertFaces = dynVertFaces.CompressMemberIndices();
            int maxVertEdges = dynVertEdges.CompressMemberIndices();

            level.MaxEdgeFaces = maxEdgeFaces;
            level.MaxValence = Math.Max(maxVertFaces, level.MaxValence);
            level.MaxValence = Math.Max(maxVertEdges, level.MaxValence);

            // 엣지-페이스 최대값이 넘치면 밸런스도 넘치므로 하나만 본다
            if (level.MaxValence > OsdConstants.ValenceLimit)
            {
                return false;
            }

            // 엣지 크기를 확정하고 관계를 버퍼로 옮긴다 (태그·샤프니스는 0)
            level.EdgeCount = edgeCount;
            level.EdgeVertIndices = ToBuffer(edgeVertIndices);
            level.EdgeFaceCountsAndOffsets = ToBuffer(dynEdgeFaces.CountsAndOffsets);
            level.EdgeFaceIndices = ToBuffer(dynEdgeFaces.Members);
            level.EdgeFaceLocalIndices = OsdBuffer<ushort>.Allocate(level.EdgeFaceIndices.Length);
            level.EdgeSharpness = OsdBuffer<float>.Allocate(edgeCount);
            level.EdgeTags = OsdBuffer<byte>.Allocate(edgeCount);

            level.VertFaceCountsAndOffsets = ToBuffer(dynVertFaces.CountsAndOffsets);
            level.VertFaceIndices = ToBuffer(dynVertFaces.Members);
            level.VertFaceLocalIndices = OsdBuffer<ushort>.Allocate(level.VertFaceIndices.Length);
            level.VertEdgeCountsAndOffsets = ToBuffer(dynVertEdges.CountsAndOffsets);
            level.VertEdgeIndices = ToBuffer(dynVertEdges.Members);
            level.VertEdgeLocalIndices = OsdBuffer<ushort>.Allocate(level.VertEdgeIndices.Length);

            // 비다양체 엣지와 그 끝 정점을 먼저 표시해 정렬을 건너뛴다 (정렬에 실패한 정점도 뒤에서 비다양체가 된다)
            for (int i = 0; i < nonManifoldEdges.Count; ++i)
            {
                int eIndex = nonManifoldEdges[i];

                level.EdgeTags.Ptr[eIndex] |= OsdETag.NonManifold;

                int* eVerts = level.EdgeVertIndices.Ptr + 2 * eIndex;
                level.VertTags.Ptr[eVerts[0]] |= OsdVTag.NonManifold;
                level.VertTags.Ptr[eVerts[1]] |= OsdVTag.NonManifold;
            }

            OrientIncidentComponents(ref level);

            PopulateLocalIndices(ref level);

            return true;
        }

        /// <summary>Level::findEdge 의 v0 != v1 분기를 아직 압축하지 않은 정점-엣지 관계에서 수행한다.</summary>
        private static int FindEdge(List<int> edgeVertIndices, DynamicRelation vertEdges, int v0Index, int v1Index)
        {
            List<int> members = vertEdges.GetMembers(v0Index, out int start, out int count);
            for (int j = 0; j < count; ++j)
            {
                int eIndex = members[start + j];
                if (edgeVertIndices[2 * eIndex] == v1Index || edgeVertIndices[2 * eIndex + 1] == v1Index)
                {
                    return eIndex;
                }
            }
            return OsdConstants.IndexInvalid;
        }

        /// <summary>Level::populateLocalIndices. 엣지-페이스·정점-페이스·정점-엣지 로컬 인덱스를 채운다.</summary>
        private static void PopulateLocalIndices(ref OsdLevel level)
        {
            int eCount = level.EdgeCount;
            int vCount = level.VertCount;

            for (int vIndex = 0; vIndex < vCount; ++vIndex)
            {
                OsdRange vFaces = level.GetVertexFaces(vIndex);
                OsdLocalRange vInFaces = level.GetVertexFaceLocalIndices(vIndex);

                // 같은 페이스가 연달아 나오면(퇴화 엣지 등 비다양체) 앞 로컬 인덱스 다음부터 찾는다
                int vFaceLast = OsdConstants.IndexInvalid;
                for (int i = 0; i < vFaces.Count; ++i)
                {
                    OsdRange fVerts = level.GetFaceVertices(vFaces.Ptr[i]);

                    int vStart = (vFaces.Ptr[i] == vFaceLast) ? (vInFaces.Ptr[i - 1] + 1) : 0;
                    vInFaces.Ptr[i] = (ushort)FindInArray(fVerts, vStart, vIndex);

                    vFaceLast = vFaces.Ptr[i];
                }
            }

            for (int vIndex = 0; vIndex < vCount; ++vIndex)
            {
                OsdRange vEdges = level.GetVertexEdges(vIndex);
                OsdLocalRange vInEdges = level.GetVertexEdgeLocalIndices(vIndex);

                for (int i = 0; i < vEdges.Count; ++i)
                {
                    int* eVerts = level.EdgeVertIndices.Ptr + 2 * vEdges.Ptr[i];

                    // 퇴화 엣지는 (연달아 나오는) 첫 번째가 0, 두 번째가 1
                    if (eVerts[0] != eVerts[1])
                    {
                        vInEdges.Ptr[i] = (ushort)(vIndex == eVerts[1] ? 1 : 0);
                    }
                    else
                    {
                        vInEdges.Ptr[i] = (ushort)((i != 0 && vEdges.Ptr[i] == vEdges.Ptr[i - 1]) ? 1 : 0);
                    }
                }
                level.MaxValence = Math.Max(level.MaxValence, vEdges.Count);
            }

            for (int eIndex = 0; eIndex < eCount; ++eIndex)
            {
                OsdRange eFaces = level.GetEdgeFaces(eIndex);
                OsdLocalRange eInFaces = level.GetEdgeFaceLocalIndices(eIndex);

                int eFaceLast = OsdConstants.IndexInvalid;
                for (int i = 0; i < eFaces.Count; ++i)
                {
                    OsdRange fEdges = level.GetFaceEdges(eFaces.Ptr[i]);

                    int eStart = (eFaces.Ptr[i] == eFaceLast) ? (eInFaces.Ptr[i - 1] + 1) : 0;
                    eInFaces.Ptr[i] = (ushort)FindInArray(fEdges, eStart, eIndex);

                    eFaceLast = eFaces.Ptr[i];
                }
            }
        }

        /// <summary>Level::orientIncidentComponents. 비다양체가 아닌 정점의 주변을 반시계로 정렬하고, 정렬에 실패하면 비다양체로 표시한다.</summary>
        private static void OrientIncidentComponents(ref OsdLevel level)
        {
            int vCount = level.VertCount;

            // 원본 StackBuffer 대신: 정점의 페이스 수 + 엣지 수는 2 × MaxValence 를 넘지 않는다
            int[] scratch = new int[2 * level.MaxValence];
            fixed (int* indexBuffer = scratch)
            {
                for (int vIndex = 0; vIndex < vCount; ++vIndex)
                {
                    if ((level.VertTags.Ptr[vIndex] & OsdVTag.NonManifold) == 0)
                    {
                        if (OrderVertexFacesAndEdges(level, vIndex, indexBuffer) == false)
                        {
                            level.VertTags.Ptr[vIndex] |= OsdVTag.NonManifold;
                        }
                    }
                }
            }
        }

        /// <summary>Level::orderVertexFacesAndEdges(vIndex). 정렬에 성공하면 정점-페이스·정점-엣지를 정렬한 순서로 덮어쓴다.</summary>
        private static bool OrderVertexFacesAndEdges(in OsdLevel level, int vIndex, int* indexBuffer)
        {
            OsdRange vFaces = level.GetVertexFaces(vIndex);
            OsdRange vEdges = level.GetVertexEdges(vIndex);

            int* vFacesOrdered = indexBuffer;
            int* vEdgesOrdered = indexBuffer + vFaces.Count;

            if (OrderVertexFacesAndEdges(level, vIndex, vFacesOrdered, vEdgesOrdered))
            {
                for (int i = 0; i < vFaces.Count; ++i)
                {
                    vFaces.Ptr[i] = vFacesOrdered[i];
                }
                for (int i = 0; i < vEdges.Count; ++i)
                {
                    vEdges.Ptr[i] = vEdgesOrdered[i];
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// Level::orderVertexFacesAndEdges(vIndex, vFaces, vEdges). 시작 페이스·앞 엣지에서 반시계로 걸어 다양체 이웃을 찾는다.
        /// 정말 국소 다양체면 시작 엣지로 돌아오거나(내부) 다른 경계 엣지에서 끝난다(경계).
        /// </summary>
        private static bool OrderVertexFacesAndEdges(in OsdLevel level, int vIndex, int* vFacesOrdered, int* vEdgesOrdered)
        {
            OsdRange vEdges = level.GetVertexEdges(vIndex);
            OsdRange vFaces = level.GetVertexFaces(vIndex);

            int fCount = vFaces.Count;
            int eCount = vEdges.Count;

            if (fCount == 0 || eCount < 2 || (eCount - fCount) > 1)
            {
                return false;
            }

            // 퇴화 엣지 등 잘못된 엣지에 닿는 정점은 이미 비다양체로 표시돼 여기 오지 않는다
            int fStart = OsdConstants.IndexInvalid;
            int eStart = OsdConstants.IndexInvalid;
            int fvStart = 0;

            if (eCount == fCount)
            {
                // 내부: 첫 페이스에서 시작
                fStart = vFaces.Ptr[0];
                fvStart = FindInArray(level.GetFaceVertices(fStart), 0, vIndex);
                eStart = level.GetFaceEdges(fStart).Ptr[fvStart];
            }
            else
            {
                // 경계: 두 경계 엣지 중 앞(이 정점에서 나가는) 엣지를 찾는다
                for (int i = 0; i < eCount; ++i)
                {
                    OsdRange eFaces = level.GetEdgeFaces(vEdges.Ptr[i]);
                    if (eFaces.Count == 1)
                    {
                        eStart = vEdges.Ptr[i];
                        fStart = eFaces.Ptr[0];
                        fvStart = FindInArray(level.GetFaceVertices(fStart), 0, vIndex);

                        if (eStart == level.GetFaceEdges(fStart).Ptr[fvStart])
                        {
                            break;
                        }
                    }
                }
            }

            int eCountOrdered = 1;
            int fCountOrdered = 1;

            vFacesOrdered[0] = fStart;
            vEdgesOrdered[0] = eStart;

            int eFirst = eStart;

            while (eCountOrdered < eCount)
            {
                // 다음 엣지: 지금 페이스에서 이 정점으로 들어오는 엣지 (반시계 다음)
                OsdRange fVerts = level.GetFaceVertices(fStart);
                OsdRange fEdges = level.GetFaceEdges(fStart);

                int feStart = fvStart;
                int feNext = feStart != 0 ? (feStart - 1) : (fVerts.Count - 1);
                int eNext = fEdges.Ptr[feNext];

                // 비다양체 두 경우: 페이스 안에서 같은 엣지가 이어짐, 모든 엣지를 돌기 전에 시작으로 돌아옴
                if (eNext == eStart || eNext == eFirst)
                {
                    return false;
                }

                vEdgesOrdered[eCountOrdered++] = eNext;

                // 경계 끝이 아니면 다음 엣지 건너편 페이스로 간다
                if (fCountOrdered < fCount)
                {
                    OsdRange eFaces = level.GetEdgeFaces(eNext);

                    if (eFaces.Count == 0)
                    {
                        return false;
                    }
                    if (eFaces.Count == 1 && eFaces.Ptr[0] == fStart)
                    {
                        return false;
                    }

                    fStart = eFaces.Ptr[eFaces.Ptr[0] == fStart ? 1 : 0];
                    fvStart = FindInArray(level.GetFaceEdges(fStart), 0, eNext);

                    vFacesOrdered[fCountOrdered++] = fStart;
                }
                eStart = eNext;
            }
            return true;
        }

        /// <summary>std::find: start 부터 value 의 첫 위치, 없으면 개수.</summary>
        private static int FindInArray(OsdRange array, int start, int value)
        {
            int i = start;
            while (i < array.Count && array.Ptr[i] != value)
            {
                ++i;
            }
            return i;
        }

        private static OsdBuffer<int> ToBuffer(List<int> values)
        {
            OsdBuffer<int> buffer = OsdBuffer<int>.Allocate(values.Count);
            for (int i = 0; i < values.Count; ++i)
            {
                buffer.Ptr[i] = values[i];
            }
            return buffer;
        }

        /// <summary>
        /// level.cpp 의 DynamicRelation: 크기를 미리 모르는 관계(엣지-페이스·정점-페이스·정점-엣지)를 모은다.
        /// 요소마다 멤버 자리를 memberCountPerComp 개씩 잡고, 넘치는 요소는 멤버를 따로 떼어 사전에 둔다.
        /// 다 모은 뒤 압축하면 요소 순서대로, 요소 안에서는 넣은 순서대로 멤버가 이어진다.
        /// </summary>
        private sealed class DynamicRelation
        {
            /// <summary>요소마다 (개수, 오프셋).</summary>
            public readonly List<int> CountsAndOffsets;

            /// <summary>정규 멤버 자리 (원본 _regIndices). 압축 뒤에는 이어 붙인 멤버 전체다.</summary>
            public List<int> Members;

            private readonly int memberCountPerComp;
            private readonly Dictionary<int, List<int>> irregMembers = new Dictionary<int, List<int>>();
            private int compCount;

            public DynamicRelation(int compCount, int membersPerComp, int reservedCompCount)
            {
                this.compCount = compCount;
                memberCountPerComp = membersPerComp;

                int capacity = Math.Max(compCount, reservedCompCount);
                CountsAndOffsets = new List<int>(2 * capacity);
                Members = new List<int>(capacity * membersPerComp);
                for (int i = 0; i < compCount; ++i)
                {
                    CountsAndOffsets.Add(0);
                    CountsAndOffsets.Add(i * memberCountPerComp);
                }
                AddZeros(Members, compCount * memberCountPerComp);
            }

            public int GetMemberCount(int compIndex)
            {
                return CountsAndOffsets[2 * compIndex];
            }

            /// <summary>요소의 멤버가 담긴 목록과 그 안의 시작 위치·개수 (getCompMembers).</summary>
            public List<int> GetMembers(int compIndex, out int start, out int count)
            {
                count = CountsAndOffsets[2 * compIndex];
                if (count > memberCountPerComp)
                {
                    start = 0;
                    return irregMembers[compIndex];
                }
                start = CountsAndOffsets[2 * compIndex + 1];
                return Members;
            }

            public int GetMember(int compIndex, int memberIndex)
            {
                List<int> members = GetMembers(compIndex, out int start, out _);
                return members[start + memberIndex];
            }

            public void AppendCompMember(int compIndex, int memberValue)
            {
                int count = CountsAndOffsets[2 * compIndex];
                int offset = CountsAndOffsets[2 * compIndex + 1];

                if (count < memberCountPerComp)
                {
                    Members[offset + count] = memberValue;
                }
                else if (count > memberCountPerComp)
                {
                    irregMembers[compIndex].Add(memberValue);
                }
                else
                {
                    List<int> irregular = new List<int>(2 * (memberCountPerComp + 1));
                    for (int i = 0; i < memberCountPerComp; ++i)
                    {
                        irregular.Add(Members[offset + i]);
                    }
                    irregular.Add(memberValue);
                    irregMembers[compIndex] = irregular;
                }
                CountsAndOffsets[2 * compIndex] = count + 1;
            }

            public void AppendComponent()
            {
                CountsAndOffsets.Add(0);
                CountsAndOffsets.Add(compCount * memberCountPerComp);

                ++compCount;
                AddZeros(Members, memberCountPerComp);
            }

            /// <summary>멤버를 요소 순서대로 이어 붙이고 오프셋을 고친다. 요소당 멤버 수 최대값을 돌려준다.</summary>
            public int CompressMemberIndices()
            {
                if (irregMembers.Count == 0)
                {
                    int memberCount = CountsAndOffsets[0];
                    int memberMax = CountsAndOffsets[0];
                    for (int i = 1; i < compCount; ++i)
                    {
                        int count = CountsAndOffsets[2 * i];
                        int offset = CountsAndOffsets[2 * i + 1];

                        // 앞으로 당기는 이동이라 앞에서부터 옮겨도 안전하다 (memmove)
                        for (int k = 0; k < count; ++k)
                        {
                            Members[memberCount + k] = Members[offset + k];
                        }

                        CountsAndOffsets[2 * i + 1] = memberCount;
                        memberCount += count;
                        memberMax = Math.Max(memberMax, count);
                    }
                    Members.RemoveRange(memberCount, Members.Count - memberCount);
                    return memberMax;
                }
                else
                {
                    // 새 오프셋을 정하면서 제자리 압축이 가능한지 본다
                    bool cannotBeCompressedInPlace = false;

                    int memberCount = CountsAndOffsets[0];
                    for (int i = 1; i < compCount; ++i)
                    {
                        CountsAndOffsets[2 * i + 1] = memberCount;

                        cannotBeCompressedInPlace |= memberCount > (memberCountPerComp * i);

                        memberCount += CountsAndOffsets[2 * i];
                    }
                    cannotBeCompressedInPlace |= memberCount > (memberCountPerComp * compCount);

                    // 제자리 또는 임시 목록으로 옮긴다
                    List<int> dstIndices = Members;
                    if (cannotBeCompressedInPlace)
                    {
                        dstIndices = new List<int>(memberCount);
                        AddZeros(dstIndices, memberCount);
                    }

                    int memberMax = memberCountPerComp;
                    for (int i = 0; i < compCount; ++i)
                    {
                        int count = CountsAndOffsets[2 * i];
                        int dstStart = CountsAndOffsets[2 * i + 1];

                        if (count <= memberCountPerComp)
                        {
                            int srcStart = i * memberCountPerComp;
                            for (int k = 0; k < count; ++k)
                            {
                                dstIndices[dstStart + k] = Members[srcStart + k];
                            }
                        }
                        else
                        {
                            List<int> srcMembers = irregMembers[i];
                            for (int k = 0; k < count; ++k)
                            {
                                dstIndices[dstStart + k] = srcMembers[k];
                            }
                            memberMax = Math.Max(memberMax, count);
                        }
                    }
                    if (cannotBeCompressedInPlace)
                    {
                        Members = dstIndices;
                    }
                    else
                    {
                        Members.RemoveRange(memberCount, Members.Count - memberCount);
                    }
                    return memberMax;
                }
            }

            private static void AddZeros(List<int> list, int count)
            {
                for (int i = 0; i < count; ++i)
                {
                    list.Add(0);
                }
            }
        }
    }
}
