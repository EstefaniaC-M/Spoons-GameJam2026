﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 자식 요소 태그 비트 (vtr/refinement.h 의 Refinement::ChildTag 비트필드를 같은 비트 위치의 byte 로 옮긴 것).
    /// 부모 종류 자리는 0=Face, 1=Edge, 2=Vertex 를 담도록 정의돼 있지만, 원본은 균일·희소 분할 모두 초기 태그의 부모 종류를 0 으로 두고
    /// 바꾸지 않는다 (읽는 곳도 없다). 이 이식도 원본과 같게 늘 0 이다.
    /// </summary>
    public static class OsdChildTag
    {
        /// <summary>부모의 극한을 나타낼 이웃이 다 있지 않다 (희소 분할 전용 — 균일 분할에서는 늘 0).</summary>
        public const byte Incomplete = 1;

        public const byte ParentTypeShift = 1;
        public const byte ParentTypeMask = 3 << 1;

        /// <summary>부모 안에서 자식의 위치 (0~3, 다섯 이상인 페이스의 자식은 0).</summary>
        public const byte IndexInParentShift = 3;
        public const byte IndexInParentMask = 3 << 3;
    }

    /// <summary>
    /// 한 레벨 분할(부모 레벨 → 자식 레벨)의 부모↔자식 매핑 (vtr/refinement.h 의 Refinement 중 균일 분할에 쓰는 멤버).
    /// 버퍼는 OsdQuadRefiner.AllocateChild 가 할당하고 OsdQuadRefiner.RefineTopology 가 채운다.
    /// 자식 페이스·엣지 번호: 페이스 자식은 0 부터 부모 페이스·코너 순, 엣지 자식 엣지는 페이스 자식 엣지 뒤(ChildEdgeFromFaceCount)부터 엣지마다 2 개.
    /// 구조체를 복사하면 같은 메모리를 가리키므로 Free 는 소유한 쪽 변수에서 한 번만 부른다. 접근자는 버스트 호환이다.
    /// </summary>
    public unsafe struct OsdRefinement
    {
        // 부모 → 자식
        /// <summary>부모 페이스-정점과 같은 개수·오프셋 (원본처럼 부모 FaceVertCountsAndOffsets 를 함께 쓴다).</summary>
        public OsdBuffer<int> FaceChildFaceIndices;

        /// <summary>부모 페이스-엣지와 같은 개수·오프셋. 자식 엣지 j 는 페이스 자식 정점에서 부모 엣지 j 의 자식 정점으로 간다.</summary>
        public OsdBuffer<int> FaceChildEdgeIndices;

        public OsdBuffer<int> FaceChildVertIndex;

        /// <summary>부모 엣지마다 2 개 (엣지의 끝 정점 0·1 쪽 자식 엣지).</summary>
        public OsdBuffer<int> EdgeChildEdgeIndices;

        public OsdBuffer<int> EdgeChildVertIndex;
        public OsdBuffer<int> VertChildVertIndex;

        // 자식 → 부모
        public OsdBuffer<int> ChildFaceParentIndex;
        public OsdBuffer<int> ChildEdgeParentIndex;

        /// <summary>자식 정점의 부모 (자식 정점 번호 구간에 따라 부모 정점·페이스·엣지 인덱스).</summary>
        public OsdBuffer<int> ChildVertexParentIndex;

        /// <summary>OsdChildTag 비트.</summary>
        public OsdBuffer<byte> ChildFaceTags;
        public OsdBuffer<byte> ChildEdgeTags;
        public OsdBuffer<byte> ChildVertexTags;

        // 자식 요소 종류별 개수와 시작 번호. 페이스 자식 페이스·엣지는 0 부터, 엣지 자식 엣지는 ChildEdgeFromFaceCount 부터 시작한다
        public int ChildFaceFromFaceCount;
        public int ChildEdgeFromFaceCount;
        public int ChildEdgeFromEdgeCount;
        public int ChildVertFromFaceCount;
        public int ChildVertFromEdgeCount;
        public int ChildVertFromVertCount;
        public int FirstChildVertFromFace;
        public int FirstChildVertFromEdge;
        public int FirstChildVertFromVert;

        /// <summary>부모 페이스의 자식 페이스 (코너 순).</summary>
        public readonly OsdRange GetFaceChildFaces(in OsdLevel parent, int parentFace)
        {
            OsdRange range;
            range.Ptr = FaceChildFaceIndices.Ptr + parent.FaceVertCountsAndOffsets.Ptr[2 * parentFace + 1];
            range.Count = parent.FaceVertCountsAndOffsets.Ptr[2 * parentFace];
            return range;
        }

        /// <summary>부모 페이스 안의 자식 엣지 (부모 엣지 순).</summary>
        public readonly OsdRange GetFaceChildEdges(in OsdLevel parent, int parentFace)
        {
            OsdRange range;
            range.Ptr = FaceChildEdgeIndices.Ptr + parent.FaceVertCountsAndOffsets.Ptr[2 * parentFace + 1];
            range.Count = parent.FaceVertCountsAndOffsets.Ptr[2 * parentFace];
            return range;
        }

        /// <summary>부모 엣지의 자식 엣지 2 개 (엣지 끝 정점 0·1 쪽).</summary>
        public readonly OsdRange GetEdgeChildEdges(int parentEdge)
        {
            OsdRange range;
            range.Ptr = EdgeChildEdgeIndices.Ptr + 2 * parentEdge;
            range.Count = 2;
            return range;
        }

        /// <summary>모든 버퍼를 해제하고 개수를 0 으로 되돌린다. 같은 변수에서 두 번 불러도 안전하다. 관리 코드 전용.</summary>
        public void Free()
        {
            FaceChildFaceIndices.Free();
            FaceChildEdgeIndices.Free();
            FaceChildVertIndex.Free();
            EdgeChildEdgeIndices.Free();
            EdgeChildVertIndex.Free();
            VertChildVertIndex.Free();

            ChildFaceParentIndex.Free();
            ChildEdgeParentIndex.Free();
            ChildVertexParentIndex.Free();
            ChildFaceTags.Free();
            ChildEdgeTags.Free();
            ChildVertexTags.Free();

            ChildFaceFromFaceCount = 0;
            ChildEdgeFromFaceCount = 0;
            ChildEdgeFromEdgeCount = 0;
            ChildVertFromFaceCount = 0;
            ChildVertFromEdgeCount = 0;
            ChildVertFromVertCount = 0;
            FirstChildVertFromFace = 0;
            FirstChildVertFromEdge = 0;
            FirstChildVertFromVert = 0;
        }
    }
}
