﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.


namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 마스크 (Sdc 의 MASK 인터페이스). 가중치 버퍼는 호출자가 충분한 크기로 마련해 넘기고,
    /// 마스크 함수는 개수를 정해 그 버퍼에 쓴다.
    /// </summary>
    public unsafe struct OsdMask
    {
        public float* VertexWeights;
        public float* EdgeWeights;
        public float* FaceWeights;
        public int VertexWeightCount;
        public int EdgeWeightCount;
        public int FaceWeightCount;
        public bool FaceWeightsForFaceCenters;
    }

    /// <summary>엣지 주변 정보 (vtr EdgeInterface 에서 무한 샤프니스에 필요한 값만).</summary>
    public struct OsdEdgeNeighborhood
    {
        public int FaceCount;
        public float Sharpness;
    }

    /// <summary>정점 주변 정보 (vtr VertexInterface 에서 무한 샤프니스에 필요한 값만).</summary>
    public unsafe struct OsdVertexNeighborhood
    {
        public int EdgeCount;
        public int FaceCount;
        public float Sharpness;
        public float* EdgeSharpness;
    }

    /// <summary>
    /// sdc/catmarkScheme.h 와 scheme.h 의 Catmark 마스크. 버스트 호환: 정적 함수, 포인터·blittable 구조체만 쓴다.
    /// 부모·자식 규칙은 항상 같으므로(전이 없음) 규칙을 하나만 받고, TRI_SUB_SMOOTH 분기는 옮기지 않았다.
    /// </summary>
    public static unsafe class OsdCatmark
    {
        /// <summary>페이스 정점 마스크: 페이스의 정점 n 개에 각 1/n.</summary>
        public static void ComputeFaceVertexMask(int faceVertexCount, ref OsdMask mask)
        {
            mask.VertexWeightCount = faceVertexCount;
            mask.EdgeWeightCount = 0;
            mask.FaceWeightCount = 0;
            mask.FaceWeightsForFaceCenters = false;

            float weight = 1.0f / (float)faceVertexCount;
            for (int i = 0; i < faceVertexCount; ++i)
            {
                mask.VertexWeights[i] = weight;
            }
        }

        /// <summary>엣지 정점 마스크: 규칙이 Crease 면 중점, 아니면 Smooth 마스크.</summary>
        public static void ComputeEdgeVertexMask(in OsdEdgeNeighborhood edge, ref OsdMask mask, OsdRule rule)
        {
            if (rule == OsdRule.Crease)
            {
                mask.VertexWeightCount = 2;
                mask.EdgeWeightCount = 0;
                mask.FaceWeightCount = 0;
                mask.FaceWeightsForFaceCenters = false;

                mask.VertexWeights[0] = 0.5f;
                mask.VertexWeights[1] = 0.5f;
                return;
            }

            int faceCount = edge.FaceCount;
            mask.VertexWeightCount = 2;
            mask.EdgeWeightCount = 0;
            mask.FaceWeightCount = faceCount;
            mask.FaceWeightsForFaceCenters = true;

            mask.VertexWeights[0] = 0.25f;
            mask.VertexWeights[1] = 0.25f;

            if (faceCount == 2)
            {
                mask.FaceWeights[0] = 0.25f;
                mask.FaceWeights[1] = 0.25f;
            }
            else
            {
                float faceWeight = 0.5f / (float)faceCount;
                for (int i = 0; i < faceCount; ++i)
                {
                    mask.FaceWeights[i] = faceWeight;
                }
            }
        }

        /// <summary>
        /// 정점 정점 마스크: Smooth·Dart 는 Smooth 마스크, Crease 는 creaseEnds(길이 2)의 두 엣지에 1/8, 그 밖(Corner)은 정점 자신.
        /// </summary>
        public static void ComputeVertexVertexMask(in OsdVertexNeighborhood vertex, ref OsdMask mask, OsdRule rule, int* creaseEnds)
        {
            if (rule == OsdRule.Smooth || rule == OsdRule.Dart)
            {
                // Smooth 정점은 다양체 내부 정점이라 엣지 수와 페이스 수가 같다.
                int valence = vertex.FaceCount;
                mask.VertexWeightCount = 1;
                mask.EdgeWeightCount = valence;
                mask.FaceWeightCount = valence;
                mask.FaceWeightsForFaceCenters = true;

                float vertexWeight = (float)(valence - 2) / (float)valence;
                float faceWeight = 1.0f / (float)(valence * valence);

                mask.VertexWeights[0] = vertexWeight;
                for (int i = 0; i < valence; ++i)
                {
                    mask.EdgeWeights[i] = faceWeight;
                    mask.FaceWeights[i] = faceWeight;
                }
            }
            else if (rule == OsdRule.Crease)
            {
                int valence = vertex.EdgeCount;
                mask.VertexWeightCount = 1;
                mask.EdgeWeightCount = valence;
                mask.FaceWeightCount = 0;
                mask.FaceWeightsForFaceCenters = false;

                mask.VertexWeights[0] = 0.75f;
                for (int i = 0; i < valence; ++i)
                {
                    mask.EdgeWeights[i] = 0.0f;
                }
                mask.EdgeWeights[creaseEnds[0]] = 0.125f;
                mask.EdgeWeights[creaseEnds[1]] = 0.125f;
            }
            else
            {
                mask.VertexWeightCount = 1;
                mask.EdgeWeightCount = 0;
                mask.FaceWeightCount = 0;
                mask.FaceWeightsForFaceCenters = false;

                mask.VertexWeights[0] = 1.0f;
            }
        }
    }
}
