﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.


namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// sdc/crease.h·crease.cpp 의 크리스 판정. 이 이식은 무한 샤프니스만 의미가 있으므로
    /// semi-sharp 감쇠·Chaikin·분수 가중치는 옮기지 않았다.
    /// </summary>
    public static class OsdCrease
    {
        public static bool IsSmooth(float s)
        {
            return s <= OsdConstants.SharpnessSmooth;
        }

        public static bool IsSharp(float s)
        {
            return s > OsdConstants.SharpnessSmooth;
        }

        public static bool IsInfinite(float s)
        {
            return s >= OsdConstants.SharpnessInfinite;
        }

        public static bool IsSemiSharp(float s)
        {
            return OsdConstants.SharpnessSmooth < s && s < OsdConstants.SharpnessInfinite;
        }

        /// <summary>
        /// 정점 샤프니스와 샤프 엣지 수로 정점-정점 규칙을 정한다.
        /// 샤프 정점이거나 샤프 엣지가 3 개 이상이면 Corner, 아니면 1 &lt;&lt; 샤프 엣지 수 (Smooth/Dart/Crease).
        /// </summary>
        public static OsdRule DetermineVertexVertexRule(float vertexSharpness, int incidentSharpEdgeCount)
        {
            if (IsSharp(vertexSharpness))
            {
                return OsdRule.Corner;
            }

            return incidentSharpEdgeCount > 2 ? OsdRule.Corner : (OsdRule)(1 << incidentSharpEdgeCount);
        }
    }
}
