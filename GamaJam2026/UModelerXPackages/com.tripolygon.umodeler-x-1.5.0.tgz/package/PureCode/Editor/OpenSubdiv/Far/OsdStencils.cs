﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 한 레벨의 스텐실 (CSR). 행 r 은 자식 레벨 값 r 을 부모 레벨 값의 가중합으로 나타낸다:
    /// 자식[r] = Σ Weights[k] × 부모[Indices[k]], k ∈ [RowOffsets[r], RowOffsets[r + 1]).
    /// 인덱스는 부모 레벨 값만 가리킨다 (같은 레벨의 페이스 자식을 거치지 않는다 — D8). 한 행 안에서 같은 부모 인덱스는 한 번만 나온다.
    /// 구조체를 복사하면 같은 메모리를 가리키므로 Free 는 소유한 쪽 변수에서 한 번만 부른다.
    /// </summary>
    public unsafe struct OsdStencilLevel
    {
        /// <summary>행 수 (자식 레벨 값 수).</summary>
        public int RowCount;

        /// <summary>원본 수 (부모 레벨 값 수). 인덱스는 [0, SourceCount) 안이다.</summary>
        public int SourceCount;

        /// <summary>길이 RowCount + 1. 행 r 의 항목은 [RowOffsets[r], RowOffsets[r + 1]).</summary>
        public OsdBuffer<int> RowOffsets;

        public OsdBuffer<int> Indices;
        public OsdBuffer<float> Weights;

        /// <summary>버퍼를 해제하고 개수를 0 으로 되돌린다. 같은 변수에서 두 번 불러도 안전하다. 관리 코드 전용.</summary>
        public void Free()
        {
            RowOffsets.Free();
            Indices.Free();
            Weights.Free();
            RowCount = 0;
            SourceCount = 0;
        }
    }

    /// <summary>
    /// 한 레벨 스텐실 생성의 작업 데이터 블록. 버스트 커널이 포인터 하나로 받도록 blittable 필드만 둔다.
    /// 호출자(오케스트레이터)가 Target 의 RowCount·SourceCount 를 정하고 RowOffsets(RowCount + 1)를 할당한 뒤 Phase 0 으로 부르면
    /// 행마다 항목 수가 Target->RowOffsets[row + 1] 에 쓰인다. 호출자가 누적합을 만들고 Indices·Weights 를 할당한 뒤 Phase 1 로 부르면 채워진다.
    /// 정점 스텐실은 RowCount = Child.VertCount, SourceCount = Parent.VertCount 이고, 값 스텐실(IsValues = 1)은 FVar 세 필드를 채우고
    /// RowCount = ChildFVar.ValueCount, SourceCount = ParentFVar.ValueCount 다.
    /// 스크래치는 마스크 가중치와 개수 단계의 중복 제거에 쓰며 길이가 2 × Parent.MaxValence + 2 이상이어야 한다
    /// (값 스텐실은 정점 엣지 값 칸 MaxValence 개를 더해 3 × Parent.MaxValence + 2 이상).
    /// 버퍼 소유권은 호출자에게 있다 (블록은 복사본을 들고 있을 뿐이다).
    /// </summary>
    public unsafe struct OsdStencilBuildData
    {
        public OsdLevel Parent;
        public OsdLevel Child;
        public OsdRefinement Refinement;

        // FVar(UV) 채널 — 값 스텐실(IsValues = 1)일 때만 쓴다. OsdFVarRefiner.RefineValues 를 마친 것이어야 한다
        public OsdFVarLevel ParentFVar;
        public OsdFVarLevel ChildFVar;
        public OsdFVarRefinement FVarRefinement;

        public OsdStencilLevel* Target;
        public float* Scratch;
        public int ScratchLength;

        /// <summary>0 = 행별 개수, 1 = 채우기.</summary>
        public int Phase;

        /// <summary>
        /// 1 이면 값(FVar) 스텐실이다. 실행기가 어느 생성 함수(BuildVertexStencils / BuildValueStencils)를 부를지 고르는 데 쓴다 (생성 함수 자신은 보지 않는다).
        /// </summary>
        public byte IsValues;

        /// <summary>결과 (OsdStatus 값). 끝나면 Ok, 입력이 계약과 맞지 않으면 InvalidInput.</summary>
        public int Status;
    }

    /// <summary>
    /// 레벨별 정점·값 스텐실 생성 (far/primvarRefiner.h 의 interpFromFaces·interpFromEdges·interpFromVerts 와
    /// interpFVarFromFaces·interpFVarFromEdges·interpFVarFromVerts 의 Catmark 경로를, far/stencilBuilder.cpp 처럼 값 대신 가중치를 기록하도록 옮긴 것).
    /// 버스트 호환: 포인터·blittable 만, 할당·예외 없음.
    /// 원본은 엣지·정점 자식에 같은 레벨 페이스 자식 값(dst[cVertOfFace])을 더하지만, 이 이식은 그 가중치 w 를 그 페이스의 부모 정점(값 스텐실은 부모 FVar 코너 값)으로
    /// w / n 씩 펼친다. 수학적으로 같고 반올림만 다르다 (D8). 규칙은 자식 정점 태그의 rule 이다 — 부모·자식 규칙이 늘 같다 (D2, semi-sharp 없음).
    /// </summary>
    public static unsafe class OsdStencilBuilder
    {
        // 행 수집 방식 (RowSink.Mode)
        /// <summary>서로 다른 인덱스를 스크래치(정수로 다시 읽는다)에 모아 센다. 넘치면 Overflow.</summary>
        private const int SinkCount = 0;

        /// <summary>행 구간에 인덱스·가중치를 쓰고 같은 인덱스는 가중치를 합친다.</summary>
        private const int SinkFill = 1;

        /// <summary>Probe 번째 후보의 인덱스를 Result 에 둔다 (Probe 가 음수면 후보 수만 센다).</summary>
        private const int SinkGetAt = 2;

        /// <summary>인덱스 Probe 가 처음 나오는 후보 위치를 Result 에 둔다.</summary>
        private const int SinkFindFirst = 3;

        /// <summary>한 행의 후보(부모 인덱스, 가중치)를 받는 곳.</summary>
        private struct RowSink
        {
            public int Mode;
            public int* Indices;
            public float* Weights;

            /// <summary>SinkCount·SinkFill: 모은 서로 다른 인덱스 수. SinkGetAt·SinkFindFirst: 지나간 후보 수.</summary>
            public int Count;

            public int Capacity;
            public int Probe;
            public int Result;
            public byte Overflow;
        }

        /// <summary>Crease 마스크에 넘기는 크리스 끝 엣지 두 개 (Crease::GetSharpEdgePairOfCrease 의 결과).</summary>
        private struct CreaseEnds
        {
            public fixed int Values[2];
        }

        /// <summary>FVar 질의가 돌려주는 값 두 개 (엣지 양 끝 값, 크리스 끝 값).</summary>
        private struct ValuePair
        {
            public fixed int Values[2];
        }

        /// <summary>
        /// 자식 레벨 정점마다 한 행을 만든다. Phase 0 이면 행별 항목 수(같은 부모 인덱스를 합친 뒤)를 Target->RowOffsets[row + 1] 에 쓰고
        /// RowOffsets[0] 을 0 으로 둔다. Phase 1 이면 누적합이 된 RowOffsets 의 구간에 인덱스·가중치를 쓴다.
        /// </summary>
        public static void BuildVertexStencils(OsdStencilBuildData* data)
        {
            OsdStencilLevel* target = data->Target;
            int rowCount = data->Child.VertCount;
            if (target == null || data->Scratch == null || data->ScratchLength < 2 * data->Parent.MaxValence + 2
                || target->RowCount != rowCount || target->SourceCount != data->Parent.VertCount || target->RowOffsets.Length != rowCount + 1)
            {
                data->Status = (int)OsdStatus.InvalidInput;
                return;
            }

            if (data->Phase == 0)
            {
                target->RowOffsets.Ptr[0] = 0;
                for (int cVert = 0; cVert < rowCount; ++cVert)
                {
                    int count = CountRow(data, cVert, 0, false);
                    if (count < 0)
                    {
                        data->Status = (int)OsdStatus.InvalidInput;
                        return;
                    }
                    target->RowOffsets.Ptr[cVert + 1] = count;
                }
                data->Status = (int)OsdStatus.Ok;
                return;
            }

            if (data->Phase == 1)
            {
                int total = target->RowOffsets.Ptr[rowCount];
                if (target->Indices.Length != total || target->Weights.Length != total)
                {
                    data->Status = (int)OsdStatus.InvalidInput;
                    return;
                }

                for (int cVert = 0; cVert < rowCount; ++cVert)
                {
                    int begin = target->RowOffsets.Ptr[cVert];
                    int end = target->RowOffsets.Ptr[cVert + 1];

                    RowSink sink = default;
                    sink.Mode = SinkFill;
                    sink.Indices = target->Indices.Ptr + begin;
                    sink.Weights = target->Weights.Ptr + begin;
                    sink.Capacity = end - begin;

                    // 개수 단계와 같은 후보를 내므로 정확히 Capacity 개가 채워져야 한다
                    if (EmitRow(data, cVert, ref sink) == false || sink.Overflow != 0 || sink.Count != sink.Capacity)
                    {
                        data->Status = (int)OsdStatus.InvalidInput;
                        return;
                    }
                }
                data->Status = (int)OsdStatus.Ok;
                return;
            }

            data->Status = (int)OsdStatus.InvalidInput;
        }

        /// <summary>
        /// 자식 레벨 FVar(UV) 값마다 한 행을 만든다 (far/primvarRefiner.h 의 interpFVarFromFaces·interpFVarFromEdges·interpFVarFromVerts 의 Catmark 경로).
        /// 행 번호는 자식 값 오프셋(자식 정점의 값 오프셋 + 형제 번호)이고, 인덱스는 부모 레벨 FVar 값이다 — 레벨 0 은 입력 값 인덱스, 분할된 레벨은 값 오프셋.
        /// 블록에 OsdFVarRefiner.RefineValues 를 마친 ParentFVar·ChildFVar·FVarRefinement 를 넣고 Target 의 RowCount = ChildFVar.ValueCount,
        /// SourceCount = ParentFVar.ValueCount 로 둔다. Phase 0·1 은 BuildVertexStencils 와 같다.
        /// 스크래치는 3 × Parent.MaxValence + 2 이상: 앞 2 × MaxValence + 2 칸은 마스크 가중치·개수 단계 중복 제거, 뒤 MaxValence 칸은 정점 엣지 값(정수)이다.
        /// </summary>
        public static void BuildValueStencils(OsdStencilBuildData* data)
        {
            OsdStencilLevel* target = data->Target;
            int rowCount = data->ChildFVar.ValueCount;
            if (target == null || data->Scratch == null || data->ScratchLength < 3 * data->Parent.MaxValence + 2
                || target->RowCount != rowCount || target->SourceCount != data->ParentFVar.ValueCount || target->RowOffsets.Length != rowCount + 1)
            {
                data->Status = (int)OsdStatus.InvalidInput;
                return;
            }

            int childVertCount = data->Child.VertCount;
            if (data->Phase == 0)
            {
                target->RowOffsets.Ptr[0] = 0;
                int coveredRows = 0;
                for (int cVert = 0; cVert < childVertCount; ++cVert)
                {
                    int offset = data->ChildFVar.GetVertexValueOffset(cVert);
                    int valueCount = data->ChildFVar.GetNumVertexValues(cVert);
                    if (valueCount < 1 || offset < 0 || offset + valueCount > rowCount)
                    {
                        data->Status = (int)OsdStatus.InvalidInput;
                        return;
                    }
                    for (int sibling = 0; sibling < valueCount; ++sibling)
                    {
                        int count = CountRow(data, cVert, sibling, true);
                        if (count < 0)
                        {
                            data->Status = (int)OsdStatus.InvalidInput;
                            return;
                        }
                        target->RowOffsets.Ptr[offset + sibling + 1] = count;
                    }
                    coveredRows += valueCount;
                }

                // RefineValues 가 자식 정점마다 겹치지 않는 값 구간을 차례로 주므로, 구간 합이 값 수와 같으면 모든 행을 한 번씩 셌다
                if (coveredRows != rowCount)
                {
                    data->Status = (int)OsdStatus.InvalidInput;
                    return;
                }
                data->Status = (int)OsdStatus.Ok;
                return;
            }

            if (data->Phase == 1)
            {
                int total = target->RowOffsets.Ptr[rowCount];
                if (target->Indices.Length != total || target->Weights.Length != total)
                {
                    data->Status = (int)OsdStatus.InvalidInput;
                    return;
                }

                for (int cVert = 0; cVert < childVertCount; ++cVert)
                {
                    int offset = data->ChildFVar.GetVertexValueOffset(cVert);
                    int valueCount = data->ChildFVar.GetNumVertexValues(cVert);
                    if (valueCount < 1 || offset < 0 || offset + valueCount > rowCount)
                    {
                        data->Status = (int)OsdStatus.InvalidInput;
                        return;
                    }
                    for (int sibling = 0; sibling < valueCount; ++sibling)
                    {
                        int begin = target->RowOffsets.Ptr[offset + sibling];
                        int end = target->RowOffsets.Ptr[offset + sibling + 1];

                        RowSink sink = default;
                        sink.Mode = SinkFill;
                        sink.Indices = target->Indices.Ptr + begin;
                        sink.Weights = target->Weights.Ptr + begin;
                        sink.Capacity = end - begin;

                        // 개수 단계와 같은 후보를 내므로 정확히 Capacity 개가 채워져야 한다
                        if (EmitValueRow(data, cVert, sibling, ref sink) == false || sink.Overflow != 0 || sink.Count != sink.Capacity)
                        {
                            data->Status = (int)OsdStatus.InvalidInput;
                            return;
                        }
                    }
                }
                data->Status = (int)OsdStatus.Ok;
                return;
            }

            data->Status = (int)OsdStatus.InvalidInput;
        }

        /// <summary>
        /// 행의 서로 다른 부모 인덱스 수. 스크래치 앞 2 × Parent.MaxValence + 2 칸을 정수 집합으로 쓰고 (값 스텐실의 정점 엣지 값 칸과 겹치지 않게 늘 이 길이까지만),
        /// 넘치면(큰 N 각형 여럿이 모인 레벨 0 정점) 저장 공간 없이 후보를 다시 훑어 센다: 후보 p 의 인덱스가 처음 나오는 위치가 p 면 새 인덱스다 (후보 수의 제곱).
        /// values 면 자식 정점 cVert 의 sibling 번째 값 행, 아니면 자식 정점 cVert 행(sibling 은 보지 않는다). 토폴로지가 규칙과 맞지 않으면 -1.
        /// </summary>
        private static int CountRow(OsdStencilBuildData* data, int cVert, int sibling, bool values)
        {
            RowSink sink = default;
            sink.Mode = SinkCount;
            sink.Indices = (int*)data->Scratch;
            sink.Capacity = 2 * data->Parent.MaxValence + 2;
            if (EmitAnyRow(data, cVert, sibling, values, ref sink) == false)
            {
                return -1;
            }
            if (sink.Overflow == 0)
            {
                return sink.Count;
            }

            RowSink all = default;
            all.Mode = SinkGetAt;
            all.Probe = -1;
            all.Result = -1;
            EmitAnyRow(data, cVert, sibling, values, ref all);
            int candidateCount = all.Count;

            int distinct = 0;
            for (int p = 0; p < candidateCount; ++p)
            {
                RowSink at = default;
                at.Mode = SinkGetAt;
                at.Probe = p;
                at.Result = -1;
                EmitAnyRow(data, cVert, sibling, values, ref at);

                RowSink first = default;
                first.Mode = SinkFindFirst;
                first.Probe = at.Result;
                first.Result = -1;
                EmitAnyRow(data, cVert, sibling, values, ref first);

                if (first.Result == p)
                {
                    ++distinct;
                }
            }
            return distinct;
        }

        private static bool EmitAnyRow(OsdStencilBuildData* data, int cVert, int sibling, bool values, ref RowSink sink)
        {
            return values ? EmitValueRow(data, cVert, sibling, ref sink) : EmitRow(data, cVert, ref sink);
        }

        /// <summary>
        /// 자식 정점 cVert 의 후보(부모 인덱스, 가중치)를 원본이 더하는 순서대로 sink 에 낸다.
        /// 어떤 후보가 나오는지는 규칙과 토폴로지로만 정해진다 (가중치가 0 인 후보도 나온다) — 그래서 개수 단계와 채우기 단계의 행이 같다.
        /// 채우기 단계에서만 마스크를 스크래치에 계산해 가중치를 붙이고, 그 밖에는 가중치가 0 이고 스크래치를 건드리지 않는다.
        /// 토폴로지가 규칙과 맞지 않으면(원본의 assert 조건) false.
        /// </summary>
        private static bool EmitRow(OsdStencilBuildData* data, int cVert, ref RowSink sink)
        {
            OsdLevel* parent = &data->Parent;
            OsdRefinement* refinement = &data->Refinement;
            float* scratch = data->Scratch;
            bool withWeights = sink.Mode == SinkFill;

            int pIndex = refinement->ChildVertexParentIndex.Ptr[cVert];
            OsdRule rule = OsdVTag.GetRule(data->Child.VertTags.Ptr[cVert]);

            OsdMask mask = default;

            // interpFromFaces: 페이스 정점 마스크를 페이스의 정점에
            int faceBegin = refinement->FirstChildVertFromFace;
            if (cVert >= faceBegin && cVert < faceBegin + refinement->ChildVertFromFaceCount)
            {
                OsdRange fVerts = parent->GetFaceVertices(pIndex);
                if (fVerts.Count > data->ScratchLength)
                {
                    return false;
                }
                if (withWeights)
                {
                    mask.VertexWeights = scratch;
                    OsdCatmark.ComputeFaceVertexMask(fVerts.Count, ref mask);
                }
                for (int i = 0; i < fVerts.Count; ++i)
                {
                    Emit(ref sink, fVerts.Ptr[i], withWeights ? scratch[i] : 0.0f);
                }
                return true;
            }

            // interpFromEdges: 엣지 양 끝 정점, Smooth 면 닿는 페이스의 중심
            int edgeBegin = refinement->FirstChildVertFromEdge;
            if (cVert >= edgeBegin && cVert < edgeBegin + refinement->ChildVertFromEdgeCount)
            {
                OsdRange eVerts = parent->GetEdgeVertices(pIndex);
                OsdRange eFaces = parent->GetEdgeFaces(pIndex);

                // 원본 ComputeEdgeVertexMask: 부모·자식이 Crease 면 중점, 아니면 Smooth (페이스 가중치는 페이스 중심용)
                bool smooth = rule != OsdRule.Crease;
                if (smooth && 2 + eFaces.Count > data->ScratchLength)
                {
                    return false;
                }
                if (withWeights)
                {
                    OsdEdgeNeighborhood edge;
                    edge.FaceCount = eFaces.Count;
                    edge.Sharpness = parent->EdgeSharpness.Ptr[pIndex];

                    mask.VertexWeights = scratch;
                    mask.FaceWeights = scratch + 2;
                    OsdCatmark.ComputeEdgeVertexMask(edge, ref mask, rule);
                }

                Emit(ref sink, eVerts.Ptr[0], withWeights ? scratch[0] : 0.0f);
                Emit(ref sink, eVerts.Ptr[1], withWeights ? scratch[1] : 0.0f);
                if (smooth)
                {
                    for (int i = 0; i < eFaces.Count; ++i)
                    {
                        EmitFaceCenter(parent, eFaces.Ptr[i], withWeights ? scratch[2 + i] : 0.0f, ref sink);
                    }
                }
                return true;
            }

            // interpFromVerts: 페이스 가중치(페이스 중심) → 엣지 가중치(엣지 맞은편 정점) → 정점 가중치 순서로 더한다
            OsdRange vEdges = parent->GetVertexEdges(pIndex);
            OsdRange vFaces = parent->GetVertexFaces(pIndex);

            OsdVertexNeighborhood vertex;
            vertex.EdgeCount = vEdges.Count;
            vertex.FaceCount = vFaces.Count;
            vertex.Sharpness = parent->VertSharpness.Ptr[pIndex];
            // 이 이식의 마스크는 엣지별 샤프니스를 읽지 않는다 (크리스 끝은 아래에서 따로 구해 넘긴다)
            vertex.EdgeSharpness = null;

            if (rule == OsdRule.Smooth || rule == OsdRule.Dart)
            {
                // assignSmoothMaskForVertex 의 assert: 매끈한 정점은 다양체 내부 정점이라 엣지 수 == 페이스 수
                int valence = vEdges.Count;
                if (vFaces.Count != valence || 1 + 2 * valence > data->ScratchLength)
                {
                    return false;
                }
                if (withWeights)
                {
                    mask.VertexWeights = scratch;
                    mask.EdgeWeights = scratch + 1;
                    mask.FaceWeights = scratch + 1 + valence;
                    OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, null);
                }

                for (int i = 0; i < valence; ++i)
                {
                    EmitFaceCenter(parent, vFaces.Ptr[i], withWeights ? scratch[1 + valence + i] : 0.0f, ref sink);
                }
                for (int i = 0; i < valence; ++i)
                {
                    Emit(ref sink, OppositeVertex(parent, vEdges.Ptr[i], pIndex), withWeights ? scratch[1 + i] : 0.0f);
                }
                Emit(ref sink, pIndex, withWeights ? scratch[0] : 0.0f);
                return true;
            }

            if (rule == OsdRule.Crease)
            {
                // Crease::GetSharpEdgePairOfCrease: 앞에서 첫 샤프 엣지, 뒤에서 첫 샤프 엣지. Crease 규칙이면 샤프 엣지가 정확히 둘이다
                int first = 0;
                while (first < vEdges.Count && OsdCrease.IsSmooth(parent->EdgeSharpness.Ptr[vEdges.Ptr[first]]))
                {
                    ++first;
                }
                int last = vEdges.Count - 1;
                while (last >= 0 && OsdCrease.IsSmooth(parent->EdgeSharpness.Ptr[vEdges.Ptr[last]]))
                {
                    --last;
                }
                if (first >= last || 1 + vEdges.Count > data->ScratchLength)
                {
                    return false;
                }
                if (withWeights)
                {
                    CreaseEnds ends = default;
                    ends.Values[0] = first;
                    ends.Values[1] = last;

                    mask.VertexWeights = scratch;
                    mask.EdgeWeights = scratch + 1;
                    OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, ends.Values);
                }

                // 원본은 모든 엣지에 더하지만 크리스 끝 둘 말고는 가중치가 0 이라 그 둘만 낸다
                Emit(ref sink, OppositeVertex(parent, vEdges.Ptr[first], pIndex), withWeights ? scratch[1 + first] : 0.0f);
                Emit(ref sink, OppositeVertex(parent, vEdges.Ptr[last], pIndex), withWeights ? scratch[1 + last] : 0.0f);
                Emit(ref sink, pIndex, withWeights ? scratch[0] : 0.0f);
                return true;
            }

            // Corner (그 밖의 규칙도 마스크처럼 코너로 다룬다): 정점 자신
            if (withWeights)
            {
                mask.VertexWeights = scratch;
                OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, null);
            }
            Emit(ref sink, pIndex, withWeights ? scratch[0] : 0.0f);
            return true;
        }

        /// <summary>페이스 중심(페이스 자식 정점)에 줄 가중치를 그 페이스의 부모 정점으로 weight / n 씩 펼친다.</summary>
        private static void EmitFaceCenter(OsdLevel* parent, int face, float weight, ref RowSink sink)
        {
            OsdRange fVerts = parent->GetFaceVertices(face);
            float spread = weight / (float)fVerts.Count;
            for (int i = 0; i < fVerts.Count; ++i)
            {
                Emit(ref sink, fVerts.Ptr[i], spread);
            }
        }

        /// <summary>
        /// 자식 정점 cVert 의 sibling 번째 값의 후보(부모 FVar 값, 가중치)를 원본이 더하는 순서대로 sink 에 낸다. EmitRow 와 같은 규칙으로 후보가 정해진다
        /// (규칙·FVar 태그·토폴로지만 보고, 가중치가 0 인 후보도 낸다). 마스크는 채우기 단계에서만 스크래치 앞 2 × MaxValence + 2 칸에 계산하고,
        /// 정점 엣지 값은 어느 단계든 그 뒤 MaxValence 칸에 받는다. 토폴로지가 규칙과 맞지 않으면(원본의 assert 조건) false.
        /// </summary>
        private static bool EmitValueRow(OsdStencilBuildData* data, int cVert, int sibling, ref RowSink sink)
        {
            OsdLevel* parent = &data->Parent;
            OsdRefinement* refinement = &data->Refinement;
            OsdFVarLevel* parentFVar = &data->ParentFVar;
            OsdFVarLevel* childFVar = &data->ChildFVar;
            ushort* parentSources = data->FVarRefinement.ChildValueParentSource.Ptr;
            float* scratch = data->Scratch;
            bool withWeights = sink.Mode == SinkFill;

            int maxValence = parent->MaxValence;
            int weightLimit = 2 * maxValence + 2;

            int pIndex = refinement->ChildVertexParentIndex.Ptr[cVert];
            OsdRule rule = OsdVTag.GetRule(data->Child.VertTags.Ptr[cVert]);

            // 원본 isLinearFVar (Bilinear 는 쓰지 않는다)
            bool isLinear = parentFVar->IsLinear != 0;

            // 원본 childFVar.valueTopologyMatches(cVertValues[0]) — 정점의 첫 값으로 정점 전체를 판단한다
            int cValueOffset = childFVar->GetVertexValueOffset(cVert);
            bool matches = childFVar->ValueTopologyMatches(cValueOffset);

            OsdMask mask = default;
            ValuePair pair = default;

            // interpFVarFromFaces: 페이스 정점 마스크를 부모 페이스의 코너 값에 (페이스 자식은 값이 하나다)
            int faceBegin = refinement->FirstChildVertFromFace;
            if (cVert >= faceBegin && cVert < faceBegin + refinement->ChildVertFromFaceCount)
            {
                OsdRange fValues = parentFVar->GetFaceValues(*parent, pIndex);
                if (sibling != 0 || fValues.Count > weightLimit)
                {
                    return false;
                }
                if (withWeights)
                {
                    mask.VertexWeights = scratch;
                    OsdCatmark.ComputeFaceVertexMask(fValues.Count, ref mask);
                }
                for (int i = 0; i < fValues.Count; ++i)
                {
                    Emit(ref sink, fValues.Ptr[i], withWeights ? scratch[i] : 0.0f);
                }
                return true;
            }

            // interpFVarFromEdges
            int edgeBegin = refinement->FirstChildVertFromEdge;
            if (cVert >= edgeBegin && cVert < edgeBegin + refinement->ChildVertFromEdgeCount)
            {
                OsdRange eFaces = parent->GetEdgeFaces(pIndex);
                if (matches)
                {
                    // FVar 가 이어진 엣지: 선형이면 중점, 아니면 정점과 같은 엣지 마스크 (Smooth 면 페이스 중심 값까지)
                    bool smooth = isLinear == false && rule != OsdRule.Crease;
                    if (sibling != 0 || eFaces.Count < 1 || (smooth && 2 + eFaces.Count > weightLimit))
                    {
                        return false;
                    }
                    if (withWeights)
                    {
                        if (isLinear)
                        {
                            scratch[0] = 0.5f;
                            scratch[1] = 0.5f;
                        }
                        else
                        {
                            OsdEdgeNeighborhood edge;
                            edge.FaceCount = eFaces.Count;
                            edge.Sharpness = parent->EdgeSharpness.Ptr[pIndex];

                            mask.VertexWeights = scratch;
                            mask.FaceWeights = scratch + 2;
                            OsdCatmark.ComputeEdgeVertexMask(edge, ref mask, rule);
                        }
                    }

                    // 끝 정점이 엣지 반대편에 다른 값을 가질 수 있어 엣지의 첫 페이스에서 끝 값을 읽는다
                    parentFVar->GetEdgeFaceValues(*parent, pIndex, 0, pair.Values);
                    Emit(ref sink, pair.Values[0], withWeights ? scratch[0] : 0.0f);
                    Emit(ref sink, pair.Values[1], withWeights ? scratch[1] : 0.0f);
                    if (smooth)
                    {
                        for (int i = 0; i < eFaces.Count; ++i)
                        {
                            EmitFaceValueCenter(parent, parentFVar, eFaces.Ptr[i], withWeights ? scratch[2 + i] : 0.0f, ref sink);
                        }
                    }
                    return true;
                }

                // 끊긴 엣지: 형제마다 그 형제가 나온 엣지 페이스의 끝 값 둘을 선형 보간한다 (원본 assert: 출처 == 형제 번호)
                int eFaceIndex = parentSources[cValueOffset + sibling];
                if (eFaceIndex != sibling || eFaceIndex >= eFaces.Count)
                {
                    return false;
                }
                parentFVar->GetEdgeFaceValues(*parent, pIndex, eFaceIndex, pair.Values);
                Emit(ref sink, pair.Values[0], 0.5f);
                Emit(ref sink, pair.Values[1], 0.5f);
                return true;
            }

            // interpFVarFromVerts
            OsdRange pVertValues = parentFVar->GetVertexValues(pIndex);
            if (matches)
            {
                if (sibling != 0)
                {
                    return false;
                }

                // 선형이고 일치하면 부모 값을 그대로
                if (isLinear)
                {
                    Emit(ref sink, pVertValues.Ptr[0], 1.0f);
                    return true;
                }

                // 정점과 같은 마스크: 페이스 가중치(페이스 중심 값) → 엣지 가중치(엣지 맞은편 값) → 정점 가중치 순서로 더한다
                OsdRange vEdges = parent->GetVertexEdges(pIndex);
                OsdRange vFaces = parent->GetVertexFaces(pIndex);
                int* edgeValues = (int*)(scratch + weightLimit);

                OsdVertexNeighborhood vertex;
                vertex.EdgeCount = vEdges.Count;
                vertex.FaceCount = vFaces.Count;
                vertex.Sharpness = parent->VertSharpness.Ptr[pIndex];
                vertex.EdgeSharpness = null;

                if (rule == OsdRule.Smooth || rule == OsdRule.Dart)
                {
                    int valence = vEdges.Count;
                    if (vFaces.Count != valence || valence > maxValence || 1 + 2 * valence > weightLimit)
                    {
                        return false;
                    }
                    if (withWeights)
                    {
                        mask.VertexWeights = scratch;
                        mask.EdgeWeights = scratch + 1;
                        mask.FaceWeights = scratch + 1 + valence;
                        OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, null);
                    }
                    parentFVar->GetVertexEdgeValues(*parent, pIndex, edgeValues);

                    for (int i = 0; i < valence; ++i)
                    {
                        EmitFaceValueCenter(parent, parentFVar, vFaces.Ptr[i], withWeights ? scratch[1 + valence + i] : 0.0f, ref sink);
                    }
                    for (int i = 0; i < valence; ++i)
                    {
                        Emit(ref sink, edgeValues[i], withWeights ? scratch[1 + i] : 0.0f);
                    }
                    Emit(ref sink, pVertValues.Ptr[0], withWeights ? scratch[0] : 0.0f);
                    return true;
                }

                if (rule == OsdRule.Crease)
                {
                    // 정점 스텐실과 같은 크리스 끝 엣지 (앞에서 첫 샤프 엣지, 뒤에서 첫 샤프 엣지)
                    int first = 0;
                    while (first < vEdges.Count && OsdCrease.IsSmooth(parent->EdgeSharpness.Ptr[vEdges.Ptr[first]]))
                    {
                        ++first;
                    }
                    int last = vEdges.Count - 1;
                    while (last >= 0 && OsdCrease.IsSmooth(parent->EdgeSharpness.Ptr[vEdges.Ptr[last]]))
                    {
                        --last;
                    }
                    if (first >= last || vEdges.Count > maxValence || 1 + vEdges.Count > weightLimit)
                    {
                        return false;
                    }
                    if (withWeights)
                    {
                        CreaseEnds ends = default;
                        ends.Values[0] = first;
                        ends.Values[1] = last;

                        mask.VertexWeights = scratch;
                        mask.EdgeWeights = scratch + 1;
                        OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, ends.Values);
                    }
                    parentFVar->GetVertexEdgeValues(*parent, pIndex, edgeValues);

                    // 원본은 모든 엣지에 더하지만 크리스 끝 둘 말고는 가중치가 0 이라 그 둘만 낸다
                    Emit(ref sink, edgeValues[first], withWeights ? scratch[1 + first] : 0.0f);
                    Emit(ref sink, edgeValues[last], withWeights ? scratch[1 + last] : 0.0f);
                    Emit(ref sink, pVertValues.Ptr[0], withWeights ? scratch[0] : 0.0f);
                    return true;
                }

                // Corner (그 밖의 규칙도 마스크처럼 코너로 다룬다): 부모 값 자신
                if (withWeights)
                {
                    mask.VertexWeights = scratch;
                    OsdCatmark.ComputeVertexVertexMask(vertex, ref mask, rule, null);
                }
                Emit(ref sink, pVertValues.Ptr[0], withWeights ? scratch[0] : 0.0f);
                return true;
            }

            // 불일치 값: 형제마다 코너면 부모 값 그대로, 크리스면 크리스 끝 값 둘에 1/8 + 부모 값 3/4 (원본 assert: 출처 == 형제 번호)
            int pSibling = parentSources[cValueOffset + sibling];
            if (pSibling != sibling || pSibling >= pVertValues.Count)
            {
                return false;
            }
            int pVertValue = pVertValues.Ptr[pSibling];
            byte cValueTag = childFVar->VertValueTags.Ptr[cValueOffset + sibling];
            if (isLinear || OsdValueTag.IsCorner(cValueTag))
            {
                Emit(ref sink, pVertValue, 1.0f);
                return true;
            }

            // semi-sharp 값의 분수 가중치(getFractionalWeight)는 옮기지 않았다 — semi-sharp 가 생기지 않는다 (D2). 크리스 끝은 매끈한 경계에서만 있다
            byte pValueTag = parentFVar->GetVertexValueTags(pIndex)[pSibling];
            if (OsdValueTag.IsSemiSharp(pValueTag) || parentFVar->HasCreaseEnds == false)
            {
                return false;
            }
            parentFVar->GetVertexCreaseEndValues(*parent, pIndex, pSibling, pair.Values);
            Emit(ref sink, pair.Values[0], 0.125f);
            Emit(ref sink, pair.Values[1], 0.125f);
            Emit(ref sink, pVertValue, 0.75f);
            return true;
        }

        /// <summary>페이스 중심 값(페이스 자식 값)에 줄 가중치를 그 페이스의 부모 FVar 코너 값으로 weight / n 씩 펼친다.</summary>
        private static void EmitFaceValueCenter(OsdLevel* parent, OsdFVarLevel* parentFVar, int face, float weight, ref RowSink sink)
        {
            OsdRange fValues = parentFVar->GetFaceValues(*parent, face);
            float spread = weight / (float)fValues.Count;
            for (int i = 0; i < fValues.Count; ++i)
            {
                Emit(ref sink, fValues.Ptr[i], spread);
            }
        }

        /// <summary>엣지에서 vertex 의 맞은편 정점 (퇴화 엣지면 자신).</summary>
        private static int OppositeVertex(OsdLevel* parent, int edge, int vertex)
        {
            int* eVerts = parent->EdgeVertIndices.Ptr + 2 * edge;
            return eVerts[0] == vertex ? eVerts[1] : eVerts[0];
        }

        private static void Emit(ref RowSink sink, int index, float weight)
        {
            if (sink.Mode == SinkGetAt)
            {
                if (sink.Count == sink.Probe)
                {
                    sink.Result = index;
                }
                ++sink.Count;
                return;
            }
            if (sink.Mode == SinkFindFirst)
            {
                if (sink.Result < 0 && index == sink.Probe)
                {
                    sink.Result = sink.Count;
                }
                ++sink.Count;
                return;
            }

            // SinkCount·SinkFill: 같은 부모 인덱스는 합친다 (StencilBuilder 의 merge 와 같은 선형 탐색)
            for (int i = 0; i < sink.Count; ++i)
            {
                if (sink.Indices[i] == index)
                {
                    if (sink.Mode == SinkFill)
                    {
                        sink.Weights[i] += weight;
                    }
                    return;
                }
            }
            if (sink.Count == sink.Capacity)
            {
                sink.Overflow = 1;
                return;
            }
            sink.Indices[sink.Count] = index;
            if (sink.Mode == SinkFill)
            {
                sink.Weights[sink.Count] = weight;
            }
            ++sink.Count;
        }
    }
}
