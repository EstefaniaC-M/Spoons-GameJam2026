﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 한 레벨 스텐실 평가의 작업 데이터 블록. 버스트 커널이 포인터 하나로 받도록 blittable 필드만 둔다.
    /// Source 는 부모 레벨 값 (SourceCount × Components), Destination 은 자식 레벨 값 (RowCount × Components) 이고 겹치지 않아야 한다.
    /// </summary>
    public unsafe struct OsdEvaluateData
    {
        public OsdStencilLevel Stencils;
        public float* Source;
        public float* Destination;

        /// <summary>값 하나의 성분 수 (위치 3, UV 2).</summary>
        public int Components;
    }

    /// <summary>
    /// 스텐실 평가 (osd/cpuEvaluator 의 EvalStencils 대응: 자식 = Σ 가중치 × 부모, float 누적). 버스트 호환: 포인터·blittable 만.
    /// 행끼리 독립이라 EvaluateRow 를 병렬로 불러도 된다.
    /// </summary>
    public static unsafe class OsdEvaluator
    {
        /// <summary>행 하나를 평가해 Destination 의 그 행 자리에 쓴다.</summary>
        public static void EvaluateRow(OsdEvaluateData* data, int row)
        {
            int begin = data->Stencils.RowOffsets.Ptr[row];
            int end = data->Stencils.RowOffsets.Ptr[row + 1];
            int* indices = data->Stencils.Indices.Ptr;
            float* weights = data->Stencils.Weights.Ptr;
            float* source = data->Source;
            int components = data->Components;
            float* destination = data->Destination + (long)row * components;

            if (components == 3)
            {
                float x = 0.0f;
                float y = 0.0f;
                float z = 0.0f;
                for (int k = begin; k < end; ++k)
                {
                    float weight = weights[k];
                    float* value = source + (long)indices[k] * 3;
                    x += weight * value[0];
                    y += weight * value[1];
                    z += weight * value[2];
                }
                destination[0] = x;
                destination[1] = y;
                destination[2] = z;
                return;
            }

            if (components == 2)
            {
                float u = 0.0f;
                float v = 0.0f;
                for (int k = begin; k < end; ++k)
                {
                    float weight = weights[k];
                    float* value = source + (long)indices[k] * 2;
                    u += weight * value[0];
                    v += weight * value[1];
                }
                destination[0] = u;
                destination[1] = v;
                return;
            }

            for (int c = 0; c < components; ++c)
            {
                destination[c] = 0.0f;
            }
            for (int k = begin; k < end; ++k)
            {
                float weight = weights[k];
                float* value = source + (long)indices[k] * components;
                for (int c = 0; c < components; ++c)
                {
                    destination[c] += weight * value[c];
                }
            }
        }

        /// <summary>모든 행을 차례로 평가한다.</summary>
        public static void EvaluateAll(OsdEvaluateData* data)
        {
            int rowCount = data->Stencils.RowCount;
            for (int row = 0; row < rowCount; ++row)
            {
                EvaluateRow(data, row);
            }
        }
    }
}
