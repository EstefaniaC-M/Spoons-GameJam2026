﻿// 서브디비전 입력 압축: 페이스가 쓰는 정점·UV 만 첫 등장 순서로 다시 번호를 매기고, 언랩되지 않은 코너(UV -1)를 공용 더미 값 하나로 바꾼다 (UModelerX 고유 코드).

using System;

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 압축한 레벨 0 입력. 페이스가 쓰는 정점·UV 만 남기고(D9) 처음 나타나는 순서로 다시 번호를 매겼다.
    /// UV ID -1 코너(언랩되지 않은 페이스)는 공용 더미 값 하나로 바꿨다(D10).
    /// </summary>
    public sealed class OsdCompactedInput
    {
        public int FaceCount;

        /// <summary>페이스마다 코너 수 (FaceCount 개).</summary>
        public int[] FaceSizes;

        /// <summary>페이스 순서대로 이어 붙인 코너의 압축 정점 인덱스.</summary>
        public int[] FaceVertices;

        /// <summary>페이스 순서대로 이어 붙인 코너의 압축 값(UV) 인덱스. -1 이 없다.</summary>
        public int[] FaceValues;

        public int VertexCount;

        /// <summary>값 수 (더미가 있으면 더미 포함).</summary>
        public int ValueCount;

        /// <summary>압축 정점 인덱스 → 원래 정점 ID.</summary>
        public int[] VertexIdOfCompact;

        /// <summary>압축 값 인덱스 → 원래 UV ID. 더미 값은 -1.</summary>
        public int[] UvIdOfCompact;

        /// <summary>-1 코너가 있으면 그 코너들이 함께 쓰는 더미 값 인덱스(마지막 값, ValueCount - 1), 없으면 -1.</summary>
        public int DummyValue;

        /// <summary>
        /// 압축 정점 인덱스별 정점 샤프니스 (호출자가 채운다). null 이면 모두 0.
        /// 값을 넣을 때는 길이가 VertexCount 이상이어야 하고 각 값은 0 또는 OsdConstants.SharpnessInfinite 만 받는다 (Port 에 semi-sharp 가 없다, D2). 아니면 TryCreate 가 InvalidInput 을 돌려준다.
        /// </summary>
        public float[] VertexSharpness;
    }

    /// <summary>입력 압축 (D9·D10). 관리 코드다 (버스트 함수가 아니다).</summary>
    public static unsafe class OsdInputCompactor
    {
        /// <summary>
        /// 페이스 순 → 코너 순으로 처음 나타나는 정점·UV 에 0 부터 압축 인덱스를 준다. UV ID -1 코너는 실제 값 뒤에 붙인 더미 값 하나를 함께 쓴다.
        /// 정점 ID 는 0 이상, UV ID 는 -1 이상이어야 하고, 코너 배열은 faceSizes 합계 이상이어야 한다 (아니면 ArgumentException).
        /// </summary>
        /// <param name="faceCount">페이스 수 (faceSizes 의 앞 faceCount 개를 쓴다).</param>
        /// <param name="faceSizes">페이스마다 코너 수.</param>
        /// <param name="cornerVertexIds">페이스 순서대로 이어 붙인 코너 정점 ID.</param>
        /// <param name="cornerUvIds">cornerVertexIds 와 같은 순서의 코너 UV ID (언랩되지 않은 코너는 -1).</param>
        public static OsdCompactedInput Compact(int faceCount, int[] faceSizes, int[] cornerVertexIds, int[] cornerUvIds)
        {
            if (faceSizes == null)
            {
                throw new ArgumentNullException(nameof(faceSizes));
            }
            if (cornerVertexIds == null)
            {
                throw new ArgumentNullException(nameof(cornerVertexIds));
            }
            if (cornerUvIds == null)
            {
                throw new ArgumentNullException(nameof(cornerUvIds));
            }
            return CompactCore(faceCount, faceSizes, cornerVertexIds, cornerUvIds);
        }

        /// <summary>
        /// UV 채널 없이 정점만 압축한다: ValueCount 0, FaceValues·UvIdOfCompact 길이 0, DummyValue -1 (OsdTopology 가 FVar 채널을 만들지 않는다).
        /// 언랩된 페이스가 하나도 없어 UV 결과를 모두 버릴 때 쓴다. 나머지 규칙·예외는 UV 를 받는 Compact 와 같다.
        /// </summary>
        public static OsdCompactedInput Compact(int faceCount, int[] faceSizes, int[] cornerVertexIds)
        {
            if (faceSizes == null)
            {
                throw new ArgumentNullException(nameof(faceSizes));
            }
            if (cornerVertexIds == null)
            {
                throw new ArgumentNullException(nameof(cornerVertexIds));
            }
            return CompactCore(faceCount, faceSizes, cornerVertexIds, null);
        }

        /// <summary>압축 본체. cornerUvIds 가 null 이면 UV 채널 없이 정점만 압축한다.</summary>
        private static OsdCompactedInput CompactCore(int faceCount, int[] faceSizes, int[] cornerVertexIds, int[] cornerUvIds)
        {
            if (faceCount < 0 || faceCount > faceSizes.Length)
            {
                throw new ArgumentOutOfRangeException(nameof(faceCount), "faceCount must be within the faceSizes array.");
            }

            long cornerTotal = 0;
            for (int f = 0; f < faceCount; ++f)
            {
                if (faceSizes[f] < 0)
                {
                    throw new ArgumentException("Face sizes must not be negative.", nameof(faceSizes));
                }
                cornerTotal += faceSizes[f];
            }
            if (cornerTotal > cornerVertexIds.Length || (cornerUvIds != null && cornerTotal > cornerUvIds.Length))
            {
                throw new ArgumentException("Corner arrays are shorter than the sum of the face sizes.");
            }
            int cornerCount = (int)cornerTotal;

            // ID 의 최대값으로 ID → 압축 인덱스 표를 만든다
            int maxVertexId = -1;
            int maxUvId = -1;
            for (int c = 0; c < cornerCount; ++c)
            {
                int vertexId = cornerVertexIds[c];
                int uvId = cornerUvIds != null ? cornerUvIds[c] : -1;
                if (vertexId < 0)
                {
                    throw new ArgumentException("Corner vertex IDs must not be negative.", nameof(cornerVertexIds));
                }
                if (uvId < -1)
                {
                    throw new ArgumentException("Corner UV IDs must be -1 or greater.", nameof(cornerUvIds));
                }
                maxVertexId = Math.Max(maxVertexId, vertexId);
                maxUvId = Math.Max(maxUvId, uvId);
            }

            int[] compactOfVertex = NewFilled(maxVertexId + 1, -1);
            int[] compactOfUv = NewFilled(maxUvId + 1, -1);
            int[] vertexIdOfCompact = new int[cornerCount];
            int[] uvIdOfCompact = new int[cornerCount + 1];

            OsdCompactedInput input = new OsdCompactedInput();
            input.FaceCount = faceCount;
            input.FaceSizes = new int[faceCount];
            Array.Copy(faceSizes, input.FaceSizes, faceCount);
            input.FaceVertices = new int[cornerCount];
            input.FaceValues = new int[cornerUvIds != null ? cornerCount : 0];

            int vertexCount = 0;
            int valueCount = 0;
            bool hasDummy = false;
            for (int c = 0; c < cornerCount; ++c)
            {
                int vertexId = cornerVertexIds[c];
                int compactVertex = compactOfVertex[vertexId];
                if (compactVertex < 0)
                {
                    compactVertex = vertexCount++;
                    compactOfVertex[vertexId] = compactVertex;
                    vertexIdOfCompact[compactVertex] = vertexId;
                }
                input.FaceVertices[c] = compactVertex;

                if (cornerUvIds == null)
                {
                    // UV 채널 없음: 값·더미를 만들지 않는다
                    continue;
                }
                int uvId = cornerUvIds[c];
                if (uvId < 0)
                {
                    // 더미 번호는 실제 값 개수가 정해진 뒤에 넣는다
                    hasDummy = true;
                    input.FaceValues[c] = -1;
                    continue;
                }
                int compactValue = compactOfUv[uvId];
                if (compactValue < 0)
                {
                    compactValue = valueCount++;
                    compactOfUv[uvId] = compactValue;
                    uvIdOfCompact[compactValue] = uvId;
                }
                input.FaceValues[c] = compactValue;
            }

            input.DummyValue = -1;
            if (hasDummy)
            {
                input.DummyValue = valueCount;
                uvIdOfCompact[valueCount] = -1;
                ++valueCount;
                for (int c = 0; c < cornerCount; ++c)
                {
                    if (input.FaceValues[c] < 0)
                    {
                        input.FaceValues[c] = input.DummyValue;
                    }
                }
            }

            input.VertexCount = vertexCount;
            input.ValueCount = valueCount;
            input.VertexIdOfCompact = new int[vertexCount];
            Array.Copy(vertexIdOfCompact, input.VertexIdOfCompact, vertexCount);
            input.UvIdOfCompact = new int[valueCount];
            Array.Copy(uvIdOfCompact, input.UvIdOfCompact, valueCount);
            return input;
        }

        private static int[] NewFilled(int length, int value)
        {
            int[] array = new int[length];
            for (int i = 0; i < length; ++i)
            {
                array[i] = value;
            }
            return array;
        }
    }
}
