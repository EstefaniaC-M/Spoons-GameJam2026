﻿//
//   Copyright 2014 DreamWorks Animation LLC.
//
//   Licensed under the Apache License, Version 2.0 (the "Apache License")
//   with the following modification; you may not use this file except in
//   compliance with the Apache License and the following modification to it:
//   Section 6. Trademarks. is deleted and replaced with:
//
//   6. Trademarks. This License does not grant permission to use the trade
//      names, trademarks, service marks, or product names of the Licensor
//      and its affiliates, except as required to comply with Section 4(c) of
//      the License and to reproduce the content of the NOTICE file.
//
//   You may obtain a copy of the Apache License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the Apache License with the above modification is
//   distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
//   KIND, either express or implied. See the Apache License for the specific
//   language governing permissions and limitations under the Apache License.
//

// OpenSubdiv 3.4.3 의 C# 이식.

namespace Tripolygon.UModelerX.Editor.OpenSubdiv
{
    /// <summary>
    /// 한 레벨 분할(부모 레벨 → 자식 레벨)의 작업 데이터 블록 (far/topologyRefiner.cpp 의 RefineUniform 이 한 레벨마다 넘기는 것).
    /// 버스트 커널이 포인터 하나로 받도록 blittable 필드만 둔다. 호출자가 OsdQuadRefiner.AllocateChild 결과를 Child·Refinement 에 넣고
    /// OsdQuadRefiner.RefineTopology 에 넘기면, 자식 개수와 줄인 관계 길이가 이 블록 안의 Child·Refinement 에 쓰인다.
    /// HasFVar 면 OsdFVarRefiner.AllocateChild 결과를 ChildFVar·FVarRefinement 에 넣고, RefineTopology 다음에 OsdFVarRefiner.RefineValues 를 부른다
    /// (자식 값 수와 줄인 값 버퍼 길이가 블록 안의 ChildFVar·FVarRefinement 에 쓰인다).
    /// 버퍼 소유권은 호출자에게 있다 (블록은 복사본을 들고 있을 뿐이다).
    /// </summary>
    public unsafe struct OsdRefineLevelData
    {
        public OsdLevel Parent;
        public OsdLevel Child;
        public OsdRefinement Refinement;

        // FVar(UV) 채널 — HasFVar 일 때만 쓴다
        public OsdFVarLevel ParentFVar;
        public OsdFVarLevel ChildFVar;
        public OsdFVarRefinement FVarRefinement;

        /// <summary>1 이면 FVar 채널이 있다: 마지막 레벨(FullTopology == 0)에서도 정점-페이스를 채운다 (FVar 분할이 쓴다).</summary>
        public byte HasFVar;

        /// <summary>1 이면 여섯 관계를 모두 채운다. 0 이면(마지막 레벨, 원본 minimalTopology) 페이스-정점과 — HasFVar 면 — 정점-페이스만 채운다.</summary>
        public byte FullTopology;

        /// <summary>RefineTopology·RefineValues 결과 (OsdStatus 값). 균일 분할은 실패 경로가 없어 끝나면 Ok 다.</summary>
        public int Status;
    }

    /// <summary>
    /// 오케스트레이터가 레벨 분할·스텐실 생성·평가를 맡기는 실행기 (버스트 커널 등). 각 함수는 데이터 블록 포인터 하나를 받아
    /// Port 정적 함수(OsdQuadRefiner.RefineTopology — HasFVar 면 이어서 OsdFVarRefiner.RefineValues,
    /// OsdStencilBuilder.BuildVertexStencils — IsValues 면 OsdStencilBuilder.BuildValueStencils, OsdEvaluator.EvaluateAll)와 같은 일을 한다.
    /// false 를 돌려주면 Port 가 같은 정적 함수를 관리 코드로 직접 부른다 (블록은 다시 채워 넘긴다).
    /// </summary>
    public unsafe interface IOsdExecutor
    {
        bool TryRefineLevel(OsdRefineLevelData* data);

        bool TryBuildStencils(OsdStencilBuildData* data);

        bool TryEvaluate(OsdEvaluateData* data);
    }

    /// <summary>레벨 0 출처 요소 종류 (OsdTopology 출처 표). 짝을 이루는 인덱스는 정점이면 압축 정점, 엣지면 레벨 0 엣지(CoarseEdgeVertices), 페이스면 레벨 0 페이스다.</summary>
    public enum OsdOriginKind : byte
    {
        Vertex = 0,
        Edge = 1,
        Face = 2,
    }

    /// <summary>
    /// 서브디비전 오케스트레이터 (far/topologyRefinerFactory 의 레벨 0 생성 + far/topologyRefiner 의 RefineUniform + 레벨별 스텐실).
    /// TryCreate 가 레벨 0 을 만들고 레벨 1..N 을 균일 분할하며 레벨마다 정점 스텐실(CSR, D8)과 — 값이 있으면 — 값(UV) 스텐실을 만든다. 끝나면 레벨 토폴로지는 해제하고
    /// 스텐실과 마지막 레벨 출력 인덱스만 남긴다. Evaluate 는 스텐실로 레벨 0 값에서 마지막 레벨 값을 만든다 (위치·UV 만 바뀌면 다시 부른다).
    /// 관리 코드다. 비관리 메모리는 Dispose 가 풀고, Dispose 를 잊으면 파이널라이저가 푼다.
    /// </summary>
    public sealed unsafe class OsdTopology : System.IDisposable
    {
        private OsdStencilLevel[] vertexStencils;
        private OsdStencilLevel[] valueStencils;
        private OsdBuffer<int> refinedFaceVertices;
        private OsdBuffer<int> refinedFaceValues;
        private int[] refinedFaceParents;
        private bool disposed;

        // 출처 표 (TryCreate 의 recordOrigins). 없으면 배열이 null 이다
        private int[] coarseEdgeVertices;
        private int[] refinedVertexOrigins;
        private byte[] refinedVertexOriginKinds;
        private int firstRefinedVertFromFace;
        private int refinedVertFromFaceCount;
        private int firstRefinedVertFromEdge;
        private int refinedVertFromEdgeCount;

        private OsdTopology()
        {
        }

        ~OsdTopology()
        {
            FreeUnmanaged();
        }

        /// <summary>분할 레벨 수.</summary>
        public int Level { get; private set; }

        /// <summary>레벨 0 정점 수 (압축한 입력의 VertexCount).</summary>
        public int CoarseVertexCount { get; private set; }

        /// <summary>레벨 0 값(UV) 수 (압축한 입력의 ValueCount).</summary>
        public int CoarseValueCount { get; private set; }

        public int RefinedVertexCount { get; private set; }

        /// <summary>마지막 레벨 값(UV) 수. 입력에 값이 없으면(ValueCount == 0) 0.</summary>
        public int RefinedValueCount { get; private set; }

        public int RefinedFaceCount { get; private set; }

        /// <summary>정점 스텐실. 인덱스 0 = 레벨 0 → 1. Dispose 뒤에는 비어 있다.</summary>
        public OsdStencilLevel[] VertexStencils
        {
            get { return vertexStencils; }
        }

        /// <summary>
        /// 값(UV) 스텐실. 인덱스 0 = 레벨 0 → 1. 행은 자식 레벨 값 오프셋, 인덱스는 부모 레벨 값(레벨 0 은 압축 값 인덱스)이다.
        /// 입력에 값이 없으면(ValueCount == 0) 길이 0. Dispose 뒤에는 비어 있다.
        /// </summary>
        public OsdStencilLevel[] ValueStencils
        {
            get { return valueStencils; }
        }

        /// <summary>마지막 레벨 쿼드의 코너 정점 인덱스 (페이스당 4). ReleaseOutputTopology 뒤에는 비어 있다.</summary>
        public OsdBuffer<int> RefinedFaceVertices
        {
            get { return refinedFaceVertices; }
        }

        /// <summary>마지막 레벨 쿼드의 코너 값 인덱스 (페이스당 4). 입력에 값이 없으면 비어 있다. ReleaseOutputTopology 뒤에는 비어 있다.</summary>
        public OsdBuffer<int> RefinedFaceValues
        {
            get { return refinedFaceValues; }
        }

        /// <summary>마지막 레벨 쿼드마다 레벨 0 부모 페이스 인덱스. ReleaseOutputTopology 뒤에는 null.</summary>
        public int[] RefinedFaceParents
        {
            get { return refinedFaceParents; }
        }

        /// <summary>TryCreate 에 recordOrigins 를 줬으면 true — 출처 표(CoarseEdgeVertices·GetRefined*)를 쓸 수 있다. ReleaseOutputTopology 뒤에도 남는다.</summary>
        public bool HasOrigins
        {
            get { return refinedVertexOrigins != null; }
        }

        /// <summary>레벨 0 엣지마다 두 끝 정점 (압축 정점 인덱스, 엣지당 2). 출처 표의 엣지 인덱스가 가리키는 표다. 출처 표가 없으면 null.</summary>
        public int[] CoarseEdgeVertices
        {
            get { return coarseEdgeVertices; }
        }

        /// <summary>
        /// 마지막 레벨 정점의 레벨 0 출처. 정점 점이면 부모 정점의 출처를 잇고, 엣지 점은 부모 엣지의 출처(레벨 0 엣지의 조각이면 그 엣지,
        /// 페이스 안에서 생긴 엣지면 그 페이스), 페이스 점은 부모 페이스의 레벨 0 페이스다. 끝까지 정점 점이면 레벨 0 정점이다.
        /// </summary>
        public OsdOriginKind GetRefinedVertexOrigin(int vertex, out int index)
        {
            index = refinedVertexOrigins[vertex];
            return (OsdOriginKind)refinedVertexOriginKinds[vertex];
        }

        /// <summary>마지막 분할 단계에서 정점을 만든 부모 요소 종류 (정점 점·엣지 점·페이스 점). 출처 표가 있을 때만 쓴다.</summary>
        public OsdOriginKind GetRefinedVertexParentKind(int vertex)
        {
            if (vertex >= firstRefinedVertFromFace && vertex < firstRefinedVertFromFace + refinedVertFromFaceCount)
            {
                return OsdOriginKind.Face;
            }
            if (vertex >= firstRefinedVertFromEdge && vertex < firstRefinedVertFromEdge + refinedVertFromEdgeCount)
            {
                return OsdOriginKind.Edge;
            }
            return OsdOriginKind.Vertex;
        }

        /// <summary>
        /// 마지막 레벨 엣지(한 쿼드에서 이웃한 두 코너)의 레벨 0 출처. 쿼드 분할의 자식 엣지는 늘 엣지 점과 정점 점(부모 엣지의 반쪽)이나
        /// 엣지 점과 페이스 점(부모 페이스 안의 새 엣지)을 잇는다 — 앞은 엣지 점의, 뒤는 페이스 점의 출처를 따르므로
        /// 부모 종류가 높은 쪽(정점 &lt; 엣지 &lt; 페이스) 끝점의 출처다. 늘 엣지나 페이스다 (이웃 코너가 아닌 쌍이면 뜻이 없다).
        /// </summary>
        public OsdOriginKind GetRefinedEdgeOrigin(int vertexA, int vertexB, out int index)
        {
            int vertex = GetRefinedVertexParentKind(vertexA) >= GetRefinedVertexParentKind(vertexB) ? vertexA : vertexB;
            return GetRefinedVertexOrigin(vertex, out index);
        }

        /// <summary>TryCreate 의 레벨 0 생성·분할 시간 (시간 로그용).</summary>
        public double RefineMilliseconds { get; private set; }

        /// <summary>TryCreate 의 스텐실 생성 시간 (시간 로그용).</summary>
        public double StencilMilliseconds { get; private set; }

        /// <summary>
        /// 압축한 입력에서 level 단계 분할 토폴로지와 레벨별 스텐실을 만든다. 실패하면 topology 는 null 이고 쓴 메모리는 모두 풀린다.
        /// 레벨 0 이 입력을 거절하면 그 사유(원본의 거절 조건), 입력 배열이 계약과 맞지 않거나 level 이 1 보다 작으면 InvalidInput.
        /// executor 가 null 이거나 단계마다 false 를 돌려주면 관리 코드로 돈다.
        /// input.ValueCount > 0 이면 FVar(UV) 채널 하나를 만들어 레벨마다 함께 분할하고 값 스텐실·RefinedFaceValues·RefinedValueCount 를 채운다.
        /// </summary>
        /// <param name="linear">FVar 선형 보간 (FVar 채널의 옵션).</param>
        /// <param name="recordOrigins">true 면 레벨마다 자식 → 부모 매핑을 이어 출처 표(마지막 레벨 정점의 레벨 0 출처, 레벨 0 엣지 끝점)를 남긴다 — 요소별 데이터를 결과로 옮기는 툴 경로용.</param>
        public static OsdStatus TryCreate(OsdCompactedInput input, int level, OsdBoundaryInterpolation boundary, OsdFVarLinearInterpolation linear, IOsdExecutor executor, out OsdTopology topology,
            bool recordOrigins = false)
        {
            topology = null;
            OsdStatus inputStatus = ValidateInput(input, level);
            if (inputStatus != OsdStatus.Ok)
            {
                return inputStatus;
            }

            OsdTopology result = new OsdTopology();
            result.Level = level;
            result.CoarseVertexCount = input.VertexCount;
            result.CoarseValueCount = input.ValueCount;
            result.vertexStencils = new OsdStencilLevel[level];

            System.Diagnostics.Stopwatch refineWatch = new System.Diagnostics.Stopwatch();
            System.Diagnostics.Stopwatch stencilWatch = new System.Diagnostics.Stopwatch();

            // FVar 분할은 마지막 레벨에도 정점-페이스가 필요하다
            bool hasFVar = input.ValueCount > 0;
            result.valueStencils = new OsdStencilLevel[hasFVar ? level : 0];

            OsdLevel parent = default;
            OsdLevel child = default;
            OsdRefinement refinement = default;
            OsdFVarLevel parentFVar = default;
            OsdFVarLevel childFVar = default;
            OsdFVarRefinement fvarRefinement = default;
            OsdBuffer<OsdRefineLevelData> refineBlock = default;
            OsdBuffer<OsdStencilBuildData> stencilBlock = default;
            OsdBuffer<OsdStencilLevel> targetBlock = default;
            OsdBuffer<float> scratch = default;
            bool succeeded = false;
            try
            {
                // 레벨 0: 토폴로지 완성 + 태그·샤프니스
                refineWatch.Start();
                OsdStatus status;
                fixed (int* faceSizes = input.FaceSizes)
                fixed (int* faceVertices = input.FaceVertices)
                {
                    status = OsdLevelBuilder.BuildBaseLevel(input.VertexCount, input.FaceCount, faceSizes, faceVertices, out parent);
                }
                if (status != OsdStatus.Ok)
                {
                    return status;
                }
                // 호출자가 준 정점 샤프니스를 태그 전에 넣는다 (Apply 가 이 값을 시작값으로 쓴다)
                if (input.VertexSharpness != null)
                {
                    for (int v = 0; v < input.VertexCount; ++v)
                    {
                        parent.VertSharpness.Ptr[v] = input.VertexSharpness[v];
                    }
                }
                OsdBaseLevelTags.Apply(ref parent, boundary, out _);

                // 레벨 0 FVar 채널 (태그를 붙인 뒤 — 원본 prepareFaceVaryingChannels 순서)
                if (hasFVar)
                {
                    fixed (int* faceValues = input.FaceValues)
                    {
                        status = OsdFVarLevelBuilder.BuildBaseChannel(parent, input.ValueCount, faceValues, boundary, linear, out parentFVar);
                    }
                    if (status != OsdStatus.Ok)
                    {
                        return status;
                    }
                }

                // 지금 레벨 페이스 → 레벨 0 부모 페이스
                int[] faceParents = new int[parent.FaceCount];
                for (int f = 0; f < faceParents.Length; ++f)
                {
                    faceParents[f] = f;
                }

                // 출처 표: 지금 레벨 정점·엣지 → 레벨 0 출처 (종류·인덱스). 레벨 0 은 자기 자신이다
                int[] vertexOrigins = null;
                byte[] vertexOriginKinds = null;
                int[] edgeOrigins = null;
                byte[] edgeOriginKinds = null;
                if (recordOrigins)
                {
                    vertexOrigins = new int[parent.VertCount];
                    vertexOriginKinds = new byte[parent.VertCount];
                    for (int v = 0; v < vertexOrigins.Length; ++v)
                    {
                        vertexOrigins[v] = v;
                    }
                    edgeOrigins = new int[parent.EdgeCount];
                    edgeOriginKinds = new byte[parent.EdgeCount];
                    result.coarseEdgeVertices = new int[2 * parent.EdgeCount];
                    for (int e = 0; e < edgeOrigins.Length; ++e)
                    {
                        edgeOrigins[e] = e;
                        edgeOriginKinds[e] = (byte)OsdOriginKind.Edge;
                        result.coarseEdgeVertices[2 * e] = parent.EdgeVertIndices.Ptr[2 * e];
                        result.coarseEdgeVertices[2 * e + 1] = parent.EdgeVertIndices.Ptr[2 * e + 1];
                    }
                }
                refineWatch.Stop();

                // 작업 데이터 블록은 비관리 메모리에 둔다 (버스트 커널이 포인터 하나만 갖도록)
                refineBlock = OsdBuffer<OsdRefineLevelData>.Allocate(1);
                stencilBlock = OsdBuffer<OsdStencilBuildData>.Allocate(1);
                targetBlock = OsdBuffer<OsdStencilLevel>.Allocate(1);

                for (int depth = 1; depth <= level; ++depth)
                {
                    bool fullTopology = depth != level;

                    // 분할: AllocateChild(토폴로지·FVar) → 실행기 또는 RefineTopology + RefineValues
                    refineWatch.Start();
                    OsdQuadRefiner.AllocateChild(parent, fullTopology, hasFVar, out child, out refinement);
                    if (hasFVar)
                    {
                        int estimatedValueCount = OsdFVarRefiner.EstimateChildValueCount(parent, parentFVar, refinement);
                        OsdFVarRefiner.AllocateChild(child, estimatedValueCount, out childFVar, out fvarRefinement);
                    }

                    OsdRefineLevelData* refineData = refineBlock.Ptr;
                    FillRefineData(refineData, parent, child, refinement, parentFVar, childFVar, fvarRefinement, fullTopology, hasFVar);
                    if (executor == null || executor.TryRefineLevel(refineData) == false)
                    {
                        FillRefineData(refineData, parent, child, refinement, parentFVar, childFVar, fvarRefinement, fullTopology, hasFVar);
                        OsdQuadRefiner.RefineTopology(refineData);
                        if (hasFVar && refineData->Status == (int)OsdStatus.Ok)
                        {
                            OsdFVarRefiner.RefineValues(refineData);
                        }
                    }

                    // RefineTopology·RefineValues 는 자식 개수와 줄인 관계·값 버퍼 길이를 블록 안에 쓴다
                    child = refineData->Child;
                    refinement = refineData->Refinement;
                    if (hasFVar)
                    {
                        childFVar = refineData->ChildFVar;
                        fvarRefinement = refineData->FVarRefinement;
                    }
                    int refineStatus = refineData->Status;
                    *refineData = default;
                    if (refineStatus != (int)OsdStatus.Ok)
                    {
                        return StatusOf(refineStatus);
                    }

                    // 출처 표: 부모 페이스 표를 바꾸기 전에 잇는다. 마지막 레벨은 엣지가 없어(최소 토폴로지) 정점만 잇는다
                    if (recordOrigins)
                    {
                        InheritOrigins(refinement, child.VertCount, fullTopology ? child.EdgeCount : 0, faceParents,
                            ref vertexOrigins, ref vertexOriginKinds, ref edgeOrigins, ref edgeOriginKinds);
                        result.firstRefinedVertFromFace = refinement.FirstChildVertFromFace;
                        result.refinedVertFromFaceCount = refinement.ChildVertFromFaceCount;
                        result.firstRefinedVertFromEdge = refinement.FirstChildVertFromEdge;
                        result.refinedVertFromEdgeCount = refinement.ChildVertFromEdgeCount;
                    }

                    int[] childFaceParents = new int[child.FaceCount];
                    for (int cFace = 0; cFace < childFaceParents.Length; ++cFace)
                    {
                        childFaceParents[cFace] = faceParents[refinement.ChildFaceParentIndex.Ptr[cFace]];
                    }
                    faceParents = childFaceParents;
                    refineWatch.Stop();

                    // 정점 스텐실: 부모 레벨(전체 토폴로지) + 자식 정점 태그(규칙)
                    stencilWatch.Start();
                    OsdStatus stencilStatus = BuildStencilLevel(parent, child, refinement, default, default, default, false, executor, stencilBlock.Ptr, targetBlock.Ptr, ref scratch);
                    if (stencilStatus != OsdStatus.Ok)
                    {
                        return stencilStatus;
                    }
                    result.vertexStencils[depth - 1] = *targetBlock.Ptr;
                    *targetBlock.Ptr = default;

                    // 값 스텐실: 위에 더해 부모·자식 FVar 채널과 FVar 분할 (RefineValues 를 마친 것)
                    if (hasFVar)
                    {
                        stencilStatus = BuildStencilLevel(parent, child, refinement, parentFVar, childFVar, fvarRefinement, true, executor, stencilBlock.Ptr, targetBlock.Ptr, ref scratch);
                        if (stencilStatus != OsdStatus.Ok)
                        {
                            return stencilStatus;
                        }
                        result.valueStencils[depth - 1] = *targetBlock.Ptr;
                        *targetBlock.Ptr = default;
                    }
                    stencilWatch.Stop();

                    // 부모 레벨과 분할 매핑은 더 쓰지 않는다
                    refinement.Free();
                    parent.Free();
                    parent = child;
                    child = default;

                    fvarRefinement.Free();
                    parentFVar.Free();
                    parentFVar = childFVar;
                    childFVar = default;
                }

                // 마지막 레벨의 페이스-정점·페이스 값은 출력으로 넘겨받는다 (복사하지 않는다)
                result.RefinedVertexCount = parent.VertCount;
                result.RefinedFaceCount = parent.FaceCount;
                result.refinedFaceVertices = parent.FaceVertIndices;
                parent.FaceVertIndices = default;
                result.refinedFaceParents = faceParents;
                result.refinedVertexOrigins = vertexOrigins;
                result.refinedVertexOriginKinds = vertexOriginKinds;
                if (hasFVar)
                {
                    result.RefinedValueCount = parentFVar.ValueCount;
                    result.refinedFaceValues = parentFVar.FaceVertValues;
                    parentFVar.FaceVertValues = default;
                }

                result.RefineMilliseconds = refineWatch.Elapsed.TotalMilliseconds;
                result.StencilMilliseconds = stencilWatch.Elapsed.TotalMilliseconds;
                succeeded = true;
                topology = result;
                return OsdStatus.Ok;
            }
            finally
            {
                fvarRefinement.Free();
                childFVar.Free();
                parentFVar.Free();
                refinement.Free();
                child.Free();
                parent.Free();
                if (targetBlock.IsCreated)
                {
                    targetBlock.Ptr->Free();
                }
                targetBlock.Free();
                stencilBlock.Free();
                refineBlock.Free();
                scratch.Free();
                if (succeeded == false)
                {
                    result.Dispose();
                }
            }
        }

        /// <summary>
        /// 레벨 0 값에서 마지막 레벨 값을 만든다. 위치는 정점당 3 float (coarsePositions 는 CoarseVertexCount 개, refinedPositions 는 RefinedVertexCount 개).
        /// 값(UV)은 값당 2 float 이고 (coarseValues 는 CoarseValueCount 개 — 압축 값 순서, refinedValues 는 RefinedValueCount 개),
        /// coarseValues·refinedValues 가 둘 다 있고 값 스텐실이 있을 때만 평가한다 (null 허용).
        /// 중간 레벨 버퍼는 호출마다 잡고 푼다. executor 가 null 이거나 false 를 돌려주면 관리 코드로 돈다.
        /// </summary>
        public void Evaluate(float* coarsePositions, float* coarseValues, float* refinedPositions, float* refinedValues, IOsdExecutor executor)
        {
            if (disposed)
            {
                throw new System.ObjectDisposedException(nameof(OsdTopology));
            }
            if (coarsePositions == null)
            {
                throw new System.ArgumentNullException(nameof(coarsePositions));
            }
            if (refinedPositions == null)
            {
                throw new System.ArgumentNullException(nameof(refinedPositions));
            }

            EvaluateLevels(vertexStencils, 3, coarsePositions, refinedPositions, executor);
            if (coarseValues != null && refinedValues != null && valueStencils.Length > 0)
            {
                EvaluateLevels(valueStencils, 2, coarseValues, refinedValues, executor);
            }
        }

        /// <summary>출력 인덱스(RefinedFaceVertices·RefinedFaceValues·RefinedFaceParents)를 놓는다. 스텐실은 남아 Evaluate 를 계속 쓸 수 있다.</summary>
        public void ReleaseOutputTopology()
        {
            refinedFaceVertices.Free();
            refinedFaceValues.Free();
            refinedFaceParents = null;
        }

        public void Dispose()
        {
            FreeUnmanaged();
            System.GC.SuppressFinalize(this);
        }

        /// <summary>비관리 메모리(스텐실·출력 인덱스)를 푼다. 두 번 불러도 안전하다. 파이널라이저도 부르므로 다른 관리 객체는 건드리지 않는다.</summary>
        private void FreeUnmanaged()
        {
            if (vertexStencils != null)
            {
                for (int i = 0; i < vertexStencils.Length; ++i)
                {
                    vertexStencils[i].Free();
                }
            }
            if (valueStencils != null)
            {
                for (int i = 0; i < valueStencils.Length; ++i)
                {
                    valueStencils[i].Free();
                }
            }
            refinedFaceVertices.Free();
            refinedFaceValues.Free();
            refinedFaceParents = null;
            disposed = true;
        }

        /// <summary>
        /// BuildBaseLevel·BuildBaseChannel 이 믿는 호출자 계약을 확인한다: 배열 길이, 페이스 크기 0 이상, 코너 정점이 [0, VertexCount) 안,
        /// 값이 있으면(ValueCount > 0) 코너 값이 [0, ValueCount) 안 (값 스텐실이 레벨 0 값 배열 밖을 읽지 않게).
        /// </summary>
        private static OsdStatus ValidateInput(OsdCompactedInput input, int level)
        {
            if (input == null || input.FaceSizes == null || input.FaceVertices == null || level < 1)
            {
                return OsdStatus.InvalidInput;
            }
            if (input.FaceCount < 0 || input.FaceCount > input.FaceSizes.Length || input.VertexCount < 0 || input.ValueCount < 0)
            {
                return OsdStatus.InvalidInput;
            }

            long cornerCount = 0;
            for (int f = 0; f < input.FaceCount; ++f)
            {
                if (input.FaceSizes[f] < 0)
                {
                    return OsdStatus.InvalidInput;
                }
                cornerCount += input.FaceSizes[f];
            }
            if (cornerCount > input.FaceVertices.Length)
            {
                return OsdStatus.InvalidInput;
            }
            for (int c = 0; c < cornerCount; ++c)
            {
                int vertex = input.FaceVertices[c];
                if (vertex < 0 || vertex >= input.VertexCount)
                {
                    return OsdStatus.InvalidInput;
                }
            }

            if (input.VertexSharpness != null)
            {
                if (input.VertexSharpness.Length < input.VertexCount)
                {
                    return OsdStatus.InvalidInput;
                }
                for (int v = 0; v < input.VertexCount; ++v)
                {
                    // 0 과 무한만 받는다 (semi-sharp 는 이식하지 않았다, D2). NaN·음수·+∞ 도 여기서 걸린다
                    float sharpness = input.VertexSharpness[v];
                    if (sharpness != OsdConstants.SharpnessSmooth && sharpness != OsdConstants.SharpnessInfinite)
                    {
                        return OsdStatus.InvalidInput;
                    }
                }
            }

            if (input.ValueCount > 0)
            {
                if (input.FaceValues == null || cornerCount > input.FaceValues.Length)
                {
                    return OsdStatus.InvalidInput;
                }
                for (int c = 0; c < cornerCount; ++c)
                {
                    int value = input.FaceValues[c];
                    if (value < 0 || value >= input.ValueCount)
                    {
                        return OsdStatus.InvalidInput;
                    }
                }
            }
            return OsdStatus.Ok;
        }

        private static void FillRefineData(OsdRefineLevelData* data, in OsdLevel parent, in OsdLevel child, in OsdRefinement refinement,
            in OsdFVarLevel parentFVar, in OsdFVarLevel childFVar, in OsdFVarRefinement fvarRefinement, bool fullTopology, bool hasFVar)
        {
            *data = default;
            data->Parent = parent;
            data->Child = child;
            data->Refinement = refinement;
            data->ParentFVar = parentFVar;
            data->ChildFVar = childFVar;
            data->FVarRefinement = fvarRefinement;
            data->FullTopology = (byte)(fullTopology ? 1 : 0);
            data->HasFVar = (byte)(hasFVar ? 1 : 0);
            data->Status = -1;
        }

        /// <summary>
        /// 자식 레벨 정점과 자식 엣지(childEdgeCount 개 — 마지막 레벨은 0)의 레벨 0 출처를 부모 출처에서 잇는다 (출처 표).
        /// 정점 점은 부모 정점의, 엣지 점과 엣지 자식 엣지는 부모 엣지의 출처를 물려받고, 페이스 점과 페이스 자식 엣지는 부모 페이스의 레벨 0 페이스(faceParents)가 출처다.
        /// 자식 종류는 분할이 정한 번호 구간(FirstChildVertFrom*, ChildEdgeFromFaceCount)으로 가린다.
        /// </summary>
        private static void InheritOrigins(in OsdRefinement refinement, int childVertCount, int childEdgeCount, int[] faceParents,
            ref int[] vertexOrigins, ref byte[] vertexOriginKinds, ref int[] edgeOrigins, ref byte[] edgeOriginKinds)
        {
            int* vertexParents = refinement.ChildVertexParentIndex.Ptr;
            int faceBegin = refinement.FirstChildVertFromFace;
            int faceEnd = faceBegin + refinement.ChildVertFromFaceCount;
            int edgeBegin = refinement.FirstChildVertFromEdge;
            int edgeEnd = edgeBegin + refinement.ChildVertFromEdgeCount;
            int[] childVertexOrigins = new int[childVertCount];
            byte[] childVertexOriginKinds = new byte[childVertCount];
            for (int cVert = 0; cVert < childVertCount; ++cVert)
            {
                int pIndex = vertexParents[cVert];
                if (cVert >= faceBegin && cVert < faceEnd)
                {
                    childVertexOrigins[cVert] = faceParents[pIndex];
                    childVertexOriginKinds[cVert] = (byte)OsdOriginKind.Face;
                }
                else if (cVert >= edgeBegin && cVert < edgeEnd)
                {
                    childVertexOrigins[cVert] = edgeOrigins[pIndex];
                    childVertexOriginKinds[cVert] = edgeOriginKinds[pIndex];
                }
                else
                {
                    childVertexOrigins[cVert] = vertexOrigins[pIndex];
                    childVertexOriginKinds[cVert] = vertexOriginKinds[pIndex];
                }
            }

            int* edgeParents = refinement.ChildEdgeParentIndex.Ptr;
            int[] childEdgeOrigins = new int[childEdgeCount];
            byte[] childEdgeOriginKinds = new byte[childEdgeCount];
            for (int cEdge = 0; cEdge < childEdgeCount; ++cEdge)
            {
                int pIndex = edgeParents[cEdge];
                if (cEdge < refinement.ChildEdgeFromFaceCount)
                {
                    childEdgeOrigins[cEdge] = faceParents[pIndex];
                    childEdgeOriginKinds[cEdge] = (byte)OsdOriginKind.Face;
                }
                else
                {
                    childEdgeOrigins[cEdge] = edgeOrigins[pIndex];
                    childEdgeOriginKinds[cEdge] = edgeOriginKinds[pIndex];
                }
            }

            vertexOrigins = childVertexOrigins;
            vertexOriginKinds = childVertexOriginKinds;
            edgeOrigins = childEdgeOrigins;
            edgeOriginKinds = childEdgeOriginKinds;
        }

        /// <summary>
        /// 한 레벨의 정점 스텐실(isValues 면 값 스텐실)을 target 에 만든다: RowOffsets 할당 → Phase 0(행별 개수) → 누적합·Indices/Weights 할당 → Phase 1(채우기).
        /// 정점 스텐실은 FVar 인자를 보지 않는다. 스크래치는 2 × 부모 MaxValence + 2 (값 스텐실은 3 × MaxValence + 2)로 키워 가며 레벨 사이에 다시 쓴다.
        /// 실패하면 target 에 남은 버퍼는 호출자가 푼다.
        /// </summary>
        private static OsdStatus BuildStencilLevel(in OsdLevel parent, in OsdLevel child, in OsdRefinement refinement,
            in OsdFVarLevel parentFVar, in OsdFVarLevel childFVar, in OsdFVarRefinement fvarRefinement, bool isValues, IOsdExecutor executor,
            OsdStencilBuildData* data, OsdStencilLevel* target, ref OsdBuffer<float> scratch)
        {
            int rowCount = isValues ? childFVar.ValueCount : child.VertCount;

            *target = default;
            target->RowCount = rowCount;
            target->SourceCount = isValues ? parentFVar.ValueCount : parent.VertCount;
            target->RowOffsets = OsdBuffer<int>.Allocate(rowCount + 1);

            int scratchLength = (isValues ? 3 : 2) * parent.MaxValence + 2;
            if (scratch.Length < scratchLength)
            {
                scratch.Free();
                scratch = OsdBuffer<float>.Allocate(scratchLength);
            }

            // Phase 0: 행별 개수가 RowOffsets[row + 1] 에 쓰인다
            OsdStatus status = RunStencilPhase(parent, child, refinement, parentFVar, childFVar, fvarRefinement, isValues, executor, data, target, scratch, 0);
            if (status != OsdStatus.Ok)
            {
                return status;
            }

            // 누적합 → 행 오프셋
            int* offsets = target->RowOffsets.Ptr;
            offsets[0] = 0;
            long total = 0;
            for (int row = 0; row < target->RowCount; ++row)
            {
                total += offsets[row + 1];
                if (total > int.MaxValue)
                {
                    return OsdStatus.InvalidInput;
                }
                offsets[row + 1] = (int)total;
            }
            target->Indices = OsdBuffer<int>.Allocate((int)total);
            target->Weights = OsdBuffer<float>.Allocate((int)total);

            // Phase 1: 채우기
            return RunStencilPhase(parent, child, refinement, parentFVar, childFVar, fvarRefinement, isValues, executor, data, target, scratch, 1);
        }

        private static OsdStatus RunStencilPhase(in OsdLevel parent, in OsdLevel child, in OsdRefinement refinement,
            in OsdFVarLevel parentFVar, in OsdFVarLevel childFVar, in OsdFVarRefinement fvarRefinement, bool isValues, IOsdExecutor executor,
            OsdStencilBuildData* data, OsdStencilLevel* target, OsdBuffer<float> scratch, int phase)
        {
            FillStencilData(data, parent, child, refinement, parentFVar, childFVar, fvarRefinement, isValues, target, scratch, phase);
            if (executor == null || executor.TryBuildStencils(data) == false)
            {
                FillStencilData(data, parent, child, refinement, parentFVar, childFVar, fvarRefinement, isValues, target, scratch, phase);
                if (isValues)
                {
                    OsdStencilBuilder.BuildValueStencils(data);
                }
                else
                {
                    OsdStencilBuilder.BuildVertexStencils(data);
                }
            }
            int status = data->Status;
            *data = default;
            return StatusOf(status);
        }

        private static void FillStencilData(OsdStencilBuildData* data, in OsdLevel parent, in OsdLevel child, in OsdRefinement refinement,
            in OsdFVarLevel parentFVar, in OsdFVarLevel childFVar, in OsdFVarRefinement fvarRefinement, bool isValues,
            OsdStencilLevel* target, OsdBuffer<float> scratch, int phase)
        {
            *data = default;
            data->Parent = parent;
            data->Child = child;
            data->Refinement = refinement;
            if (isValues)
            {
                data->ParentFVar = parentFVar;
                data->ChildFVar = childFVar;
                data->FVarRefinement = fvarRefinement;
            }
            data->Target = target;
            data->Scratch = scratch.Ptr;
            data->ScratchLength = scratch.Length;
            data->Phase = phase;
            data->IsValues = (byte)(isValues ? 1 : 0);
            data->Status = -1;
        }

        /// <summary>
        /// 스텐실을 레벨 순서로 적용한다. 중간 레벨은 번갈아 쓰는 버퍼 둘에, 마지막 레벨은 refined 에 쓴다.
        /// </summary>
        private static void EvaluateLevels(OsdStencilLevel[] levels, int components, float* coarse, float* refined, IOsdExecutor executor)
        {
            int levelCount = levels.Length;
            int maxIntermediate = 0;
            for (int i = 0; i < levelCount - 1; ++i)
            {
                maxIntermediate = System.Math.Max(maxIntermediate, levels[i].RowCount);
            }

            OsdBuffer<float> ping = default;
            OsdBuffer<float> pong = default;
            OsdBuffer<OsdEvaluateData> block = default;
            try
            {
                if (levelCount > 1)
                {
                    ping = OsdBuffer<float>.Allocate(maxIntermediate * components);
                }
                if (levelCount > 2)
                {
                    pong = OsdBuffer<float>.Allocate(maxIntermediate * components);
                }
                block = OsdBuffer<OsdEvaluateData>.Allocate(1);

                float* source = coarse;
                for (int i = 0; i < levelCount; ++i)
                {
                    float* destination = i == levelCount - 1 ? refined : ((i & 1) == 0 ? ping.Ptr : pong.Ptr);

                    OsdEvaluateData* data = block.Ptr;
                    FillEvaluateData(data, levels[i], source, destination, components);
                    if (executor == null || executor.TryEvaluate(data) == false)
                    {
                        // 실행기가 블록을 건드린 뒤 실패했을 수 있으므로 다시 채워 관리 코드로 돈다 (분할·스텐실과 같은 규칙)
                        FillEvaluateData(data, levels[i], source, destination, components);
                        OsdEvaluator.EvaluateAll(data);
                    }
                    source = destination;
                }
            }
            finally
            {
                ping.Free();
                pong.Free();
                block.Free();
            }
        }

        private static void FillEvaluateData(OsdEvaluateData* data, in OsdStencilLevel stencils, float* source, float* destination, int components)
        {
            *data = default;
            data->Stencils = stencils;
            data->Source = source;
            data->Destination = destination;
            data->Components = components;
        }

        /// <summary>블록의 Status 를 OsdStatus 로. 실행되지 않았거나(-1) 모르는 값이면 InvalidInput.</summary>
        private static OsdStatus StatusOf(int status)
        {
            if (status >= (int)OsdStatus.Ok && status <= (int)OsdStatus.InvalidInput)
            {
                return (OsdStatus)status;
            }
            return OsdStatus.InvalidInput;
        }
    }
}
