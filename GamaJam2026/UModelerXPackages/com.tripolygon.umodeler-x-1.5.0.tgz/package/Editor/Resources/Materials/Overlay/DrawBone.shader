Shader "Hidden/UModelerX/DrawBone"
{
    Properties
    {
        [Enum(UnityEngine.Rendering.CompareFunction)] _ZTest("ZTest", Float) = 4
        [Enum(UnityEngine.Rendering.CullMode)] _CullMode("CullMode", Float) = 2
        [Enum(Off, 0, On, 1)] _ZWrite("ZWrite", Float) = 1
        _Alpha("Alpha", Float) = 1
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Blend SrcAlpha OneMinusSrcAlpha
        Lighting Off
        ZWrite [_ZWrite]
        ZTest [_ZTest]
        Cull [_CullMode]

        Pass
        {
            Name "Bone"

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            /// 노말은 UV1 로 들어온다. UMXOverlayMesh 의 채널에 Normal 이 없어
            /// DrawFace 가 색을 TEXCOORD2 로 보내는 것과 같은 관례를 쓴다.
            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : TEXCOORD1;
                float4 color  : COLOR;
            };

            struct v2f
            {
                float4 pos   : SV_POSITION;
                float4 color : COLOR;
                float  shade : TEXCOORD0;
            };

            float _Alpha;

            v2f vert(appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);

                /// 뷰공간 노말의 z 성분이 곧 카메라를 향하는 정도다.
                /// 별도 광원 없이 면마다 밝기를 갈라 옥타헤드론의 8면이 구분되게 한다.
                float3 viewNormal = normalize(mul((float3x3)UNITY_MATRIX_IT_MV, v.normal));
                o.shade = lerp(0.55, 1.0, saturate(abs(viewNormal.z)));
                o.color = v.color;
                return o;
            }

            float4 frag(v2f i) : SV_Target
            {
                return float4(i.color.rgb * i.shade, i.color.a * _Alpha);
            }
            ENDCG
        }
    }
}
